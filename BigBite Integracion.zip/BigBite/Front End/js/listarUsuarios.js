async function cargarUsuarios() {
  try {
    const res = await fetch('/api/usuarios');
    const data = await res.json();
    const lista = document.getElementById('lista-usuarios');
    lista.innerHTML = '';

    data.usuarios.forEach(p => {
      const item = document.createElement('li');
      item.classList.add('usuario-item');

      item.innerHTML = `
        <div class="usuario-detalle">
          <div class="usuario-header">
            <strong>${p.rut}</strong>
            <strong class="rolUsua">Rol: ${p.rol}</strong>
          </div>
          <div>
            <strong>${p.nombre}</strong>
            <strong> (${p.correo})</strong>
          </div>
          <div class="rol-descripcion">
            <em>${p.rolDescripcion || 'Sin descripción'}</em>
          </div>
        </div>
      `;

      lista.appendChild(item);
    });
  } catch (err) {
    console.error('Error al cargar usuarios:', err);
  }
}

cargarUsuarios();