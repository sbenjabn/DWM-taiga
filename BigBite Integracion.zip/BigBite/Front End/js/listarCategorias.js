async function cargarCategorias() {
  try {
    const res = await fetch('/api/categorias');
    const data = await res.json();
    const lista = document.getElementById('lista-categorias');
    lista.innerHTML = '';

    data.categorias.forEach(p => {
      const item = document.createElement('li');
      item.classList.add('categoria-item');


    item.innerHTML = `
    <div class="categoria-detalle">
        <div class="categoria-header">
        <strong>${p.codigo}</strong>
        <strong>${p.nombre}</strong>
        </div>
        <span>${p.descripcion}</span><br>
    </div>
    `;
        lista.appendChild(item);
    });
  } catch (err) {
    console.error('Error al cargar categorias:', err);
  }
}

cargarCategorias();