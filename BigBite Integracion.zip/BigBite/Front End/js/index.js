// Menú móvil
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Carrusel
const carruselContenedor = document.querySelector('.carrusel-contenedor');
const carruselItems = document.querySelectorAll('.carrusel-item');
const prevBtn = document.querySelector('.izquierda');
const nextBtn = document.querySelector('.derecha');
const indicadores = document.querySelectorAll('.indicador');

let currentIndex = 0;
const totalItems = carruselItems.length;

function updateCarrusel() {
    carruselContenedor.style.transform = `translateX(-${currentIndex * 100}%)`;
    
    // Actualizar indicadores
    indicadores.forEach((indicador, index) => {
    indicador.classList.toggle('activo', index === currentIndex);
    });
}

prevBtn.addEventListener('click', () => {
    currentIndex = (currentIndex - 1 + totalItems) % totalItems;
    updateCarrusel();
});

nextBtn.addEventListener('click', () => {
    currentIndex = (currentIndex + 1) % totalItems;
    updateCarrusel();
});

// Agregar eventos a los indicadores
indicadores.forEach((indicador, index) => {
    indicador.addEventListener('click', () => {
    currentIndex = index;
    updateCarrusel();
    });
});

// Auto-avance del carrusel
setInterval(() => {
    currentIndex = (currentIndex + 1) % totalItems;
    updateCarrusel();
}, 5000);
  