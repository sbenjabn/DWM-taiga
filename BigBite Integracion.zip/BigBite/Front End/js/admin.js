document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('adminForm');
  const errorDiv = document.getElementById('error');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const correo = form.correo.value;
    const clave = form.clave.value;

    // Limpiar mensajes anteriores
    errorDiv.textContent = '';
    
    try {
      // 1. Hacer login
      const loginResponse = await fetch('http://localhost:3000/api/usuarios/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo, clave })
      });

      const loginData = await loginResponse.json();

      if (!loginResponse.ok || !loginData.success) {
        throw new Error(loginData.error || 'Credenciales inválidas');
      }

      // 2. Obtener datos completos del usuario
      const usuarioResponse = await fetch(`http://localhost:3000/api/usuarios/correo/${encodeURIComponent(correo)}`);
      
      if (!usuarioResponse.ok) {
        throw new Error('Error al obtener datos del usuario');
      }

      const usuarioData = await usuarioResponse.json();

      if (usuarioData.success) {
        // Guardar datos del usuario para usar en otras páginas
        localStorage.setItem('usuario', JSON.stringify(usuarioData.usuario));
        localStorage.setItem('token', 'p4r4l3l3p1p3d0'); 
        
        if (usuarioData.usuario.rol != 'administrador'){
            throw new Error('Usuario no autorizado a utilizar módulo administración');
        }
        else{
          if (!usuarioData.usuario.active){
            throw new Error('Su cuenta se encuentra desactivada');
          }
          else{
            window.location.href = 'administracion.html';
          }
        }
      } else {
        throw new Error(usuarioData.error || 'Error al procesar datos del usuario');
      }

    } catch (err) {
      console.error(' Error en login:', err);
      errorDiv.textContent = err.message;
    }
  });
});