document.addEventListener('DOMContentLoaded', () => {
  const contenedor = document.querySelector('.carrusel-contenedor');
  const items = document.querySelectorAll('.carrusel-item');
  let index = 0;

  function mostrarItem(i) {
    contenedor.style.transform = `translateX(-${i * 100}%)`;
  }

  function avanzarCarrusel() {
    index = (index + 1) % items.length;
    mostrarItem(index);
  }

  // Cambia cada 3 segundos
  setInterval(avanzarCarrusel, 3000);

  // Opcional: botones manuales
  document.querySelector('.carrusel-btn.derecha').addEventListener('click', () => {
    avanzarCarrusel();
  });

  document.querySelector('.carrusel-btn.izquierda').addEventListener('click', () => {
    index = (index - 1 + items.length) % items.length;
    mostrarItem(index);
  });
});