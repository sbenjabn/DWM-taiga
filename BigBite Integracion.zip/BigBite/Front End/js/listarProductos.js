async function cargarProductos() {
  try {
    const res = await fetch('/api/productos');
    const data = await res.json();
    const lista = document.getElementById('lista-productos');
    lista.innerHTML = '';

    data.productos.forEach(p => {
      const item = document.createElement('li');
      item.classList.add('producto-item');

      const ingredientes = p.ingredientes?.length
        ? p.ingredientes.join(', ')
        : 'Sin ingredientes';

    item.innerHTML = `
    <img src="${p.url_imagen}" alt="${p.nombre}" class="producto-imagen">
    <div class="producto-detalle">
        <div class="producto-header">
        <strong>${p.nombre}</strong>
        <span class="precio">$${p.precio.toFixed(0)}</span>
        </div>
        <span>${p.descripcion}</span><br>
        <span><em>Ingredientes:</em> ${ingredientes}</span><br>
    </div>
    `;
        lista.appendChild(item);
    });
  } catch (err) {
    console.error('Error al cargar productos:', err);
  }
}

cargarProductos();