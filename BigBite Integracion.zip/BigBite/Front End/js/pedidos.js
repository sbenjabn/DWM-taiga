// Estado del carrito
let carrito = [];
let productos = [];
let categorias = [];
let categoriasMap = {};
let categoriaActual = 'todos';
let todosLosProductos = [];

// Función para cargar TODOS los productos (sin filtro de categoría)
async function cargarTodosLosProductos() {
  try {
    const response = await fetch('/api/productos?page=1&pageSize=1000&onlyActive=true');
    
    if (!response.ok) {
      throw new Error('Error al cargar productos');
    }
    
    const data = await response.json();
    todosLosProductos = data.productos || [];
    
    return true;
    
  } catch (error) {
    console.error(' Error cargando todos los productos:', error);
    return false;
  }
}

// Función para mostrar bienvenida personalizada
function mostrarBienvenidaUsuario() {
  const clienteNombre = localStorage.getItem('cliente_nombre');
  const bienvenidaContainer = document.getElementById('bienvenida-usuario');
  
  if (!clienteNombre || clienteNombre === 'Cliente' || clienteNombre === 'cliente') {
    // Si no hay nombre específico, mostrar bienvenida genérica
    bienvenidaContainer.innerHTML = `
      <span class="bienvenida-usuario">
        <i class="fas fa-smile icono-saludo"></i>
        ¡Qué gusto verte por aquí!
      </span>
    `;
  } else {
    // Mostrar bienvenida personalizada con el nombre
    bienvenidaContainer.innerHTML = `
      <span class="bienvenida-usuario">
        <i class="fas fa-smile-beam icono-saludo"></i>
        ¡Qué gusto verte otra vez, ${clienteNombre}!
      </span>
    `;
  }
  
}

// Función para cargar categorías desde el servidor
async function cargarCategoriasDesdeServidor() {
  try {
    mostrarLoadingCategorias(true);
    
    const response = await fetch('/api/categorias', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    });
    
    if (!response.ok) {
      throw new Error('Error al cargar categorías');
    }
    
    const data = await response.json();
    categorias = data.categorias || [];
    
    if (categorias.length === 0) {
      throw new Error('No se encontraron categorías');
    }
    
    // Crear mapa de categorías por ID
    categoriasMap = {};
    categorias.forEach(categoria => {
      categoriasMap[categoria.id] = categoria;
    });
    
    // Actualizar filtros de categorías
    actualizarFiltrosCategorias();
    mostrarLoadingCategorias(false);
    
    return true;
  } catch (error) {
    console.error('Error cargando categorías:', error);
    mostrarLoadingCategorias(false);
    mostrarErrorCategorias(true);
    return false;
  }
}

// Función para mostrar/ocultar loading de categorías
function mostrarLoadingCategorias(mostrar) {
  const filtrosContainer = document.getElementById('filtros-categorias');
  if (mostrar) {
    filtrosContainer.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Cargando categorías...</div>';
  }
}

// Función para mostrar error de categorías
function mostrarErrorCategorias(mostrar) {
  const filtrosContainer = document.getElementById('filtros-categorias');
  if (mostrar) {
    filtrosContainer.innerHTML = `
      <div class="error">
        <p>Error al cargar categorías</p>
        <button id="retry-categorias" class="agregar-btn" style="margin-top: 1rem;">Reintentar</button>
      </div>
    `;
    
    document.getElementById('retry-categorias').addEventListener('click', cargarCategoriasDesdeServidor);
  }
}

// Función para actualizar los filtros de categorías en la UI
function actualizarFiltrosCategorias() {
  const filtrosContainer = document.getElementById('filtros-categorias');
  filtrosContainer.innerHTML = '';
  
  // Botón "Todos"
  const todosBtn = document.createElement('button');
  todosBtn.className = 'filtro-btn active';
  todosBtn.dataset.categoria = 'todos';
  todosBtn.textContent = 'Todos los Productos';
  todosBtn.addEventListener('click', manejarFiltroCategoria);
  filtrosContainer.appendChild(todosBtn);
  
  // Botones para cada categoría
  categorias.forEach(categoria => {
    const boton = document.createElement('button');
    boton.className = 'filtro-btn';
    boton.dataset.categoria = categoria.id;
    boton.dataset.categoriaInfo = JSON.stringify(categoria);
    boton.textContent = categoria.nombre;
    boton.addEventListener('click', manejarFiltroCategoria);
    filtrosContainer.appendChild(boton);
  });
}

// Función para mostrar información de la categoría seleccionada
function mostrarInfoCategoria(categoriaId) {
  const infoContainer = document.getElementById('categoria-info');
  
  if (categoriaId === 'todos') {
    infoContainer.style.display = 'none';
    return;
  }
  
  const categoria = categoriasMap[categoriaId];
  if (!categoria) {
    infoContainer.style.display = 'none';
    return;
  }
  
  infoContainer.innerHTML = `
    <div class="categoria-info">
      <h3>${categoria.nombre}</h3>
      ${categoria.descripcion ? `<p class="categoria-descripcion">${categoria.descripcion}</p>` : ''}
    </div>
  `;
  infoContainer.style.display = 'block';
}

// Función para manejar el filtrado por categoría
async function manejarFiltroCategoria(e) {
  // Quitar clase active de todos los botones
  document.querySelectorAll('.filtro-btn').forEach(b => {
    b.classList.remove('active');
  });
  
  // Agregar clase active al botón clickeado
  e.target.classList.add('active');
  
  // Obtener ID de categoría
  const categoriaId = e.target.dataset.categoria;
  categoriaActual = categoriaId;
  
  // Mostrar información de la categoría
  mostrarInfoCategoria(categoriaId);
  
  // Cargar productos de la categoría seleccionada
  await cargarProductosPorCategoria(categoriaId);
}

// Función para cargar productos por categoría
async function cargarProductosPorCategoria(categoriaId) {
  try {
    mostrarLoadingProductos(true);
    
    let url = '/api/productos';
    
    if (categoriaId !== 'todos') {
      url += `?categoria=${categoriaId}`;
    }
    
    url += `${categoriaId !== 'todos' ? '&' : '?'}page=1&pageSize=100&onlyActive=true`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    });
    
    if (!response.ok) {
      throw new Error('Error al cargar productos');
    }
    
    const data = await response.json();
    let productosFiltrados = data.productos || [];
    
    // Filtrar solo productos activos
    productosFiltrados = productosFiltrados.filter(producto => producto.active !== false);
    
    // Si no es "todos", filtrar por categoría en el cliente (como respaldo)
    if (categoriaId !== 'todos') {
      productosFiltrados = productosFiltrados.filter(producto => producto.id_categoria === categoriaId);
    }
    
    productos = productosFiltrados; // Solo productos de la categoría actual para mostrar
    mostrarProductosEnGrid();
    mostrarLoadingProductos(false);
    
  } catch (error) {
    console.error('Error cargando productos:', error);
    mostrarErrorProductos(true);
  }
}

// Función para mostrar productos en el grid
function mostrarProductosEnGrid() {
  const productosGrid = document.getElementById('productos-grid');
  
  if (productos.length === 0) {
    productosGrid.innerHTML = `
      <div class="error" style="grid-column: 1 / -1;">
        <p>No hay productos disponibles en esta categoría</p>
      </div>
    `;
    productosGrid.style.display = 'grid';
    return;
  }
  
  productosGrid.innerHTML = '';
  
  productos.forEach(producto => {
    const productoCard = document.createElement('div');
    productoCard.className = 'producto-card';
    productoCard.dataset.categoria = producto.id_categoria;
    productoCard.dataset.id = producto.id;
    
    const sinStock = producto.stock_disponible <= 0;
    const imagen = producto.url_imagen || 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80';
    
    productoCard.innerHTML = `
      <img src="${imagen}" alt="${producto.nombre}" class="producto-img">
      <div class="producto-info">
        <h3 class="producto-nombre">${producto.nombre}</h3>
        <p class="producto-descripcion">${producto.descripcion || 'Delicioso producto preparado con ingredientes de calidad.'}</p>
        <div class="producto-precio">$${producto.precio.toLocaleString()}</div>
        <div class="producto-stock">
          ${sinStock ? 
            '<span style="color: #e74c3c;">Sin stock disponible</span>' : 
            `Stock: ${producto.stock_disponible} unidades`
          }
        </div>
        <div class="producto-acciones">
          <div class="cantidad-control">
            <button class="cantidad-btn disminuir" data-id="${producto.id}" ${sinStock ? 'disabled' : ''}>-</button>
            <input type="number" class="cantidad-input" data-id="${producto.id}" value="1" min="1" max="${producto.stock_disponible}" ${sinStock ? 'disabled' : ''}>
            <button class="cantidad-btn aumentar" data-id="${producto.id}" ${sinStock ? 'disabled' : ''}>+</button>
          </div>
          <button class="agregar-btn" data-id="${producto.id}" ${sinStock ? 'disabled' : ''}>
            ${sinStock ? 'Sin Stock' : 'Agregar'}
          </button>
        </div>
      </div>
    `;
    
    productosGrid.appendChild(productoCard);
  });
  
  productosGrid.style.display = 'grid';
  
  // Agregar event listeners a los botones
  agregarEventListenersProductos();
}

// Función para mostrar/ocultar loading de productos
function mostrarLoadingProductos(mostrar) {
  document.getElementById('loading-products').style.display = mostrar ? 'block' : 'none';
  document.getElementById('productos-grid').style.display = mostrar ? 'none' : 'grid';
  document.getElementById('error-products').style.display = 'none';
}

// Función para mostrar/ocultar error de productos
function mostrarErrorProductos(mostrar) {
  document.getElementById('loading-products').style.display = 'none';
  document.getElementById('productos-grid').style.display = 'none';
  document.getElementById('error-products').style.display = mostrar ? 'block' : 'none';
}

// Función para agregar event listeners a los productos
function agregarEventListenersProductos() {
  document.querySelectorAll('.agregar-btn:not(:disabled)').forEach(btn => {
    btn.addEventListener('click', agregarAlCarrito);
  });
  
  document.querySelectorAll('.cantidad-btn.aumentar:not(:disabled)').forEach(btn => {
    btn.addEventListener('click', aumentarCantidad);
  });
  
  document.querySelectorAll('.cantidad-btn.disminuir:not(:disabled)').forEach(btn => {
    btn.addEventListener('click', disminuirCantidad);
  });
}

// Función para aumentar la cantidad de un producto
function aumentarCantidad(e) {
  const id = e.target.dataset.id;
  const input = document.querySelector(`.cantidad-input[data-id="${id}"]`);
  const max = parseInt(input.max);
  const currentValue = parseInt(input.value);
  
  if (currentValue < max) {
    input.value = currentValue + 1;
  }
}

// Función para disminuir la cantidad de un producto
function disminuirCantidad(e) {
  const id = e.target.dataset.id;
  const input = document.querySelector(`.cantidad-input[data-id="${id}"]`);
  if (parseInt(input.value) > 1) {
    input.value = parseInt(input.value) - 1;
  }
}

// Función para agregar producto al carrito
function agregarAlCarrito(e) {
  const id = e.target.dataset.id;
  const producto = productos.find(p => p.id === id);
  
  if (!producto) return;
  
  const cantidadInput = document.querySelector(`.cantidad-input[data-id="${id}"]`);
  const cantidad = parseInt(cantidadInput.value);
  
  // Verificar stock disponible
  if (cantidad > producto.stock_disponible) {
    mostrarMensaje(`No hay suficiente stock. Solo quedan ${producto.stock_disponible} unidades.`, 'error');
    return;
  }
  
  // Verificar si el producto ya está en el carrito
  const itemExistente = carrito.find(item => item.id === id);
  
  if (itemExistente) {
    const nuevaCantidad = itemExistente.cantidad + cantidad;
    if (nuevaCantidad > producto.stock_disponible) {
      mostrarMensaje(`No puedes agregar más. Stock máximo: ${producto.stock_disponible}`, 'error');
      return;
    }
    itemExistente.cantidad = nuevaCantidad;
  } else {
    carrito.push({
      id: producto.id,
      nombre: producto.nombre,
      precio: producto.precio,
      cantidad: cantidad,
      stock_disponible: producto.stock_disponible,
      imagen: producto.url_imagen || 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
    });
  }
  
  // Actualizar la vista del carrito
  actualizarCarrito();
  
  // Mostrar mensaje de confirmación
  mostrarMensaje(`${producto.nombre} agregado al carrito`);
  
  // Restablecer la cantidad a 1
  cantidadInput.value = 1;
}

// Función para actualizar la vista del carrito
function actualizarCarrito() {
  const carritoVacio = document.getElementById('carrito-vacio');
  const carritoItems = document.getElementById('carrito-items');
  const carritoTotal = document.getElementById('carrito-total');
  const carritoAcciones = document.getElementById('carrito-acciones');
  
  if (carrito.length === 0) {
    carritoVacio.style.display = 'block';
    carritoItems.style.display = 'none';
    carritoTotal.style.display = 'none';
    carritoAcciones.style.display = 'none';
    return;
  }
  
  carritoVacio.style.display = 'none';
  carritoItems.style.display = 'block';
  carritoTotal.style.display = 'block';
  carritoAcciones.style.display = 'flex';
  
  // Actualizar items del carrito
  carritoItems.innerHTML = '';
  let total = 0;
  
  carrito.forEach(item => {
    const subtotal = item.precio * item.cantidad;
    total += subtotal;
    
    const itemElement = document.createElement('div');
    itemElement.className = 'carrito-item';
    itemElement.innerHTML = `
      <img src="${item.imagen}" alt="${item.nombre}" class="carrito-item-imagen">
      <div class="carrito-item-info">
        <div class="carrito-item-nombre">${item.nombre}</div>
        <div class="carrito-item-precio">$${item.precio.toLocaleString()} x ${item.cantidad}</div>
      </div>
      <div class="carrito-item-cantidad">
        <span class="carrito-item-subtotal">$${subtotal.toLocaleString()}</span>
        <button class="carrito-item-eliminar" data-id="${item.id}">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `;
    
    carritoItems.appendChild(itemElement);
  });
  
  // Actualizar total
  document.getElementById('total-precio').textContent = total.toLocaleString();
  
  // Agregar event listeners a los botones de eliminar
  document.querySelectorAll('.carrito-item-eliminar').forEach(btn => {
    btn.addEventListener('click', eliminarDelCarrito);
  });
}

// Función para eliminar producto del carrito
function eliminarDelCarrito(e) {
  const id = e.currentTarget.dataset.id;
  carrito = carrito.filter(item => item.id !== id);
  actualizarCarrito();
  mostrarMensaje('Producto eliminado del carrito');
}

// Función para vaciar el carrito
function vaciarCarrito() {
  carrito = [];
  actualizarCarrito();
  mostrarMensaje('Carrito vaciado');
}

// Función para realizar el pedido (CORREGIDA)
async function realizarPedido() {
  if (carrito.length === 0) return;
  
  try {
    // Verificar stock antes de realizar el pedido - USAR todosLosProductos
    for (const item of carrito) {
      // Buscar en todosLosProductos en lugar de productos
      const producto = todosLosProductos.find(p => p.id === item.id);
      
      if (!producto) {
        console.error(` Producto no encontrado en todosLosProductos: ${item.id}`);
        mostrarMensaje(`Producto ${item.nombre} no encontrado`, 'error');
        return;
      }
      
      if (producto.stock_disponible < item.cantidad) {
        console.error(` Stock insuficiente: ${producto.nombre} (Stock: ${producto.stock_disponible}, Necesario: ${item.cantidad})`);
        mostrarMensaje(`No hay suficiente stock de ${item.nombre}. Disponible: ${producto.stock_disponible}`, 'error');
        return;
      }
    }
    
    // Obtener datos del cliente
    const clienteRut = obtenerClienteRut();
    const clienteNombre = localStorage.getItem('cliente_nombre') || 'Cliente';
    
    // 1. PRIMERO: Crear el pedido maestro usando el formato correcto
    const pedidoData = {
      cliente_id: clienteRut,
      detalles: carrito.map(item => ({
        producto_id: item.id,
        cantidad: item.cantidad,
        precio_unitario: item.precio,
        producto_nombre: item.nombre
      })),
      total: carrito.reduce((sum, item) => sum + (item.precio * item.cantidad), 0)
    };
    
    const pedidoResponse = await fetch('/api/pedidos', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(pedidoData)
    });
    
    if (!pedidoResponse.ok) {
      const errorText = await pedidoResponse.text();
      throw new Error(`Error del servidor: ${pedidoResponse.status} - ${errorText}`);
    }
    
    const pedidoResultado = await pedidoResponse.json();
    
    // OBTENER EL NÚMERO DE PEDIDO DE LA RESPUESTA CORRECTA
    const numPedido = pedidoResultado.numero_pedido;
    
    if (!numPedido) {
      console.error(' No se pudo obtener el número de pedido de la respuesta:', pedidoResultado);
      throw new Error('No se pudo obtener el número de pedido del servidor');
    }
    
    // 2. SEGUNDO: Crear los detalles del pedido en la colección DetallePedidos
    
    // Crear cada detalle del pedido
    const detallesPromises = carrito.map(async (item, index) => {
      const detalleData = {
        num_pedido: numPedido,
        cod_producto: item.id,
        cantidad: item.cantidad
      };
      
      try {
        const detalleResponse = await fetch('/api/detalle-pedidos', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(detalleData)
        });
        
        if (!detalleResponse.ok) {
          const errorText = await detalleResponse.text();
          console.error(` Error en detalle ${index + 1}:`, errorText);
          throw new Error(`Error creando detalle: ${detalleResponse.status} - ${errorText}`);
        }
        
        const detalleResult = await detalleResponse.json();
        return detalleResult;
        
      } catch (error) {
        console.error(` Error en detalle ${index + 1}:`, error);
        throw error;
      }
    });
    
    // Esperar a que todos los detalles se creen
    const detallesResultados = await Promise.all(detallesPromises);
    
    mostrarMensaje(`¡Pedido #${numPedido} realizado con éxito, ${clienteNombre}!`, 'success');
    
    // Vaciar el carrito después del pedido exitoso
    setTimeout(() => {
      carrito = [];
      actualizarCarrito();
      // Recargar productos para actualizar stock (ambas listas)
      cargarTodosLosProductos(); // ← Recargar todos los productos
      cargarProductosPorCategoria(categoriaActual); // ← Recargar categoría actual
    }, 2000);
    
  } catch (error) {
    console.error('Error realizando pedido:', error);
    mostrarMensaje('Error al realizar el pedido: ' + error.message, 'error');
  }
}

// Función para obtener el RUT del cliente
function obtenerClienteRut() {
  const clienteRut = localStorage.getItem('cliente_rut');
  const clienteNombre = localStorage.getItem('cliente_nombre') || 'Cliente';
  
  if (!clienteRut) {
    console.warn(' No se encontró RUT del cliente, usando valor por defecto');
    return '11111111-1'; // RUT por defecto
  }
  
  return clienteRut;
}

// Función para mostrar mensajes temporales
function mostrarMensaje(mensaje, tipo = 'info') {
  const mensajeElement = document.createElement('div');
  mensajeElement.textContent = mensaje;
  mensajeElement.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 1rem 1.5rem;
    background: ${tipo === 'success' ? '#27ae60' : tipo === 'error' ? '#e74c3c' : '#3498db'};
    color: white;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    z-index: 1000;
    transition: opacity 0.3s;
  `;
  
  document.body.appendChild(mensajeElement);
  
  setTimeout(() => {
    mensajeElement.style.opacity = '0';
    setTimeout(() => {
      if (document.body.contains(mensajeElement)) {
        document.body.removeChild(mensajeElement);
      }
    }, 300);
  }, 3000);
}

// Inicializar la página
document.addEventListener('DOMContentLoaded', async () => {
  // Verificar que el usuario esté autenticado
  const autenticado = localStorage.getItem('cliente_autenticado');
  const clienteRut = localStorage.getItem('cliente_rut');
  const clienteNombre = localStorage.getItem('cliente_nombre');
  
  if (autenticado !== 'true' || !clienteRut) {
    console.warn(' Usuario no autenticado o sin RUT, redirigiendo al login');
    mostrarMensaje('Debe iniciar sesión para realizar pedidos', 'error');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 2000);
    return;
  }
  
  // MOSTRAR BIENVENIDA PERSONALIZADA
  mostrarBienvenidaUsuario();
  
  // PRIMERO: Cargar todos los productos
  await cargarTodosLosProductos();
  
  // LUEGO: Cargar categorías y productos por categoría actual
  await cargarCategoriasDesdeServidor();
  
  // Configurar botones del carrito
  document.getElementById('vaciar-carrito').addEventListener('click', vaciarCarrito);
  document.getElementById('realizar-pedido').addEventListener('click', realizarPedido);
  
  // Configurar reintento de carga de productos
  document.getElementById('retry-loading').addEventListener('click', () => {
    cargarProductosPorCategoria(categoriaActual);
  });
});