document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const errorDiv = document.getElementById('error');
  
  // Elementos del registro
  const btnRegistrarse = document.getElementById('btnRegistrarse');
  const registroModal = document.getElementById('registroModal');
  const modalCloseRegistro = document.getElementById('modalCloseRegistro');
  const btnCancelarRegistro = document.getElementById('btnCancelarRegistro');
  const btnConfirmarRegistro = document.getElementById('btnConfirmarRegistro');
  const registroForm = document.getElementById('registroForm');
  const registroErrorDiv = document.getElementById('registroError');

  // Abrir modal de registro
  btnRegistrarse.addEventListener('click', () => {
    registroModal.classList.add('active');
    registroForm.reset();
    registroErrorDiv.textContent = '';
  });

  // Cerrar modal de registro
  function cerrarModalRegistro() {
    registroModal.classList.remove('active');
  }

  modalCloseRegistro.addEventListener('click', cerrarModalRegistro);
  btnCancelarRegistro.addEventListener('click', cerrarModalRegistro);

  // Validar contraseñas coincidan
  registroForm.addEventListener('input', () => {
    const clave = document.getElementById('registroClave').value;
    const confirmarClave = document.getElementById('registroConfirmarClave').value;
    
    if (confirmarClave && clave !== confirmarClave) {
      document.getElementById('registroConfirmarClave').style.borderColor = '#dc3545';
    } else {
      document.getElementById('registroConfirmarClave').style.borderColor = '#28a745';
    }
  });

  // Manejar registro de nuevo cliente
  btnConfirmarRegistro.addEventListener('click', async () => {
    const formData = new FormData(registroForm);
    const datos = Object.fromEntries(formData.entries());
    
    // Validaciones
    if (datos.clave !== datos.confirmarClave) {
      registroErrorDiv.textContent = 'Las contraseñas no coinciden';
      return;
    }

    if (datos.clave.length < 6) {
      registroErrorDiv.textContent = 'La contraseña debe tener al menos 6 caracteres';
      return;
    }

    if (!document.getElementById('acceptTerms').checked) {
      registroErrorDiv.textContent = 'Debes aceptar los términos y condiciones';
      return;
    }

    try {
      registroErrorDiv.textContent = '';
      btnConfirmarRegistro.disabled = true;
      btnConfirmarRegistro.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creando cuenta...';

      // Preparar datos para enviar (remover confirmarClave)
      const { confirmarClave, ...datosEnvio } = datos;
      
      // Convertir edad a número si existe
      if (datosEnvio.edad) {
        datosEnvio.edad = parseInt(datosEnvio.edad);
      }

      // Agregar campos por defecto
      datosEnvio.intentos_fallidos = 0;
      datosEnvio.cuenta_bloqueada = false;
      datosEnvio.active = true;

      const response = await fetch('http://localhost:3000/api/clientes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datosEnvio)
      });

      const result = await response.json();
      if (response.ok && result.success) {
        // Registro exitoso
        registroErrorDiv.textContent = '';
        registroErrorDiv.className = 'success';
        registroErrorDiv.innerHTML = '<i class="fas fa-check-circle"></i> ¡Cuenta creada exitosamente! Redirigiendo...';
        
        // Cerrar modal después de 2 segundos y redirigir
        setTimeout(() => {
          cerrarModalRegistro();
          // Auto-login o redirigir al login
          form.correo.value = datosEnvio.correo;
          form.clave.value = datosEnvio.clave;
          // Opcional: auto-submit el login
          // form.dispatchEvent(new Event('submit'));
        }, 2000);

      } else {
        registroErrorDiv.textContent = result.error || 'Error al crear la cuenta';
      }

    } catch (err) {
      console.error('Error en registro:', err);
      registroErrorDiv.textContent = 'Error de conexión con el servidor';
    } finally {
      btnConfirmarRegistro.disabled = false;
      btnConfirmarRegistro.innerHTML = '<i class="fas fa-user-plus"></i> Crear Cuenta';
    }
  });

  // Login original (tu código existente)
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const correo = form.correo.value;
    const clave = form.clave.value;

    try {
      const response = await fetch('http://localhost:3000/api/clientes/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo, clave })
      });

      const result = await response.json();

      if (response.ok && result.success && result.valido) {
        // Guardar datos COMPLETOS del cliente incluyendo RUT
        if (result.cliente) {
          localStorage.setItem('cliente_id', result.cliente.id || 'usr_' + Date.now());
          localStorage.setItem('cliente_rut', result.cliente.rut || '11111111-1');
          localStorage.setItem('cliente_nombre', result.cliente.nombre || 'Cliente');
          localStorage.setItem('cliente_email', result.cliente.correo || correo);
          localStorage.setItem('cliente_telefono', result.cliente.telefono || '');
          localStorage.setItem('cliente_direccion', result.cliente.direccion || '');
        } else {
          console.warn(' No se recibieron datos completos del cliente');
          localStorage.setItem('cliente_id', 'usr_' + Date.now());
          localStorage.setItem('cliente_rut', '22222222-2');
          localStorage.setItem('cliente_nombre', correo.split('@')[0]);
          localStorage.setItem('cliente_email', correo);
        }
        
        localStorage.setItem('cliente_autenticado', 'true');
        
        setTimeout(() => {
          window.location.href = 'pedidos.html';
        }, 500);
        
      } else {
        errorDiv.textContent = result.error || 'Credenciales inválidas';
      }
    } catch (err) {
      console.error('Error de login:', err);
      errorDiv.textContent = 'Error de conexión con el servidor';
    }
  });
});