// ========== VALIDACIÓN DE ACCESO Y TOKEN ==========

function validarAccesoAdministracion() {
    // Verificar si existe el token
    const token = localStorage.getItem('token');
    const usuario = localStorage.getItem('usuario');
    
    if (!token || token !== 'p4r4l3l3p1p3d0') {
        console.error(' Token inválido o no encontrado');
        mostrarErrorAcceso('Acceso no autorizado. Token inválido.');
        return false;
    }
    
    if (!usuario) {
        console.error(' Información de usuario no encontrada');
        mostrarErrorAcceso('Información de usuario no disponible.');
        return false;
    }
    
    try {
        const usuarioData = JSON.parse(usuario);
        
        // Verificar rol de administrador
        if (usuarioData.rol !== 'administrador') {
            console.error(' Usuario no es administrador. Rol:', usuarioData.rol);
            mostrarErrorAcceso('No tienes permisos para acceder al módulo de administración.');
            return false;
        }
        
        // Verificar si el usuario está activo
        if (!usuarioData.active) {
            console.error(' Usuario inactivo');
            mostrarErrorAcceso('Tu cuenta se encuentra desactivada.');
            return false;
        }
        
        mostrarInformacionUsuario();
     
        // Limpiar el token por seguridad después de validar
        setTimeout(() => {
            localStorage.removeItem('token');
        }, 1000);
        
        return true;
        
    } catch (error) {
        console.error(' Error al parsear datos del usuario:', error);
        mostrarErrorAcceso('Error al validar la información del usuario.');
        return false;
    }
}

function mostrarErrorAcceso(mensaje) {
    // Limpiar localStorage
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    
    // Mostrar mensaje de error
    document.body.innerHTML = `
        <div style="
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: Arial, sans-serif;
        ">
            <div style="
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                text-align: center;
                max-width: 400px;
                width: 90%;
            ">
                <div style="font-size: 4rem; color: #dc3545; margin-bottom: 20px;">
                    ⚠️
                </div>
                <h2 style="color: #333; margin-bottom: 20px;">Acceso Denegado</h2>
                <p style="color: #666; margin-bottom: 30px; line-height: 1.5;">${mensaje}</p>
                <button onclick="volverALogin()" style="
                    background: #667eea;
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 16px;
                    transition: background 0.3s;
                " onmouseover="this.style.background='#5a6fd8'" 
                onmouseout="this.style.background='#667eea'">
                    Volver al Login
                </button>
            </div>
        </div>
    `;
}

function volverALogin() {
    window.location.href = 'admin.html';
}

// ========== MOSTRAR INFORMACIÓN DEL USUARIO EN ENCABEZADO ==========

// ========== MOSTRAR INFORMACIÓN DEL USUARIO EN ENCABEZADO ==========

function mostrarInformacionUsuario() {
    try {
        const usuario = localStorage.getItem('usuario');
        
        if (!usuario) {
            console.warn('No se encontró información del usuario en localStorage');
            return;
        }
        
        const usuarioData = JSON.parse(usuario);
        
        // Actualizar el nombre del usuario
        const userNameElement = document.getElementById('userName');
        if (userNameElement && usuarioData.nombre) {
            userNameElement.textContent = usuarioData.nombre;
        }
        
        // Actualizar el avatar con la primera letra del nombre
        const userAvatarElement = document.getElementById('userAvatar');
        if (userAvatarElement && usuarioData.nombre) {
            const primeraLetra = usuarioData.nombre.charAt(0).toUpperCase();
            userAvatarElement.textContent = primeraLetra;
        }
        
        // Opcional: Mostrar más información en tooltip
        const userInfoElement = document.getElementById('userInfo');
        if (userInfoElement && usuarioData.correo) {
            userInfoElement.title = `${usuarioData.nombre} - ${usuarioData.correo}`;
            
            // Opcional: Agregar menú desplegable con más información
            userInfoElement.innerHTML = `
                <div class="user-avatar" id="userAvatar">${usuarioData.nombre.charAt(0).toUpperCase()}</div>
                <span id="userName">${usuarioData.nombre}</span>
                <div class="user-dropdown">
                    <div class="dropdown-content">
                        <div class="user-email">${usuarioData.correo}</div>
                        <div class="user-rol">${usuarioData.rol}</div>
                        <div class="dropdown-divider"></div>
                        <button onclick="cerrarSesion()" class="logout-btn">
                            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                        </button>
                    </div>
                </div>
            `;
        }
        
    } catch (error) {
        console.error('Error al mostrar información del usuario:', error);
    }
}

//DOM PRINCIPAL

document.addEventListener('DOMContentLoaded', function() {
    
    // Validar acceso antes de cargar cualquier cosa
    if (!validarAccesoAdministracion()) {
        return;
    }
    
    const menuItems = document.querySelectorAll('.menu-item');
    const contentSections = document.querySelectorAll('.content-section');
    const pageTitle = document.getElementById('pageTitle');
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');
    
    // ========== VARIABLES PARA GESTIÓN DE CATEGORÍAS ==========
    const categoriasTableBody = document.getElementById('categoriasTableBody');
    const btnNuevaCategoria = document.getElementById('btnNuevaCategoria');
    const categoriaModal = document.getElementById('categoriaModal');
    const modalTitle = document.getElementById('modalTitle');
    const categoriaForm = document.getElementById('categoriaForm');
    const btnGuardar = document.getElementById('btnGuardar');
    const btnCancelar = document.getElementById('btnCancelar');
    const modalClose = document.getElementById('modalClose');
    const confirmModal = document.getElementById('confirmModal');
    const btnConfirmarEliminar = document.getElementById('btnConfirmarEliminar');
    const btnCancelarEliminar = document.getElementById('btnCancelarEliminar');
    const confirmClose = document.getElementById('confirmClose');
    const alertContainer = document.getElementById('alertContainer');
    
    // Variables de estado
    let categorias = [];
    let categoriaAEliminar = null;
    
    // ========== CONFIGURACIÓN DE ENDPOINTS ==========
    const API_ENDPOINTS = {
        CATEGORIAS: {
            LISTAR: '/api/categorias',
            CREAR: '/api/categorias',
            ACTUALIZAR: '/api/categorias',
            ELIMINAR: '/api/categorias',
            COUNT: '/api/categorias/count'
        },
        PRODUCTOS: {
            COUNT: '/api/productos/count'
        },
        PEDIDOS: {
            COUNT: '/api/pedidos/count',
            COUNT_BY_ESTADO: '/api/pedidos/count-by-estado'
        }
    };

    // ========== FUNCIONALIDADES EXISTENTES ==========
    
    // Navegación entre secciones
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            
            // Actualizar menú activo
            menuItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            
            // Mostrar sección correspondiente
            contentSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === target) {
                    section.classList.add('active');
                    
                    // Actualizar título de página
                    const menuText = this.querySelector('span').textContent;
                    pageTitle.textContent = menuText;
                    
                    // Ejecutar acciones específicas por sección
                    if (target === 'dashboard') {
                        loadDashboardStats(); 
                        
                        const btnActualizarPedidos = document.getElementById('btnActualizarPedidos');
                        if (btnActualizarPedidos) {
                            // Remover event listener anterior para evitar duplicados
                            btnActualizarPedidos.replaceWith(btnActualizarPedidos.cloneNode(true));
                            
                            // Agregar nuevo event listener
                            document.getElementById('btnActualizarPedidos').addEventListener('click', function() {
                                cargarPedidosPendientes();
                                loadPedidosStats(); // También actualizar estadísticas
                            });
                        }
                        
                    } else if (target === 'categorias') {
                        cargarCategorias();
                    } else if (target === 'productos') {
                        cargarProductos();
                    } else if (target === 'permisos') {
                        cargarPermisos();
                    } else if (target === 'roles') {
                        cargarRoles();
                    } else if (target === 'usuarios') {
                        cargarUsuarios();
                    }
                }
            });
            
            // Cerrar sidebar en móviles después de seleccionar
            if (window.innerWidth < 992) {
                sidebar.classList.remove('active');
            }
        });
    });
    
    // Toggle sidebar en móviles
    mobileToggle.addEventListener('click', function() {
        sidebar.classList.toggle('active');
    });
    
    // Cerrar sidebar al hacer clic fuera de él en móviles
    document.addEventListener('click', function(event) {
        if (window.innerWidth < 992 && 
            !sidebar.contains(event.target) && 
            !mobileToggle.contains(event.target) &&
            sidebar.classList.contains('active')) {
            sidebar.classList.remove('active');
        }
    });
    
    // ========== DASHBOARD FUNCTIONS ==========
    
    // Cargar estadísticas del dashboard
    function loadDashboardStats() {
        loadProductCount();
        loadCategoriasCount();
        loadPedidosStats();
        cargarPedidosPendientes();
    }
    
    // Función para obtener el total de productos
    async function loadProductCount() {
        const productCountElement = document.getElementById('total-productos');
        
        if (!productCountElement) {
            console.error('NO se encontró el elemento #total-productos');
            return;
        }
        
        productCountElement.textContent = 'Cargando...';
        
        try {
            const response = await fetch(API_ENDPOINTS.PRODUCTOS.COUNT);
            
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                const total = data.total;
                productCountElement.textContent = total;
                updateProductBadge(total);
            } else {
                throw new Error(data.error);
            }
            
        } catch (error) {
            console.error('Error en productos:', error);
            productCountElement.textContent = 'Error';
            productCountElement.style.color = '#ff4444';
        }
    }

    // Función para obtener el total de categorías
    async function loadCategoriasCount() {
        const categoriasCountElement = document.getElementById('total-categorias');
        
        if (!categoriasCountElement) {
            console.error('NO se encontró el elemento #total-categorias');
            return;
        }
        
        categoriasCountElement.textContent = 'Cargando...';
        
        try {
            const response = await fetch(API_ENDPOINTS.CATEGORIAS.COUNT);
            
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.success) {
                const total = data.total;
                categoriasCountElement.textContent = total;
                updateCategoriasBadge(total);
            } else {
                throw new Error(data.error);
            }
            
        } catch (error) {
            console.error('Error en categorías:', error);
            categoriasCountElement.textContent = 'Error';
            categoriasCountElement.style.color = '#ff4444';
        }
    }
        
    // Actualizar el badge del menú de productos
    function updateProductBadge(total) {
        const productBadge = document.getElementById('menu-badge-productos');
        if (productBadge) {
            productBadge.textContent = total;
        } else {
            console.log('No se encontró el badge del menú productos');
        }
    }

    // Actualizar el badge del menú de categorías
    function updateCategoriasBadge(total) {
        const categoriasBadge = document.getElementById('menu-badge-categorias');
        if (categoriasBadge) {
            categoriasBadge.textContent = total;
        } else {
            console.log('No se encontró el badge del menú categorías');
        }
    }

    // Función para cargar estadísticas de pedidos (YA EXISTE - solo modifícala)
    async function loadPedidosStats() {
        try {
            const [countResponse, estadosResponse] = await Promise.all([
                fetch(API_ENDPOINTS.PEDIDOS.COUNT),
                fetch(API_ENDPOINTS.PEDIDOS.COUNT_BY_ESTADO)
            ]);

            const countData = await countResponse.json();
            const estadosData = await estadosResponse.json();

            if (countData.success) {
                document.getElementById('total-pedidos').textContent = countData.total;
            }

            if (estadosData.success) {
                document.getElementById('pedidos-pendientes').textContent = estadosData.data.pendiente;
                document.getElementById('pedidos-preparacion').textContent = estadosData.data.en_preparacion;
                document.getElementById('pedidos-listos').textContent = estadosData.data.listo;
                document.getElementById('pedidos-camino').textContent = estadosData.data.en_camino;
                document.getElementById('pedidos-entregados').textContent = estadosData.data.entregado;
                
                // NUEVO: Actualizar badge del menú
                actualizarBadgePedidosPendientes();
            }

        } catch (error) {
            console.error('Error cargando stats de pedidos:', error);
        }
    }

    // Función para cargar pedidos pendientes en el dashboard
    async function cargarPedidosPendientes() {
    try {
        const response = await fetch('/api/pedidos/estado/0?page=1&pageSize=10');
        
        if (!response.ok) {
        throw new Error('Error al cargar pedidos pendientes');
        }
        
        const data = await response.json();
        const pedidos = data.pedidos || [];
        
        mostrarPedidosPendientesEnTabla(pedidos);
        
    } catch (error) {
        console.error(' Error cargando pedidos pendientes:', error);
        mostrarPedidosPendientesError();
    }
    }

    // Función para mostrar pedidos pendientes en la tabla
    function mostrarPedidosPendientesEnTabla(pedidos) {
        const tbody = document.getElementById('pedidosPendientesTableBody');
        
        if (pedidos.length === 0) {
            tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 40px; color: #6c757d;">
                <i class="fas fa-check-circle" style="font-size: 2rem; margin-bottom: 10px; display: block; color: #28a745;"></i>
                No hay pedidos pendientes
                </td>
            </tr>
            `;
            return;
        }
        
        tbody.innerHTML = pedidos.map(pedido => {
            // Formatear fecha
            const fecha = pedido.fecha_pedido ? 
                new Date(pedido.fecha_pedido.seconds * 1000).toLocaleDateString('es-CL') : 
                'N/A';
            
            // USAR EL TOTAL DEL PEDIDO - manejar diferentes formatos
            let total = 'N/A';

            if (pedido.total_pedido !== undefined && pedido.total_pedido !== null) {
                // Si viene como número
                const totalNum = typeof pedido.total_pedido === 'string' ? 
                    parseFloat(pedido.total_pedido) : 
                    pedido.total_pedido;
                
                if (!isNaN(totalNum)) {
                    total = `$${totalNum.toLocaleString('es-CL')}`;
                }
            }
            
            // Determinar clase del estado
            let estadoClass = 'status pending';
            let estadoText = 'Pendiente';
            
            return `
            <tr>
                <td>
                    <strong>${pedido.num_pedido || 'N/A'}</strong>
                </td>
                <td>
                    <div class="cliente-info">
                        <div class="cliente-rut">${pedido.rut_cliente || 'N/A'}</div>
                    </div>
                </td>
                <td>${fecha}</td>
                <td>
                    <span class="total-pedido">${total}</span>
                </td>
                <td>
                    <span class="status ${estadoClass}">${estadoText}</span>
                </td>

                <td>
                    <div class="action-buttons">
                        <div class="action-btn view" onclick="verDetallesPedido('${pedido.id}')" title="Ver detalles">
                            <i class="fas fa-eye"></i>
                        </div>
                    </div>
                </td>
                
            </tr>
            `;
        }).join('');
        
    }

    // INICIALIZAR MODAL DETALLE PEDIDO
    function inicializarModalDetallePedido() {
        const modal = document.getElementById('detallePedidoModal');
        const modalClose = document.getElementById('modalCloseDetalle');
        const btnCerrar = document.getElementById('btnCerrarDetalle');
        
        if (modalClose) {
            modalClose.addEventListener('click', cerrarModalDetallePedido);
        }
        
        if (btnCerrar) {
            btnCerrar.addEventListener('click', cerrarModalDetallePedido);
        }
        
        // Cerrar modal al hacer clic fuera
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    cerrarModalDetallePedido();
                }
            });
        }
    }

    function cerrarModalDetallePedido() {
        document.getElementById('detallePedidoModal').classList.remove('active');
    }

    // Función para mostrar el modal con los detalles (VERSIÓN CORREGIDA)
    async function mostrarModalDetallePedido(pedido, detalles) {
        const modal = document.getElementById('detallePedidoModal');
        const pedidoInfo = document.getElementById('pedidoInfo');
        const tbody = document.getElementById('detallePedidoTableBody');
        const totalElement = document.getElementById('totalDetallePedido');
        
        if (!modal || !pedidoInfo || !tbody) {
            console.error(' No se encontraron elementos del modal');
            return;
        }
        
        // 1. Mostrar información general del pedido
        const fecha = pedido.fecha_pedido ? 
            new Date(pedido.fecha_pedido.seconds * 1000).toLocaleString('es-CL') : 
            'N/A';
        
        pedidoInfo.innerHTML = `
            <div class="info-grid">
                <div class="info-item">
                    <label>N° Pedido:</label>
                    <span>${pedido.num_pedido || 'N/A'}</span>
                </div>
                <div class="info-item">
                    <label>Cliente:</label>
                    <span>${pedido.rut_cliente || 'N/A'}</span>
                </div>
                <div class="info-item">
                    <label>Fecha:</label>
                    <span>${fecha}</span>
                </div>
                <div class="info-item">
                    <label>Estado:</label>
                    <span class="status pending">${pedido.estado}</span>
                </div>
                <div class="info-item">
                    <label>Total:</label>
                    <span class="total-pedido">${pedido.total_pedido ? `$${parseFloat(pedido.total_pedido).toLocaleString('es-CL')}` : 'N/A'}</span>
                </div>
            </div>
        `;
        
        // 2. Mostrar detalles del pedido con información del producto
        tbody.innerHTML = '';
        let totalCalculado = 0;
        
        if (detalles.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 20px; color: #6c757d;">
                        No se encontraron detalles para este pedido
                    </td>
                </tr>
            `;
        } else {
            // Mostrar loading mientras se cargan los productos
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 20px;">
                        <i class="fas fa-spinner fa-spin"></i> Cargando información de productos...
                    </td>
                </tr>
            `;
            
            try {
                // Para cada detalle, obtener información del producto por ID
                let detallesHTML = '';
                
                for (const detalle of detalles) {
                    try {
                        // Obtener información del producto usando el ID
                        const productoResponse = await fetch(`/api/productos/${detalle.cod_producto}`);
                        
                        let productoNombre = 'Producto no encontrado';
                        let productoCodigo = detalle.cod_producto || 'N/A';
                        let productoPrecio = 0;
                        
                        if (productoResponse.ok) {
                            const productoData = await productoResponse.json();
                            if (productoData.producto) {
                                productoNombre = productoData.producto.nombre || 'Sin nombre';
                                productoCodigo = productoData.producto.codigo || detalle.cod_producto;
                                productoPrecio = productoData.producto.precio || 0;
                            } else if (productoData.nombre) {
                                productoNombre = productoData.nombre;
                                productoCodigo = productoData.codigo || detalle.cod_producto;
                                productoPrecio = productoData.precio || 0;
                            }
                        } else {
                            console.warn(' No se pudo obtener el producto:', detalle.cod_producto);
                            productoNombre = `Producto ${detalle.cod_producto}`;
                        }
                        
                        const subtotal = productoPrecio * (detalle.cantidad || 0);
                        totalCalculado += subtotal;
                        
                        detallesHTML += `
                            <tr>
                                <td><strong>${productoNombre}</strong></td>
                                <td>${productoCodigo}</td>
                                <td>${detalle.cantidad || 0}</td>
                                <td>$${productoPrecio.toLocaleString('es-CL')}</td>
                                <td><strong>$${subtotal.toLocaleString('es-CL')}</strong></td>
                            </tr>
                        `;
                        
                    } catch (error) {
                        console.error(' Error obteniendo producto:', error);
                        detallesHTML += `
                            <tr>
                                <td>Error cargando producto</td>
                                <td>${detalle.cod_producto || 'N/A'}</td>
                                <td>${detalle.cantidad || 0}</td>
                                <td>N/A</td>
                                <td>N/A</td>
                            </tr>
                        `;
                    }
                }
                
                // Actualizar la tabla con los detalles
                tbody.innerHTML = detallesHTML;
                
            } catch (error) {
                console.error(' Error general cargando productos:', error);
                tbody.innerHTML = `
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 20px; color: #dc3545;">
                            <i class="fas fa-exclamation-triangle"></i><br>
                            Error al cargar los productos
                        </td>
                    </tr>
                `;
            }
        }
        
        // 3. Mostrar total
        totalElement.textContent = `$${totalCalculado.toLocaleString('es-CL')}`;
        
        // 4. Mostrar modal
        modal.classList.add('active');
    }


    // Función para mostrar error en la tabla de pedidos pendientes
    function mostrarPedidosPendientesError() {
    const tbody = document.getElementById('pedidosPendientesTableBody');
    tbody.innerHTML = `
        <tr>
        <td colspan="6" style="text-align: center; padding: 40px; color: #dc3545;">
            <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 10px; display: block;"></i>
            Error al cargar pedidos pendientes
            <br>
            <button class="btn btn-outline" onclick="cargarPedidosPendientes()" style="margin-top: 10px;">
            <i class="fas fa-redo"></i> Reintentar
            </button>
        </td>
        </tr>
    `;
    }

    // Función para ver detalles del pedido
    async function verDetallesPedido(pedidoId) {
        try {
            // 1. Obtener información del pedido maestro
            const pedidoResponse = await fetch(`/api/pedidos/${pedidoId}`);
            if (!pedidoResponse.ok) {
                throw new Error('Error al obtener información del pedido');
            }
            
            const pedidoData = await pedidoResponse.json();
            const pedido = pedidoData.pedido || pedidoData;
            
            // 2. Obtener los detalles del pedido usando el ID del pedido
            const detalleResponse = await fetch(`/api/detalle-pedidos/${pedidoId}`);
            
            if (!detalleResponse.ok) {
                // Si falla, intentar con el número de pedido
                const numPedido = pedido.num_pedido;
                if (numPedido) {
                    const detalleResponse2 = await fetch(`/api/detalle-pedidos/pedido/${numPedido}`);
                    if (detalleResponse2.ok) {
                        const detalleData = await detalleResponse2.json();
                        const detalles = detalleData.detallePedido || detalleData.detalles || detalleData;
                        mostrarModalDetallePedido(pedido, detalles);
                        return;
                    }
                }
                throw new Error('Error al obtener detalles del pedido');
            }
            
            const detalleData = await detalleResponse.json();
            const detalles = detalleData.detallePedido || detalleData.detalles || detalleData;
            
            // 3. Mostrar el modal con la información
            mostrarModalDetallePedido(pedido, detalles);
            
        } catch (error) {
            console.error(' Error obteniendo detalles del pedido:', error);
            mostrarAlerta('Error al cargar los detalles del pedido: ' + error.message, 'error');
        }
    }

    // Asegúrate de que esta función esté disponible globalmente
    window.verDetallesPedido = verDetallesPedido;

    // Función para cambiar estado del pedido (placeholder)
    function cambiarEstadoPedido(pedidoId, nuevoEstado) {
    
    const estados = {
        'preparacion': 'En Preparación',
        'listo': 'Listo',
        'camino': 'En Camino',
        'entregado': 'Entregado'
    };
    
    if (confirm(`¿Cambiar estado del pedido a "${estados[nuevoEstado]}"?`)) {
        // Recargar la lista después del cambio
        setTimeout(() => {
        cargarPedidosPendientes();
        actualizarEstadisticasPedidos(); 
        }, 1000);
    }
    }

    // Función para actualizar badge de pedidos pendientes en el menú
    async function actualizarBadgePedidosPendientes() {
        try {
            const response = await fetch('/api/pedidos/count-by-estado');
            if (response.ok) {
                const data = await response.json();
                const pendientes = data.data?.pendiente || 0;
                
                // Crear o actualizar badge en el ítem del dashboard
                let badge = document.querySelector('.menu-item[data-target="dashboard"] .menu-badge');
                if (!badge && pendientes > 0) {
                    const menuItem = document.querySelector('.menu-item[data-target="dashboard"]');
                    badge = document.createElement('span');
                    badge.className = 'menu-badge';
                    menuItem.appendChild(badge);
                }
                
                if (badge) {
                    badge.textContent = pendientes;
                    badge.style.display = pendientes > 0 ? 'flex' : 'none';
                }
            }
        } catch (error) {
            console.error('Error actualizando badge de pedidos:', error);
        }
    }

    // ========== GESTIÓN DE CATEGORÍAS ==========

    // Inicializar event listeners para categorías
    function inicializarCategorias() {
        // Abrir modal para nueva categoría
        if (btnNuevaCategoria) {
            btnNuevaCategoria.addEventListener('click', function(e) {
                e.preventDefault();
                abrirModalCategoria();
            });
        }

        // Cerrar modal categoría
        if (modalClose) modalClose.addEventListener('click', cerrarModalCategoria);
        if (btnCancelar) btnCancelar.addEventListener('click', cerrarModalCategoria);

        // Cerrar modal confirmación
        if (confirmClose) confirmClose.addEventListener('click', cerrarModalConfirmacion);
        if (btnCancelarEliminar) btnCancelarEliminar.addEventListener('click', cerrarModalConfirmacion);

        // Guardar categoría
        if (btnGuardar) btnGuardar.addEventListener('click', guardarCategoria);

        // Confirmar eliminación
        if (btnConfirmarEliminar) btnConfirmarEliminar.addEventListener('click', eliminarCategoria);

    }

    // Función para cargar categorías desde la API
    async function cargarCategorias() {
        
        if (categoriasTableBody) {
            categoriasTableBody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 20px;">Cargando categorías...</td></tr>';
        }
        
        try {
            const response = await fetch(API_ENDPOINTS.CATEGORIAS.LISTAR, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            
            if (!response.ok) {
                if (response.status === 404 || response.status === 405) {
                    const postResponse = await fetch(API_ENDPOINTS.CATEGORIAS.LISTAR, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({})
                    });
                    
                    if (!postResponse.ok) {
                        throw new Error(`Error HTTP con POST: ${postResponse.status}`);
                    }
                    
                    const result = await postResponse.json();
                    procesarCategorias(result);
                    return;
                }
                throw new Error(`Error HTTP: ${response.status}`);
            }

            const result = await response.json();
            procesarCategorias(result);
            
        } catch (error) {
            console.error('Error al cargar las categorías:', error);
            mostrarAlerta('Error al cargar las categorías: ' + error.message, 'error');
            
            if (categoriasTableBody) {
                categoriasTableBody.innerHTML = `
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 30px; color: #dc3545;">
                            <i class="fas fa-exclamation-triangle"></i><br>
                            Error conectando con el servidor<br>
                            <small>Verifica que la API esté ejecutándose</small>
                        </td>
                    </tr>
                `;
            }
        }
    }

    // Función para procesar la respuesta de categorías
    function procesarCategorias(result) {
        if (result.categorias) {
            categorias = result.categorias;
        } else if (Array.isArray(result)) {
            categorias = result;
        } else if (result.data && Array.isArray(result.data)) {
            categorias = result.data;
        } else {
            categorias = [];
            console.warn('Estructura de respuesta inesperada:', result);
        }
        
        renderizarCategorias();
        actualizarContadorCategorias();
    }

    // Función para renderizar categorías en la tabla
    function renderizarCategorias() {
        if (!categoriasTableBody) {
            console.error('No se encontró el cuerpo de la tabla de categorías');
            return;
        }
        
        categoriasTableBody.innerHTML = '';
        
        if (categorias.length === 0) {
            categoriasTableBody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align: center; padding: 30px;">
                        <div class="empty-state">
                            <i class="fas fa-tags"></i>
                            <h3>No hay categorías registradas</h3>
                            <p>Comienza creando tu primera categoría</p>
                            <button class="btn btn-primary" id="crearPrimeraCategoria">
                                <i class="fas fa-plus"></i> Crear Categoría
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            
            document.getElementById('crearPrimeraCategoria').addEventListener('click', function(e) {
                e.preventDefault();
                abrirModalCategoria();
            });
            
            return;
        }
        
        categorias.forEach(categoria => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${categoria.codigo || 'N/A'}</td>
                <td>${categoria.nombre || 'N/A'}</td>
                <td>${categoria.descripcion || '-'}</td>
                <td>
                    <div class="action-buttons">
                        <div class="action-btn edit" data-id="${categoria.id}" title="Editar categoría">
                            <i class="fas fa-edit"></i>
                        </div>
                        <div class="action-btn delete" data-id="${categoria.id}" title="Eliminar categoría">
                            <i class="fas fa-trash"></i>
                        </div>
                    </div>
                </td>
            `;
            categoriasTableBody.appendChild(tr);
        });
        
        document.querySelectorAll('.action-btn.edit').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                editarCategoria(id);
            });
        });
        
        document.querySelectorAll('.action-btn.delete').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                confirmarEliminacionCategoria(id);
            });
        });
        
    }

    // Función para abrir modal de categoría
    function abrirModalCategoria(categoria = null) {
        if (!categoriaModal) {
            console.error('No se encontró el modal de categoría');
            return;
        }
        
        
        const isModoCreacion = categoria === null || 
                            categoria === undefined || 
                            (typeof categoria === 'object' && Object.keys(categoria).length === 0) ||
                            categoria instanceof PointerEvent;
        
        if (isModoCreacion) {
            modalTitle.textContent = 'Nueva Categoría';
            
            if (categoriaForm) {
                categoriaForm.reset();
            }
            
            const idInput = document.getElementById('categoriaId');
            if (idInput) {
                idInput.value = '';
            }
            
        } else {
            modalTitle.textContent = 'Editar Categoría';
            
            const categoriaId = categoria.id || categoria._id;
            document.getElementById('categoriaId').value = categoriaId;
            document.getElementById('codigo').value = categoria.codigo || '';
            document.getElementById('nombre').value = categoria.nombre || '';
            document.getElementById('descripcion').value = categoria.descripcion || '';
        }
        
        categoriaModal.classList.add('active');
    }

    // Función para cerrar modal de categoría
    function cerrarModalCategoria() {
        if (categoriaModal) {
            categoriaModal.classList.remove('active');
        }
    }

    // Función para guardar categoría
    async function guardarCategoria() {
        const id = document.getElementById('categoriaId').value;
        const codigo = document.getElementById('codigo').value;
        const nombre = document.getElementById('nombre').value;
        const descripcion = document.getElementById('descripcion').value;
        
        const isModoCreacion = modalTitle.textContent === 'Nueva Categoría';
        
        if (!codigo || !nombre) {
            mostrarAlerta('Por favor, completa los campos obligatorios', 'error');
            return;
        }
        
        try {
            let url, method, bodyData;
            
            if (!isModoCreacion && id && id !== 'undefined') {
                url = `${API_ENDPOINTS.CATEGORIAS.ACTUALIZAR}/${id}`;
                method = 'PUT';
                bodyData = { codigo, nombre, descripcion };
            } else {
                url = API_ENDPOINTS.CATEGORIAS.CREAR;
                method = 'POST';
                bodyData = { codigo, nombre, descripcion };
            }
            
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyData)
            });
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Error ${response.status}: ${errorText.substring(0, 100)}`);
            }
            
            const result = await response.json();
            
            if (result.success) {
                mostrarAlerta(
                    isModoCreacion ? '✅ Categoría creada correctamente' : '✅ Categoría actualizada correctamente', 
                    'success'
                );
                
                cerrarModalCategoria();
                cargarCategorias();
                loadCategoriasCount();
            } else {
                throw new Error(result.error || 'Error en la operación');
            }
            
        } catch (error) {
            console.error(' Error al guardar la categoría:', error);
            mostrarAlerta('Error: ' + error.message, 'error');
        }
    }

    // Función para editar categoría
    function editarCategoria(id) {
        
        const categoria = categorias.find(c => {
            return c.id === id || 
                c._id === id ||
                (c.id && c.id.toString() === id) ||
                (c._id && c._id.toString() === id);
        });
        
        if (categoria) {
            abrirModalCategoria(categoria);
        } else {
            console.error(' Categoría no encontrada para editar. ID:', id);
            mostrarAlerta('No se pudo encontrar la categoría para editar', 'error');
        }
    }

    // Función para confirmar eliminación
    function confirmarEliminacionCategoria(id) {
        const categoria = categorias.find(c => 
            c.id === id || c._id === id
        );
        
        const categoriaNombre = categoria ? categoria.nombre : 'esta categoría';
        
        if (confirmModal) {
            const modalBody = confirmModal.querySelector('.modal-body');
            if (modalBody) {
                modalBody.innerHTML = `
                    <div style="text-align: center; padding: 20px;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #dc3545; margin-bottom: 15px;"></i>
                        <h3 style="color: #dc3545; margin-bottom: 15px;">¿Estás seguro?</h3>
                        <p>Vas a eliminar la categoría: <strong>"${categoriaNombre}"</strong></p>
                        <p style="color: #6c757d; font-size: 0.9rem;">Esta acción no se puede deshacer.</p>
                    </div>
                `;
            }
            
            const btnConfirmar = document.getElementById('btnConfirmarEliminar');
            if (btnConfirmar) {
                btnConfirmar.replaceWith(btnConfirmar.cloneNode(true));
                
                document.getElementById('btnConfirmarEliminar').addEventListener('click', function() {
                    eliminarCategoria(id);
                    cerrarModalConfirmacion();
                });
            }
            
            categoriaAEliminar = id;
            confirmModal.classList.add('active');
        } else {
            if (confirm(`¿Estás seguro de que deseas eliminar la categoría "${categoriaNombre}"? Esta acción no se puede deshacer.`)) {
                eliminarCategoria(id);
            }
        }
    }

    // Función para cerrar modal de confirmación
    function cerrarModalConfirmacion() {
        if (confirmModal) {
            confirmModal.classList.remove('active');
        }
        categoriaAEliminar = null;
    }

    // Función para eliminar categoría
    async function eliminarCategoria(id) {
        
        if (!id) {
            console.error(' ID inválido para eliminar');
            mostrarAlerta('Error: ID de categoría inválido', 'error');
            return;
        }
        
        try {
            const url = `${API_ENDPOINTS.CATEGORIAS.ELIMINAR}/${id}`;
            const response = await fetch(url, {
                method: 'DELETE',
                headers: { 
                    'Content-Type': 'application/json' 
                }
            });
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error(' Error response:', errorText);
                
                try {
                    const errorData = JSON.parse(errorText);
                    throw new Error(errorData.error || `Error HTTP: ${response.status}`);
                } catch (e) {
                    throw new Error(`Error ${response.status}: ${errorText.substring(0, 100)}`);
                }
            }
            
            const result = await response.json();
            
            if (result.success && result.ok) {
                mostrarAlerta('✅ Categoría eliminada correctamente', 'success');
                cargarCategorias();
                loadCategoriasCount();
            } else {
                throw new Error(result.error || 'No se pudo eliminar la categoría');
            }
            
        } catch (error) {
            console.error(' Error al eliminar la categoría:', error);
            mostrarAlerta('Error al eliminar la categoría: ' + error.message, 'error');
        }
    }

    // Función para mostrar alertas
    function mostrarAlerta(mensaje, tipo) {
        if (!alertContainer) {
            return;
        }
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${tipo === 'success' ? 'success' : 'error'}`;
        alert.innerHTML = `
            <i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            ${mensaje}
        `;
        
        alertContainer.innerHTML = '';
        alertContainer.appendChild(alert);
        
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 5000);
    }

    // Función para actualizar contador de categorías
    function actualizarContadorCategorias() {
        const categoriasCount = document.getElementById('categoriasCount');
        if (categoriasCount) {
            categoriasCount.textContent = categorias.length;
        }
    }

    // ========== INICIALIZACIÓN ==========

    // Inicializar funcionalidades de categorías
    inicializarCategorias();
    inicializarModalDetallePedido();
    
    // Cargar estadísticas automáticamente si el dashboard está activo al inicio
    const activeSection = document.querySelector('.content-section.active');
    
    if (activeSection && activeSection.id === 'dashboard') {
        setTimeout(() => loadDashboardStats(), 100);
    }
    
    if (activeSection && activeSection.id === 'categorias') {
        setTimeout(() => cargarCategorias(), 100);
    }
    
    // Actualización automática cada 30 segundos
    setInterval(() => {
        const dashboardSection = document.getElementById('dashboard');
        if (dashboardSection && dashboardSection.classList.contains('active')) {
            loadProductCount();
            loadCategoriasCount();
            loadPedidosStats();
            cargarPedidosPendientes();
        }
        
        const categoriasSection = document.getElementById('categorias');
        if (categoriasSection && categoriasSection.classList.contains('active')) {
            cargarCategorias();
        }
        const productosSection = document.getElementById('productos');
        if (productosSection && productosSection.classList.contains('active')) {
            cargarProductos();
        }
        
        const permisosSection = document.getElementById('permisos');
        if (permisosSection && permisosSection.classList.contains('active')) {
            cargarPermisos();
        }
        
        const rolesSection = document.getElementById('roles');
        if (rolesSection && rolesSection.classList.contains('active')) {
            cargarRoles();
        }
        
        const usuariosSection = document.getElementById('usuarios');
        if (usuariosSection && usuariosSection.classList.contains('active')) {
            cargarUsuarios();
        }
    }, 30000);

    const btnActualizarPedidos = document.getElementById('btnActualizarPedidos');
    if (btnActualizarPedidos) {
        btnActualizarPedidos.addEventListener('click', function() {
            cargarPedidosPendientes();
            loadPedidosStats();
        });
    }
});

//*****************************************************************/
// ========== CONFIGURACIÓN DE PRODUCTOS ==========
const API_ENDPOINTS_PRODUCTOS = {
    PRODUCTOS: {
        LISTAR: '/api/productos',
        CREAR: '/api/productos',
        ACTUALIZAR: '/api/productos',
        ELIMINAR: '/api/productos',
        COUNT: '/api/productos/count'
    },
    CATEGORIAS: {
        LISTAR: '/api/categorias'
    }
};

// Variables de estado para productos
let productos = [];
let categoriasProductos = [];
let ingredientes = [];
let productoAEliminar = null;

// ========== FUNCIONES PARA PRODUCTOS ==========

// Función para actualizar contador de productos
async function loadProductCount() {
    const productCountElement = document.getElementById('total-productos');
    
    if (!productCountElement) {
        console.error(' NO se encontró el elemento #total-productos');
        return;
    }
    
    try {
        const response = await fetch(API_ENDPOINTS_PRODUCTOS.PRODUCTOS.COUNT);
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            const total = data.total;
            productCountElement.textContent = total;
            
            // Actualizar badge del menú
            const productBadge = document.getElementById('menu-badge-productos');
            if (productBadge) {
                productBadge.textContent = total;
            }
        } else {
            throw new Error(data.error);
        }
        
    } catch (error) {
        console.error(' Error en productos:', error);
        productCountElement.textContent = 'Error';
        productCountElement.style.color = '#ff4444';
    }
}

function updateProductBadge(total) {
    const productBadge = document.getElementById('menu-badge-productos');
    if (productBadge) {
        productBadge.textContent = total;
    } else {
        console.log('No se encontró el badge del menú productos');
    }
}

// ========== INICIALIZACIÓN DE PRODUCTOS ==========
function inicializarProductos() {
    const btnNuevoProducto = document.getElementById('btnNuevoProducto');
    const productoModal = document.getElementById('productoModal');
    const modalCloseProducto = document.getElementById('modalCloseProducto');
    const btnCancelarProducto = document.getElementById('btnCancelarProducto');
    const btnGuardarProducto = document.getElementById('btnGuardarProducto');
    const btnAgregarIngrediente = document.getElementById('btnAgregarIngrediente');

    const confirmModalProducto = document.getElementById('confirmModalProducto');
    const confirmCloseProducto = document.getElementById('confirmCloseProducto');
    const btnCancelarEliminarProducto = document.getElementById('btnCancelarEliminarProducto');
    const btnConfirmarEliminarProducto = document.getElementById('btnConfirmarEliminarProducto');

    if (btnNuevoProducto) {
        btnNuevoProducto.addEventListener('click', () => {
            abrirModalProducto();
        });
    }

    if (modalCloseProducto) modalCloseProducto.addEventListener('click', cerrarModalProducto);
    if (btnCancelarProducto) btnCancelarProducto.addEventListener('click', cerrarModalProducto);
    if (btnGuardarProducto) btnGuardarProducto.addEventListener('click', guardarProducto);
    
    if (btnAgregarIngrediente) {
        btnAgregarIngrediente.addEventListener('click', agregarIngrediente);
    }

    const inputIngrediente = document.getElementById('nuevoIngrediente');
    if (inputIngrediente) {
        inputIngrediente.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault(); // Evita cualquier comportamiento por defecto
                agregarIngrediente(); // Llama exactamente la misma función que el botón
            }
        });
    }

    if (confirmCloseProducto) confirmCloseProducto.addEventListener('click', cerrarModalConfirmacionProducto);
    if (btnCancelarEliminarProducto) btnCancelarEliminarProducto.addEventListener('click', cerrarModalConfirmacionProducto);
    if (btnConfirmarEliminarProducto) btnConfirmarEliminarProducto.addEventListener('click', eliminarProductoConfirmado);

}

// ========== FUNCIONES DE INGREDIENTES ==========
function agregarIngrediente() {
    const input = document.getElementById('nuevoIngrediente');
    const ingrediente = input.value.trim();
    
    if (ingrediente && !ingredientes.includes(ingrediente)) {
        ingredientes.push(ingrediente);
        actualizarListaIngredientes();
        input.value = '';
        input.focus();
    }
}

function eliminarIngrediente(ingrediente) {
    ingredientes = ingredientes.filter(i => i !== ingrediente);
    actualizarListaIngredientes();
}

function actualizarListaIngredientes() {
    const lista = document.getElementById('listaIngredientes');
    if (lista) {
        lista.innerHTML = ingredientes.map(ingrediente => `
            <div class="ingrediente-tag">
                ${ingrediente}
                <button type="button" class="eliminar" onclick="eliminarIngrediente('${ingrediente}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');
    }
}

function limpiarIngredientes() {
    ingredientes = [];
    actualizarListaIngredientes();
}

// ========== FUNCIONES PRINCIPALES DE PRODUCTOS ==========
async function cargarProductos() {
    const productosTableBody = document.getElementById('productosTableBody');
    if (productosTableBody) {
        productosTableBody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px;">Cargando productos...</td></tr>';
    }
    
    try {
        if (categoriasProductos.length === 0) {
            await cargarCategoriasParaCombobox();
        } else {
            console.log('Categorías ya cargadas:', categoriasProductos.length);
        }
        
        const response = await fetch(API_ENDPOINTS_PRODUCTOS.PRODUCTOS.LISTAR);
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        
        productos = result.productos || [];
        renderizarProductos();
        
    } catch (error) {
        console.error(' Error al cargar productos:', error);
        mostrarAlertaProductos('Error al cargar los productos: ' + error.message, 'error');
    }
}

// Función para cargar sección de pedidos
function cargarSeccion(seccion) {
    
    // Encontrar el elemento del menú correspondiente
    const menuItem = document.querySelector(`.menu-item[data-target="${seccion}"]`);
    if (menuItem) {
        menuItem.click(); // Simular click en el menú
    } else {
        console.error('No se encontró la sección:', seccion);
    }
}

async function cargarCategoriasParaCombobox() {
    
    if (categoriasProductos.length > 0) {
        return;
    }
    
    try {
        const response = await fetch(API_ENDPOINTS_PRODUCTOS.CATEGORIAS.LISTAR);
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.categorias) {
            categoriasProductos = result.categorias;
        } else if (Array.isArray(result)) {
            categoriasProductos = result;
        } else if (result.data && Array.isArray(result.data)) {
            categoriasProductos = result.data;
        } else {
            categoriasProductos = [];
            console.warn('Estructura de respuesta inesperada:', result);
        }
        
        actualizarComboboxCategorias();
        
    } catch (error) {
        console.error(' Error al cargar categorías para combobox:', error);
        categoriasProductos = [];
    }
}

function actualizarComboboxCategorias() {
    const select = document.getElementById('productoCategoria');
    
    if (!select) {
        console.error(' No se encontró el elemento productoCategoria');
        return;
    }
    
    if (categoriasProductos.length === 0) {
        console.warn('No hay categorías para mostrar');
        select.innerHTML = '<option value="">No hay categorías disponibles</option>';
        return;
    }
    
    select.innerHTML = '<option value="">Seleccionar categoría...</option>';
    
    categoriasProductos.forEach(categoria => {
        const id = categoria.id || categoria._id;
        const nombre = categoria.nombre || 'Sin nombre';
        const codigo = categoria.codigo || 'Sin código';
        
        const option = document.createElement('option');
        option.value = id;
        option.textContent = `${nombre} (${codigo})`;
        select.appendChild(option);
    });
    
}

function renderizarProductos() {
    const productosTableBody = document.getElementById('productosTableBody');
    if (!productosTableBody) return;
    
    productosTableBody.innerHTML = '';
    
    if (productos.length === 0) {
        productosTableBody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 30px;">
                    <div class="empty-state">
                        <i class="fas fa-hamburger"></i>
                        <h3>No hay productos registrados</h3>
                        <p>Comienza creando tu primer producto</p>
                        <button class="btn btn-primary" id="crearPrimerProducto">
                            <i class="fas fa-plus"></i> Crear Producto
                        </button>
                    </div>
                </td>
            </tr>
        `;
        
        document.getElementById('crearPrimerProducto').addEventListener('click', (e) => {
            e.preventDefault();
            abrirModalProducto();
        });
        return;
    }
    
    productos.forEach(producto => {
        const categoriaNombre = obtenerNombreCategoria(producto.id_categoria);
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${producto.codigo || 'N/A'}</td>
            <td>${producto.nombre || 'N/A'}</td>
            <td>$${producto.precio?.toFixed(2) || '0.00'}</td>
            <td class="categoria-cell" data-categoria-id="${producto.id_categoria}">
                ${categoriaNombre || 'Cargando...'}
            </td>
            <td>${producto.stock_disponible || 0}</td>
            <td><span class="status ${producto.active ? 'active' : 'inactive'}">${producto.active ? 'Activo' : 'Inactivo'}</span></td>
            <td>
                <div class="action-buttons">
                    <div class="action-btn edit" data-id="${producto.id}" title="Editar producto">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="action-btn delete" data-id="${producto.id}" title="Eliminar producto">
                        <i class="fas fa-trash"></i>
                    </div>
                </div>
            </td>
        `;
        productosTableBody.appendChild(tr);
    });
    
    document.querySelectorAll('.action-btn.edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            editarProducto(id);
        });
    });
    
    document.querySelectorAll('.action-btn.delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            confirmarEliminacionProducto(id);
        });
    });
}

function obtenerNombreCategoria(idCategoria) {
    if (!idCategoria) return 'N/A';
    
    const categoria = categoriasProductos.find(cat => 
        (cat.id === idCategoria) || 
        (cat._id === idCategoria) ||
        (cat.id && cat.id.toString() === idCategoria) ||
        (cat._id && cat._id.toString() === idCategoria)
    );
    
    return categoria ? categoria.nombre : null;
}

function asegurarCategoriasCargadas() {
    return new Promise(async (resolve) => {
        if (categoriasProductos.length === 0) {
            await cargarCategoriasParaCombobox();
        }
        resolve();
    });
}

// ========== MODAL Y FORMULARIO DE PRODUCTOS ==========
async function abrirModalProducto(producto = null) {
    await asegurarCategoriasCargadas();
    
    const modal = document.getElementById('productoModal');
    const modalTitle = document.getElementById('modalTitleProducto');
    
    if (!modal || !modalTitle) {
        console.error(' No se pudo encontrar el modal o su título');
        return;
    }
    
    if (producto && producto.id) {
        modalTitle.textContent = 'Editar Producto';
        setValueIfExists('productoId', producto.id);
        setValueIfExists('productoCodigo', producto.codigo);
        setValueIfExists('productoNombre', producto.nombre);
        setValueIfExists('productoDescripcion', producto.descripcion);
        setValueIfExists('productoPrecio', producto.precio);
        setValueIfExists('productoStock', producto.stock_disponible);
        setValueIfExists('productoUrlImagen', producto.url_imagen);
        
        const categoriaSelect = document.getElementById('productoCategoria');
        if (categoriaSelect) {
            categoriaSelect.value = producto.id_categoria || '';
        }
        
        const activoCheckbox = document.getElementById('activo');
        if (activoCheckbox) {
            activoCheckbox.checked = producto.active !== false;
        }
        
        ingredientes = producto.ingredientes || [];
        actualizarListaIngredientes();
        
    } else {
        modalTitle.textContent = 'Nuevo Producto';
        const productoForm = document.getElementById('productoForm');
        if (productoForm) {
            productoForm.reset();
        }
        
        setValueIfExists('productoId', '');
        
        const activoCheckbox = document.getElementById('activo');
        if (activoCheckbox) {
            activoCheckbox.checked = true;
        }
        
        limpiarIngredientes();
    }
    
    modal.classList.add('active');
}

function setValueIfExists(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        element.value = value || '';
    } else {
        console.error(` No se encontró el elemento: ${elementId}`);
    }
}

function cerrarModalProducto() {
    document.getElementById('productoModal').classList.remove('active');
}

// ========== GUARDAR PRODUCTO ==========
async function guardarProducto() {
    const id = document.getElementById('productoId').value;
    const codigo = document.getElementById('productoCodigo').value;
    const nombre = document.getElementById('productoNombre').value;
    const descripcion = document.getElementById('productoDescripcion').value;
    const precioInput = document.getElementById('productoPrecio').value;
    const id_categoria = document.getElementById('productoCategoria').value;
    const stockInput = document.getElementById('productoStock').value;
    const url_imagen = document.getElementById('productoUrlImagen').value;
    const active = document.getElementById('activo').checked;

    if (!codigo || !nombre || !id_categoria) {
        mostrarAlertaProductos('Por favor, completa los campos: Código, Nombre y Categoría', 'error');
        return;
    }
    
    const precio = parseFloat(precioInput);
    if (isNaN(precio) || precio < 0) {
        mostrarAlertaProductos('El precio debe ser un número válido y no negativo', 'error');
        return;
    }
    
    let stock_disponible = 0;
    if (stockInput !== '' && !isNaN(parseFloat(stockInput))) {
        stock_disponible = parseFloat(stockInput);
        if (stock_disponible < 0) {
            mostrarAlertaProductos('El stock no puede ser negativo', 'error');
            return;
        }
    }
    
    try {
        const bodyData = {
            codigo: codigo.trim(),
            nombre: nombre.trim(),
            descripcion: (descripcion || '').trim(),
            precio: precio,
            id_categoria: id_categoria,
            ingredientes: ingredientes,
            stock_disponible: stock_disponible,
            url_imagen: (url_imagen || '').trim(),
            active: active
        };
        
        let url, method;
        
        if (id) {
            url = `${API_ENDPOINTS_PRODUCTOS.PRODUCTOS.ACTUALIZAR}/${id}`;
            method = 'PUT';
            bodyData.id = id;
        } else {
            url = API_ENDPOINTS_PRODUCTOS.PRODUCTOS.CREAR;
            method = 'POST';
        }
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData)
        });
        
        if (!response.ok) {
            let errorMessage = `Error HTTP: ${response.status}`;
            try {
                const errorText = await response.text();
                console.error(' Error response text:', errorText);
                
                try {
                    const errorData = JSON.parse(errorText);
                    errorMessage = errorData.error || errorData.message || errorText;
                } catch {
                    errorMessage = errorText || `Error ${response.status}`;
                }
            } catch (e) {
                errorMessage = `Error ${response.status}: No se pudo leer la respuesta`;
            }
            throw new Error(errorMessage);
        }
        
        const result = await response.json();
        mostrarAlertaProductos(
            id ? '✅ Producto actualizado correctamente' : '✅ Producto creado correctamente', 
            'success'
        );
        
        cerrarModalProducto();
        await cargarProductos();
        await loadProductCount();
        
    } catch (error) {
        console.error(' Error completo al guardar producto:', error);
        mostrarAlertaProductos('Error al guardar producto: ' + error.message, 'error');
    }
}

// ========== EDITAR PRODUCTO ==========
async function editarProducto(id) {
    if (!id) {
        console.error(' ID inválido recibido en editarProducto');
        mostrarAlertaProductos('Error: ID de producto inválido', 'error');
        return;
    }
    
    const producto = productos.find(p => {
        return p.id === id || 
               p.id?.toString() === id ||
               p._id === id ||
               p._id?.toString() === id;
    });
    
    if (producto) {
        await abrirModalProducto(producto);
    } else {
        console.error(' Producto no encontrado para editar. ID:', id);
        mostrarAlertaProductos('No se pudo encontrar el producto para editar', 'error');
    }
}

// ========== ELIMINAR PRODUCTO ==========
function cerrarModalConfirmacionProducto() {
    const confirmModal = document.getElementById('confirmModalProducto');
    if (confirmModal) {
        confirmModal.classList.remove('active');
    }
    productoAEliminar = null;
}

async function eliminarProductoConfirmado() {
    const id = productoAEliminar;
    
    if (!id) {
        console.error(' No hay producto seleccionado para eliminar');
        return;
    }
    
    
    try {
        const url = `${API_ENDPOINTS_PRODUCTOS.PRODUCTOS.ELIMINAR}/${id}`;
        const response = await fetch(url, { 
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(' Error response:', errorText);
            throw new Error(`Error ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
       
        if (result.success) {
            mostrarAlertaProductos('✅ Producto eliminado correctamente', 'success');
            cerrarModalConfirmacionProducto();
            
            await cargarProductos();
            await loadProductCount();
            
        } else {
            throw new Error(result.error || 'No se pudo eliminar el producto');
        }
        
    } catch (error) {
        console.error(' Error al eliminar el producto:', error);
        mostrarAlertaProductos('Error al eliminar el producto: ' + error.message, 'error');
    }
}

function confirmarEliminacionProducto(id) {
    
    const producto = productos.find(p => p.id === id);
    
    if (!producto) {
        console.error(' Producto no encontrado para eliminar');
        mostrarAlertaProductos('Error: Producto no encontrado', 'error');
        return;
    }
    
    const productoNombre = producto.nombre || 'este producto';
    
    const confirmModal = document.getElementById('confirmModalProducto');
    const productoNombreElement = document.getElementById('productoNombreEliminar');
    
    if (confirmModal && productoNombreElement) {
        productoNombreElement.textContent = `"${productoNombre}"`;
        
        const btnConfirmar = document.getElementById('btnConfirmarEliminarProducto');
        if (btnConfirmar) {
            btnConfirmar.replaceWith(btnConfirmar.cloneNode(true));
            
            document.getElementById('btnConfirmarEliminarProducto').addEventListener('click', function() {
                eliminarProductoConfirmado(id);
            });
        }
        
        productoAEliminar = id;
        confirmModal.classList.add('active');
    } else {
        console.error(' No se pudo encontrar el modal de confirmación');
        if (confirm(`¿Estás seguro de que deseas eliminar el producto "${productoNombre}"? Esta acción no se puede deshacer.`)) {
            eliminarProducto(id);
        }
    }
}

async function eliminarProducto(id) {
    try {
        const url = `${API_ENDPOINTS_PRODUCTOS.PRODUCTOS.ELIMINAR}/${id}`;
        const response = await fetch(url, { method: 'DELETE' });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Error HTTP: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            mostrarAlertaProductos('✅ Producto eliminado correctamente', 'success');
            cargarProductos();
        } else {
            throw new Error('No se pudo eliminar el producto');
        }
        
    } catch (error) {
        console.error(' Error al eliminar producto:', error);
        mostrarAlertaProductos('Error al eliminar producto: ' + error.message, 'error');
    }
}

// ========== ALERTAS ==========
function mostrarAlertaProductos(mensaje, tipo) {
    const alertContainer = document.getElementById('alertContainerProductos');
    if (!alertContainer) return;
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${tipo === 'success' ? 'success' : 'error'}`;
    alert.innerHTML = `
        <i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${mensaje}
    `;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alert);
    
    setTimeout(() => alert.remove(), 5000);
}

// ========== INTEGRACIÓN CON NAVEGACIÓN ==========
function configurarNavegacionProductos() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            if (target === 'productos') {
                cargarCategoriasParaCombobox().then(() => {
                    cargarProductos();
                }).catch(error => {
                    console.error(' Error cargando categorías:', error);
                    cargarProductos();
                });
            }
        });
    });
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    inicializarProductos();
    configurarNavegacionProductos();
});

//*****************************************************************/
// ========== CONFIGURACIÓN DE PERMISOS ==========
const API_ENDPOINTS_PERMISOS = {
    PERMISOS: {
        LISTAR: '/api/permisos',
        CREAR: '/api/permisos',
        ACTUALIZAR: '/api/permisos',
        ELIMINAR: '/api/permisos'
    }
};

// Variables de estado para permisos
let permisos = [];
let permisoAEliminar = null;

// ========== INICIALIZACIÓN DE PERMISOS ==========
function inicializarPermisos() {
    const btnNuevoPermiso = document.getElementById('btnNuevoPermiso');
    const permisoModal = document.getElementById('permisoModal');
    const modalClosePermiso = document.getElementById('modalClosePermiso');
    const btnCancelarPermiso = document.getElementById('btnCancelarPermiso');
    const btnGuardarPermiso = document.getElementById('btnGuardarPermiso');

    const confirmModalPermiso = document.getElementById('confirmModalPermiso');
    const confirmClosePermiso = document.getElementById('confirmClosePermiso');
    const btnCancelarEliminarPermiso = document.getElementById('btnCancelarEliminarPermiso');
    const btnConfirmarEliminarPermiso = document.getElementById('btnConfirmarEliminarPermiso');

    // Event Listeners para el modal de permiso
    if (btnNuevoPermiso) {
        btnNuevoPermiso.addEventListener('click', () => {
            abrirModalPermiso();
        });
    }

    if (modalClosePermiso) modalClosePermiso.addEventListener('click', cerrarModalPermiso);
    if (btnCancelarPermiso) btnCancelarPermiso.addEventListener('click', cerrarModalPermiso);
    if (btnGuardarPermiso) btnGuardarPermiso.addEventListener('click', guardarPermiso);

    // Event Listeners para el modal de confirmación
    if (confirmClosePermiso) confirmClosePermiso.addEventListener('click', cerrarModalConfirmacionPermiso);
    if (btnCancelarEliminarPermiso) btnCancelarEliminarPermiso.addEventListener('click', cerrarModalConfirmacionPermiso);
    if (btnConfirmarEliminarPermiso) btnConfirmarEliminarPermiso.addEventListener('click', eliminarPermisoConfirmado);

}

// ========== FUNCIONES PRINCIPALES DE PERMISOS ==========
async function cargarPermisos() {
    const permisosTableBody = document.getElementById('permisosTableBody');
    if (permisosTableBody) {
        permisosTableBody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 20px;">Cargando permisos...</td></tr>';
    }
    
    try {
        const response = await fetch(API_ENDPOINTS_PERMISOS.PERMISOS.LISTAR);
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        permisos = result.permisos || [];
        renderizarPermisos();
        
    } catch (error) {
        console.error(' Error al cargar permisos:', error);
        mostrarAlertaPermisos('Error al cargar los permisos: ' + error.message, 'error');
    }
}

function renderizarPermisos() {
    const permisosTableBody = document.getElementById('permisosTableBody');
    if (!permisosTableBody) return;
    
    permisosTableBody.innerHTML = '';
    
    if (permisos.length === 0) {
        permisosTableBody.innerHTML = `
            <tr>
                <td colspan="4" style="text-align: center; padding: 40px;">
                    <div class="empty-state">
                        <i class="fas fa-key"></i>
                        <h3>No hay permisos registrados</h3>
                        <p>Comienza creando tu primer permiso</p>
                        <button class="btn btn-primary" id="crearPrimerPermiso">
                            <i class="fas fa-plus"></i> Crear Permiso
                        </button>
                    </div>
                </td>
            </tr>
        `;
        
        document.getElementById('crearPrimerPermiso').addEventListener('click', (e) => {
            e.preventDefault();
            abrirModalPermiso();
        });
        return;
    }
    
    permisos.forEach(permiso => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <span class="permiso-codigo">${permiso.codigo || 'N/A'}</span>
            </td>
            <td>${permiso.nombre || 'N/A'}</td>
            <td>${permiso.descripcion || '-'}</td>
            <td>
                <div class="action-buttons">
                    <div class="action-btn edit" data-id="${permiso.id}" title="Editar permiso">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="action-btn delete" data-id="${permiso.id}" title="Eliminar permiso">
                        <i class="fas fa-trash"></i>
                    </div>
                </div>
            </td>
        `;
        permisosTableBody.appendChild(tr);
    });
    
    // Agregar event listeners a los botones
    document.querySelectorAll('.action-btn.edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            editarPermiso(id);
        });
    });
    
    document.querySelectorAll('.action-btn.delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            confirmarEliminacionPermiso(id);
        });
    });
}

// ========== MODAL Y FORMULARIO DE PERMISOS ==========
function abrirModalPermiso(permiso = null) {
    const modal = document.getElementById('permisoModal');
    const modalTitle = document.getElementById('modalTitlePermiso');
    
    if (!modal || !modalTitle) {
        console.error(' No se pudo encontrar el modal o su título');
        return;
    }
    
    if (permiso && permiso.id) {
        // Modo edición
        modalTitle.textContent = 'Editar Permiso';
       
        // Asignar valores
        setValueIfExistsPermiso('permisoId', permiso.id);
        setValueIfExistsPermiso('permisoCodigo', permiso.codigo);
        setValueIfExistsPermiso('permisoNombre', permiso.nombre);
        setValueIfExistsPermiso('permisoDescripcion', permiso.descripcion);
        
    } else {
        // Modo creación
        modalTitle.textContent = 'Nuevo Permiso';
        
        // Limpiar formulario
        const permisoForm = document.getElementById('permisoForm');
        if (permisoForm) {
            permisoForm.reset();
        }
        
        setValueIfExistsPermiso('permisoId', '');
    }
    
    modal.classList.add('active');
}

// Función auxiliar para permisos
function setValueIfExistsPermiso(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        element.value = value || '';
    } else {
        console.error(` No se encontró el elemento: ${elementId}`);
    }
}

function cerrarModalPermiso() {
    document.getElementById('permisoModal').classList.remove('active');
}

// ========== GUARDAR PERMISO ==========
async function guardarPermiso() {
    const id = document.getElementById('permisoId').value;
    const codigo = document.getElementById('permisoCodigo').value;
    const nombre = document.getElementById('permisoNombre').value;
    const descripcion = document.getElementById('permisoDescripcion').value;

    // Validaciones
    if (!codigo || !nombre) {
        mostrarAlertaPermisos('Por favor, completa los campos: Código y Nombre', 'error');
        return;
    }
    
    // Validar formato del código (opcional - más flexible)
    if (!/^[A-Za-z0-9_]+$/.test(codigo)) {
        mostrarAlertaPermisos('El código solo puede contener letras, números y guiones bajos', 'error');
        return;
    }
    
    try {
        const bodyData = {
            codigo: codigo.trim(), // ← QUITAR .toUpperCase() aquí
            nombre: nombre.trim(),
            descripcion: (descripcion || '').trim()
        };
        
        let url, method;
        
        if (id) {
            // Edición
            url = `${API_ENDPOINTS_PERMISOS.PERMISOS.ACTUALIZAR}/${id}`;
            method = 'PUT';
            bodyData.id = id;
        } else {
            // Creación
            url = API_ENDPOINTS_PERMISOS.PERMISOS.CREAR;
            method = 'POST';
        }
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(' Error response:', errorText);
            throw new Error(`Error ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        mostrarAlertaPermisos(
            id ? '✅ Permiso actualizado correctamente' : '✅ Permiso creado correctamente', 
            'success'
        );
        
        cerrarModalPermiso();
        await cargarPermisos();
        
    } catch (error) {
        console.error(' Error al guardar permiso:', error);
        mostrarAlertaPermisos('Error al guardar permiso: ' + error.message, 'error');
    }
}

// ========== EDITAR PERMISO ==========
function editarPermiso(id) {
    
    if (!id) {
        console.error(' ID inválido recibido en editarPermiso');
        mostrarAlertaPermisos('Error: ID de permiso inválido', 'error');
        return;
    }
    
    const permiso = permisos.find(p => p.id === id);
    
    if (permiso) {
        abrirModalPermiso(permiso);
    } else {
        console.error(' Permiso no encontrado para editar. ID:', id);
        mostrarAlertaPermisos('No se pudo encontrar el permiso para editar', 'error');
    }
}

// ========== ELIMINAR PERMISO ==========
function cerrarModalConfirmacionPermiso() {
    const confirmModal = document.getElementById('confirmModalPermiso');
    if (confirmModal) {
        confirmModal.classList.remove('active');
    }
    permisoAEliminar = null;
}

async function eliminarPermisoConfirmado() {
    const id = permisoAEliminar;
    
    if (!id) {
        console.error(' No hay permiso seleccionado para eliminar');
        return;
    }
    
    try {
        const url = `${API_ENDPOINTS_PERMISOS.PERMISOS.ELIMINAR}/${id}`;
        
        const response = await fetch(url, { 
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(' Error response:', errorText);
            throw new Error(`Error ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        if (result.success || result.ok) {
            mostrarAlertaPermisos('✅ Permiso eliminado correctamente', 'success');
            cerrarModalConfirmacionPermiso();
            await cargarPermisos();
        } else {
            throw new Error(result.error || 'No se pudo eliminar el permiso');
        }
        
    } catch (error) {
        console.error(' Error al eliminar el permiso:', error);
        mostrarAlertaPermisos('Error al eliminar el permiso: ' + error.message, 'error');
    }
}

function confirmarEliminacionPermiso(id) {
    const permiso = permisos.find(p => p.id === id);
    
    if (!permiso) {
        console.error(' Permiso no encontrado para eliminar');
        mostrarAlertaPermisos('Error: Permiso no encontrado', 'error');
        return;
    }
    
    const permisoNombre = permiso.nombre || 'este permiso';
    
    const confirmModal = document.getElementById('confirmModalPermiso');
    const permisoNombreElement = document.getElementById('permisoNombreEliminar');
    
    if (confirmModal && permisoNombreElement) {
        permisoNombreElement.textContent = `"${permisoNombre}"`;
        
        const btnConfirmar = document.getElementById('btnConfirmarEliminarPermiso');
        if (btnConfirmar) {
            btnConfirmar.replaceWith(btnConfirmar.cloneNode(true));
            
            document.getElementById('btnConfirmarEliminarPermiso').addEventListener('click', function() {
                eliminarPermisoConfirmado(id);
            });
        }
        
        permisoAEliminar = id;
        confirmModal.classList.add('active');
        
    } else {
        console.error(' No se pudo encontrar el modal de confirmación');
        if (confirm(`¿Estás seguro de que deseas eliminar el permiso "${permisoNombre}"? Esta acción no se puede deshacer.`)) {
            eliminarPermiso(id);
        }
    }
}

async function eliminarPermiso(id) {
    try {
        const url = `${API_ENDPOINTS_PERMISOS.PERMISOS.ELIMINAR}/${id}`;
        const response = await fetch(url, { method: 'DELETE' });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Error HTTP: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success || result.ok) {
            mostrarAlertaPermisos('✅ Permiso eliminado correctamente', 'success');
            cargarPermisos();
        } else {
            throw new Error('No se pudo eliminar el permiso');
        }
        
    } catch (error) {
        console.error(' Error al eliminar permiso:', error);
        mostrarAlertaPermisos('Error al eliminar permiso: ' + error.message, 'error');
    }
}

// ========== ALERTAS PARA PERMISOS ==========
function mostrarAlertaPermisos(mensaje, tipo) {
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) {
        return;
    }
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${tipo === 'success' ? 'success' : 'error'}`;
    alert.innerHTML = `
        <i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${mensaje}
    `;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alert);
    
    setTimeout(() => alert.remove(), 5000);
}

// ========== INTEGRACIÓN CON NAVEGACIÓN ==========
function configurarNavegacionPermisos() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            
            if (target === 'permisos') {
                cargarPermisos();
            }
        });
    });
}

// ========== INICIALIZACIÓN EN DOM CONTENT LOADED ==========
document.addEventListener('DOMContentLoaded', function() {
    inicializarPermisos();
    configurarNavegacionPermisos();
});

//*****************************************************************/
// ========== CONFIGURACIÓN DE ROLES ==========
const API_ENDPOINTS_ROLES = {
    ROLES: {
        LISTAR: '/api/roles',
        CREAR: '/api/roles',
        ACTUALIZAR: '/api/roles',
        ELIMINAR: '/api/roles'
    },
    ROLES_PERMISOS: {
        ASIGNAR: '/api/roles-permisos',
        OBTENER_PERMISOS: '/api/roles-permisos/permisos',
        ELIMINAR_TODOS: '/api/roles-permisos/rol'
    }
};

// Variables de estado para roles
let roles = [];
let rolAEliminar = null;
let rolActual = null;
let permisosDisponibles = [];
let permisosSeleccionados = [];

// ========== INICIALIZACIÓN DE ROLES ==========
function inicializarRoles() {
    const btnNuevoRol = document.getElementById('btnNuevoRol');
    const btnGestionarPermisos = document.getElementById('btnGestionarPermisos');
    const rolModal = document.getElementById('rolModal');
    const modalCloseRol = document.getElementById('modalCloseRol');
    const btnCancelarRol = document.getElementById('btnCancelarRol');
    const btnGuardarRol = document.getElementById('btnGuardarRol');

    const permisosRolModal = document.getElementById('permisosRolModal');
    const modalClosePermisosRol = document.getElementById('modalClosePermisosRol');
    const btnCancelarPermisosRol = document.getElementById('btnCancelarPermisosRol');
    const btnGuardarPermisosRol = document.getElementById('btnGuardarPermisosRol');

    const confirmModalRol = document.getElementById('confirmModalRol');
    const confirmCloseRol = document.getElementById('confirmCloseRol');
    const btnCancelarEliminarRol = document.getElementById('btnCancelarEliminarRol');
    const btnConfirmarEliminarRol = document.getElementById('btnConfirmarEliminarRol');

    // Event Listeners para el modal de rol
    if (btnNuevoRol) {
        btnNuevoRol.addEventListener('click', () => {
            abrirModalRol();
        });
    }

    if (modalCloseRol) modalCloseRol.addEventListener('click', cerrarModalRol);
    if (btnCancelarRol) btnCancelarRol.addEventListener('click', cerrarModalRol);
    if (btnGuardarRol) btnGuardarRol.addEventListener('click', guardarRol);

    // Event Listeners para el modal de permisos del rol
    if (modalClosePermisosRol) modalClosePermisosRol.addEventListener('click', cerrarModalPermisosRol);
    if (btnCancelarPermisosRol) btnCancelarPermisosRol.addEventListener('click', cerrarModalPermisosRol);
    if (btnGuardarPermisosRol) btnGuardarPermisosRol.addEventListener('click', guardarPermisosRol);

    // Event Listeners para el modal de confirmación
    if (confirmCloseRol) confirmCloseRol.addEventListener('click', cerrarModalConfirmacionRol);
    if (btnCancelarEliminarRol) btnCancelarEliminarRol.addEventListener('click', cerrarModalConfirmacionRol);
    if (btnConfirmarEliminarRol) btnConfirmarEliminarRol.addEventListener('click', eliminarRolConfirmado);

    // Event listener para búsqueda de permisos
    const searchPermiso = document.getElementById('searchPermiso');
    if (searchPermiso) {
        searchPermiso.addEventListener('input', filtrarPermisos);
    }

    // Event listener para el botón de gestionar permisos
    if (btnGestionarPermisos) {
        btnGestionarPermisos.addEventListener('click', () => {
            abrirModalPermisosRol();
        });
    }

}

// ========== FUNCIONES PRINCIPALES DE ROLES ==========
function editarRol(id) {
    if (!id) {
        console.error(' ID inválido recibido en editarRol');
        mostrarAlertaRoles('Error: ID de rol inválido', 'error');
        return;
    }
    
    const rol = roles.find(r => 
        r.id === id || 
        r.id?.toString() === id ||
        r._id === id ||
        r._id?.toString() === id
    );
    
    if (rol) {
        abrirModalRol(rol);
    } else {
        console.error(' Rol no encontrado para editar. ID:', id);
        mostrarAlertaRoles('No se pudo encontrar el rol para editar', 'error');
    }
}
async function cargarRoles() {
    const rolesTableBody = document.getElementById('rolesTableBody');
    if (rolesTableBody) {
        rolesTableBody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px;">Cargando roles...</td></tr>';
    }
    
    try {
        const response = await fetch(API_ENDPOINTS_ROLES.ROLES.LISTAR);
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        
        roles = result.roles || [];
        
        // Para cada rol, cargar sus permisos
        await Promise.all(roles.map(async (rol) => {
            rol.permisos = await obtenerPermisosDelRol(rol.codigo);
        }));
        
        renderizarRoles();
        
    } catch (error) {
        console.error(' Error al cargar roles:', error);
        mostrarAlertaRoles('Error al cargar los roles: ' + error.message, 'error');
    }
}

async function obtenerPermisosDelRol(codigoRol) {
    try {
        
        const response = await fetch(`${API_ENDPOINTS_ROLES.ROLES_PERMISOS.OBTENER_PERMISOS}/${codigoRol}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(` Error obteniendo permisos para ${codigoRol}:`, errorText);
            return [];
        }
        
        const result = await response.json();
        
        return result.permisos || [];
    } catch (error) {
        console.error(` Error al cargar permisos del rol ${codigoRol}:`, error);
        return [];
    }
}

function renderizarRoles() {
    const rolesTableBody = document.getElementById('rolesTableBody');
    if (!rolesTableBody) return;
    
    rolesTableBody.innerHTML = '';
    
    if (roles.length === 0) {
        rolesTableBody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align: center; padding: 40px;">
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3>No hay roles registrados</h3>
                        <p>Comienza creando tu primer rol</p>
                        <button class="btn btn-primary" id="crearPrimerRol">
                            <i class="fas fa-plus"></i> Crear Rol
                        </button>
                    </div>
                </td>
            </tr>
        `;
        
        document.getElementById('crearPrimerRol').addEventListener('click', (e) => {
            e.preventDefault();
            abrirModalRol();
        });
        return;
    }
    
    roles.forEach(rol => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <span class="rol-codigo">${rol.codigo || 'N/A'}</span>
            </td>
            <td>${rol.nombre || 'N/A'}</td>
            <td>${rol.descripcion || '-'}</td>
            <td>
                <div class="permisos-container">
                    ${rol.permisos && rol.permisos.length > 0 
                        ? rol.permisos.map(permiso => 
                            `<span class="permiso-badge" title="${permiso.descripcion || ''}">${permiso.codigo}</span>`
                          ).join('')
                        : '<span style="color: #6c757d; font-style: italic;">Sin permisos</span>'
                    }
                </div>
            </td>
            <td>
                <div class="action-buttons">
                    <div class="action-btn manage-permisos" data-id="${rol.id}" data-codigo="${rol.codigo}" title="Gestionar permisos">
                        <i class="fas fa-key"></i>
                    </div>
                    <div class="action-btn edit" data-id="${rol.id}" title="Editar rol">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="action-btn delete" data-id="${rol.id}" title="Eliminar rol">
                        <i class="fas fa-trash"></i>
                    </div>
                </div>
            </td>
        `;
        rolesTableBody.appendChild(tr);
    });
    
    // Agregar event listeners CORREGIDOS
    document.querySelectorAll('.action-btn.edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            editarRol(id); // ← LLAMADA CORRECTA
        });
    });
    
    document.querySelectorAll('.action-btn.delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            confirmarEliminacionRol(id);
        });
    });
    
    document.querySelectorAll('.action-btn.manage-permisos').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const codigo = this.getAttribute('data-codigo');
            abrirModalPermisosRol(id, codigo);
        });
    });
    
}

//MODALES PARA ROLES
// ========== VARIABLES GLOBALES PARA PERMISOS EN ROL ==========
let permisosSeleccionadosRol = [];
let todosLosPermisosDisponibles = [];

async function abrirModalRol(rol = null) {
    const modal = document.getElementById('rolModal');
    const modalTitle = document.getElementById('modalTitleRol');
    
    if (!modal || !modalTitle) {
        console.error(' No se pudo encontrar el modal o su título');
        return;
    }
    
    // Cargar permisos disponibles
    await cargarTodosLosPermisos();
    
    if (rol && (rol.id || rol._id)) {
        modalTitle.textContent = 'Editar Rol';
        
        // Manejar diferentes formatos de ID
        const rolId = rol.id || rol._id;
        setValueIfExistsRol('rolId', rolId);
        setValueIfExistsRol('rolCodigo', rol.codigo);
        setValueIfExistsRol('rolNombre', rol.nombre);
        setValueIfExistsRol('rolDescripcion', rol.descripcion);
        
        // Cargar permisos del rol
        permisosSeleccionadosRol = rol.permisos || [];
        
    } else {
        modalTitle.textContent = 'Nuevo Rol';
        
        const rolForm = document.getElementById('rolForm');
        if (rolForm) {
            rolForm.reset();
        }
        
        setValueIfExistsRol('rolId', '');
        permisosSeleccionadosRol = [];
    }
    
    actualizarPreviewPermisos();
    modal.classList.add('active');
}

async function cargarTodosLosPermisos() {
    if (todosLosPermisosDisponibles.length > 0) {
        return;
    }
    
    try {
        const response = await fetch(API_ENDPOINTS_PERMISOS.PERMISOS.LISTAR);
        if (response.ok) {
            const result = await response.json();
            todosLosPermisosDisponibles = result.permisos || [];
        } else {
            throw new Error('Error al cargar permisos');
        }
    } catch (error) {
        console.error(' Error al cargar todos los permisos:', error);
        todosLosPermisosDisponibles = [];
    }
}

function actualizarPreviewPermisos() {
    const preview = document.getElementById('permisosPreview');
    if (!preview) return;
    
    preview.innerHTML = '';
    
    if (permisosSeleccionadosRol.length === 0) {
        preview.innerHTML = '<span class="no-permisos">No hay permisos seleccionados</span>';
        return;
    }
    
    permisosSeleccionadosRol.forEach(permiso => {
        const tag = document.createElement('span');
        tag.className = 'permiso-preview-tag';
        tag.textContent = permiso.codigo;
        tag.title = `${permiso.nombre} - ${permiso.descripcion || 'Sin descripción'}`;
        preview.appendChild(tag);
    });
}

function setValueIfExistsRol(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        element.value = value || '';
    } else {
        console.error(` No se encontró el elemento: ${elementId}`);
    }
}

function cerrarModalRol() {
    document.getElementById('rolModal').classList.remove('active');
}

// ========== GUARDAR ROL ==========
// ========== FUNCIÓN GUARDAR ROL SIMPLIFICADA ==========
async function guardarRol() {
    const id = document.getElementById('rolId').value;
    const codigo = document.getElementById('rolCodigo').value;
    const nombre = document.getElementById('rolNombre').value;
    const descripcion = document.getElementById('rolDescripcion').value;

    if (!codigo || !nombre) {
        mostrarAlertaRoles('Por favor, completa los campos: Código y Nombre', 'error');
        return;
    }
    
    // Mostrar loading
    const btnGuardar = document.getElementById('btnGuardarRol');
    const originalText = btnGuardar.innerHTML;
    btnGuardar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
    btnGuardar.disabled = true;
    
    try {
        const bodyData = {
            codigo: codigo.trim(),
            nombre: nombre.trim(),
            descripcion: (descripcion || '').trim()
        };
        
        let url, method;
        
        if (id) {
            url = `${API_ENDPOINTS_ROLES.ROLES.ACTUALIZAR}/${id}`;
            method = 'PUT';
            bodyData.id = id;
        } else {
            url = API_ENDPOINTS_ROLES.ROLES.CREAR;
            method = 'POST';
        }
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Error ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        // Si el rol se guardó correctamente, guardar los permisos
        if (result.success && result.rol) {
            const rolGuardado = result.rol;
            
            // Obtener permisos actuales del rol antes de guardar
            const permisosActuales = await obtenerPermisosDelRol(rolGuardado.codigo);
            
            // Intentar guardar permisos de forma diferencial
            try {
                const permisosGuardados = await guardarPermisosDelRol(rolGuardado.codigo, permisosActuales);
                
                if (permisosGuardados) {
                    mostrarAlertaRoles(
                        id ? '✅ Rol y permisos actualizados correctamente' : '✅ Rol y permisos creados correctamente', 
                        'success'
                    );
                } else {
                    mostrarAlertaRoles(
                        id ? '⚠️ Rol actualizado (problemas con algunos permisos)' : '⚠️ Rol creado (problemas con algunos permisos)', 
                        'warning'
                    );
                }
                
            } catch (permisoError) {
                console.warn('⚠️ Rol guardado pero con problemas en permisos:', permisoError);
                mostrarAlertaRoles(
                    id ? '✅ Rol actualizado (error gestionando permisos)' : '✅ Rol creado (error gestionando permisos)', 
                    'warning'
                );
            }
            
            cerrarModalRol();
            await cargarRoles();
        }
        else {
            throw new Error(result.error || 'Error en la operación');
        }
        
    } catch (error) {
        console.error(' Error al guardar rol:', error);
        mostrarAlertaRoles('Error al guardar rol: ' + error.message, 'error');
    } finally {
        // Restaurar botón
        btnGuardar.innerHTML = originalText;
        btnGuardar.disabled = false;
    }
}

// ========== FUNCIÓN TEMPORAL PARA ASIGNAR PERMISOS MANUALMENTE ==========
async function asignarPermisosManual(rolCodigo, permisosCodigos) {
    try {
        const asignaciones = permisosCodigos.map(codigoPermiso => ({
            codigo_rol: rolCodigo,
            codigo_permiso: codigoPermiso
        }));


        // Enviar cada asignación
        for (const asignacion of asignaciones) {
            try {
                const response = await fetch(API_ENDPOINTS_ROLES.ROLES_PERMISOS.ASIGNAR, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(asignacion)
                });
                
                if (response.ok) {
                } else {
                    console.warn(`⚠️ Error asignando permiso ${asignacion.codigo_permiso}:`, response.status);
                }
            } catch (error) {
                console.warn(`⚠️ Error asignando permiso ${asignacion.codigo_permiso}:`, error);
            }
        }
     
        return true;
    } catch (error) {
        console.error(' Error en asignación manual:', error);
        return false;
    }
}

// ========== GESTIÓN DE PERMISOS DEL ROL ==========
async function abrirModalPermisosRol(rolId = null, rolCodigo = null) {
    const modal = document.getElementById('permisosRolModal');
    
    // Si se llama desde el botón de gestión, usar los parámetros
    if (rolId && rolCodigo) {
        const rol = roles.find(r => r.id === rolId);
        if (rol) {
            rolActual = rol;
            permisosSeleccionadosRol = rol.permisos || [];
        }
    }
    
    // Si no hay rol actual (modo creación), usar los datos del formulario
    if (!rolActual) {
        const rolIdForm = document.getElementById('rolId').value;
        const rolCodigoForm = document.getElementById('rolCodigo').value;
        const rolNombreForm = document.getElementById('rolNombre').value;
        
        if (rolCodigoForm) {
            rolActual = {
                id: rolIdForm || null,
                codigo: rolCodigoForm,
                nombre: rolNombreForm,
                permisos: permisosSeleccionadosRol
            };
        }
    }
    
    if (!rolActual) {
        console.error(' No se pudo determinar el rol actual');
        return;
    }
    
    // Actualizar información del rol en el modal
    document.getElementById('rolIdPermisos').value = rolActual.id || '';
    document.getElementById('rolNombrePermisos').textContent = rolActual.nombre || 'Nuevo Rol';
    document.getElementById('rolCodigoPermisos').textContent = rolActual.codigo || 'Nuevo';
    
    // Asegurarse de que los permisos están cargados
    await cargarTodosLosPermisos();
    
    actualizarListaPermisosModal();
    actualizarPermisosSeleccionadosModal();
    actualizarContadorPermisosModal();
    
    modal.classList.add('active');
}

function actualizarListaPermisosModal() {
    const permisosList = document.getElementById('permisosList');
    const searchTerm = document.getElementById('searchPermiso').value.toLowerCase();
    
    if (!permisosList) return;
    
    permisosList.innerHTML = '';
    
    const permisosFiltrados = todosLosPermisosDisponibles.filter(permiso => 
        permiso.codigo.toLowerCase().includes(searchTerm) ||
        permiso.nombre.toLowerCase().includes(searchTerm) ||
        (permiso.descripcion && permiso.descripcion.toLowerCase().includes(searchTerm))
    );
    
    if (permisosFiltrados.length === 0) {
        permisosList.innerHTML = '<p style="text-align: center; color: #6c757d; padding: 20px;">No se encontraron permisos</p>';
        return;
    }
    
    permisosFiltrados.forEach(permiso => {
        const isSelected = permisosSeleccionadosRol.some(p => p.id === permiso.id);
        const permisoItem = document.createElement('div');
        permisoItem.className = `permiso-item ${isSelected ? 'selected' : ''}`;
        permisoItem.innerHTML = `
            <input type="checkbox" class="permiso-checkbox" 
                   data-permiso-id="${permiso.id}" 
                   data-permiso-codigo="${permiso.codigo}"
                   ${isSelected ? 'checked' : ''}>
            <div class="permiso-info">
                <div class="permiso-nombre">${permiso.nombre}</div>
                <div class="permiso-codigo-small">${permiso.codigo}</div>
                <p class="permiso-descripcion">${permiso.descripcion || 'Sin descripción'}</p>
            </div>
        `;
        
        permisoItem.addEventListener('click', (e) => {
            if (e.target.type !== 'checkbox') {
                const checkbox = permisoItem.querySelector('.permiso-checkbox');
                checkbox.checked = !checkbox.checked;
                togglePermisoModal(permiso, checkbox.checked);
            }
        });
        
        const checkbox = permisoItem.querySelector('.permiso-checkbox');
        checkbox.addEventListener('change', (e) => {
            togglePermisoModal(permiso, e.target.checked);
        });
        
        permisosList.appendChild(permisoItem);
    });
}

function actualizarPermisosSeleccionadosModal() {
    const selectedPermisosList = document.getElementById('selectedPermisosList');
    if (!selectedPermisosList) return;
    
    selectedPermisosList.innerHTML = '';
    
    permisosSeleccionadosRol.forEach(permiso => {
        const selectedItem = document.createElement('div');
        selectedItem.className = 'selected-permiso-item';
        selectedItem.innerHTML = `
            ${permiso.codigo}
            <span class="remove-permiso" data-permiso-id="${permiso.id}">
                <i class="fas fa-times"></i>
            </span>
        `;
        
        const removeBtn = selectedItem.querySelector('.remove-permiso');
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            togglePermisoModal(permiso, false);
        });
        
        selectedPermisosList.appendChild(selectedItem);
    });
}



async function cargarPermisosDisponibles() {
    try {
        // Usar el endpoint de permisos que ya tienes
        const response = await fetch(API_ENDPOINTS_PERMISOS.PERMISOS.LISTAR);
        if (response.ok) {
            const result = await response.json();
            permisosDisponibles = result.permisos || [];
        } else {
            throw new Error('Error al cargar permisos');
        }
    } catch (error) {
        console.error(' Error al cargar permisos disponibles:', error);
        permisosDisponibles = [];
    }
}

function actualizarListaPermisos() {
    const permisosList = document.getElementById('permisosList');
    const searchTerm = document.getElementById('searchPermiso').value.toLowerCase();
    
    if (!permisosList) return;
    
    permisosList.innerHTML = '';
    
    const permisosFiltrados = permisosDisponibles.filter(permiso => 
        permiso.codigo.toLowerCase().includes(searchTerm) ||
        permiso.nombre.toLowerCase().includes(searchTerm) ||
        (permiso.descripcion && permiso.descripcion.toLowerCase().includes(searchTerm))
    );
    
    if (permisosFiltrados.length === 0) {
        permisosList.innerHTML = '<p style="text-align: center; color: #6c757d; padding: 20px;">No se encontraron permisos</p>';
        return;
    }
    
    permisosFiltrados.forEach(permiso => {
        const isSelected = permisosSeleccionados.some(p => p.id === permiso.id);
        const permisoItem = document.createElement('div');
        permisoItem.className = `permiso-item ${isSelected ? 'selected' : ''}`;
        permisoItem.innerHTML = `
            <input type="checkbox" class="permiso-checkbox" 
                   data-permiso-id="${permiso.id}" 
                   data-permiso-codigo="${permiso.codigo}"
                   ${isSelected ? 'checked' : ''}>
            <div class="permiso-info">
                <div class="permiso-nombre">${permiso.nombre}</div>
                <div class="permiso-codigo-small">${permiso.codigo}</div>
                <p class="permiso-descripcion">${permiso.descripcion || 'Sin descripción'}</p>
            </div>
        `;
        
        permisoItem.addEventListener('click', (e) => {
            if (e.target.type !== 'checkbox') {
                const checkbox = permisoItem.querySelector('.permiso-checkbox');
                checkbox.checked = !checkbox.checked;
                togglePermiso(permiso, checkbox.checked);
            }
        });
        
        const checkbox = permisoItem.querySelector('.permiso-checkbox');
        checkbox.addEventListener('change', (e) => {
            togglePermiso(permiso, e.target.checked);
        });
        
        permisosList.appendChild(permisoItem);
    });
}

function togglePermisoModal(permiso, isSelected) {
    if (isSelected) {
        if (!permisosSeleccionadosRol.some(p => p.id === permiso.id)) {
            permisosSeleccionadosRol.push(permiso);
        }
    } else {
        permisosSeleccionadosRol = permisosSeleccionadosRol.filter(p => p.id !== permiso.id);
    }
    
    actualizarListaPermisosModal();
    actualizarPermisosSeleccionadosModal();
    actualizarContadorPermisosModal();
    actualizarPreviewPermisos(); // Actualizar también el preview en el modal principal
}

function actualizarContadorPermisosModal() {
    const contador = document.getElementById('contadorPermisos');
    if (contador) {
        contador.textContent = permisosSeleccionadosRol.length;
    }
}

function togglePermiso(permiso, isSelected) {
    if (isSelected) {
        if (!permisosSeleccionados.some(p => p.id === permiso.id)) {
            permisosSeleccionados.push(permiso);
        }
    } else {
        permisosSeleccionados = permisosSeleccionados.filter(p => p.id !== permiso.id);
    }
    
    actualizarListaPermisos();
    actualizarPermisosSeleccionados();
    actualizarContadorPermisos();
}

function actualizarPermisosSeleccionados() {
    const selectedPermisosList = document.getElementById('selectedPermisosList');
    if (!selectedPermisosList) return;
    
    selectedPermisosList.innerHTML = '';
    
    permisosSeleccionados.forEach(permiso => {
        const selectedItem = document.createElement('div');
        selectedItem.className = 'selected-permiso-item';
        selectedItem.innerHTML = `
            ${permiso.codigo}
            <span class="remove-permiso" data-permiso-id="${permiso.id}">
                <i class="fas fa-times"></i>
            </span>
        `;
        
        const removeBtn = selectedItem.querySelector('.remove-permiso');
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            togglePermiso(permiso, false);
        });
        
        selectedPermisosList.appendChild(selectedItem);
    });
}

function actualizarContadorPermisos() {
    const contador = document.getElementById('contadorPermisos');
    if (contador) {
        contador.textContent = permisosSeleccionados.length;
    }
}

function filtrarPermisos() {
    actualizarListaPermisosModal();
}

function cerrarModalPermisosRol() {
    document.getElementById('permisosRolModal').classList.remove('active');
    rolActual = null;
}

async function guardarPermisosRol() {
    // Solo cerrar el modal, los permisos ya están en permisosSeleccionadosRol
    cerrarModalPermisosRol();
    mostrarAlertaRoles('✅ Permisos actualizados correctamente', 'success');
}

async function guardarPermisosDelRol(codigoRol, permisosAnteriores = []) {
    if (permisosSeleccionadosRol.length === 0 && permisosAnteriores.length === 0) {
        return true;
    }
    
    try {
       
        // 1. Identificar permisos a ELIMINAR
        const permisosAEliminar = permisosAnteriores.filter(permisoAnterior => 
            !permisosSeleccionadosRol.some(permisoNuevo => 
                permisoNuevo.codigo === permisoAnterior.codigo
            )
        );
        
        // 2. Identificar permisos a AGREGAR
        const permisosAAgregar = permisosSeleccionadosRol.filter(permisoNuevo => 
            !permisosAnteriores.some(permisoAnterior => 
                permisoAnterior.codigo === permisoNuevo.codigo
            )
        );
        
        // 3. Eliminar permisos que ya no están seleccionados
        const eliminacionesExitosas = await eliminarPermisosEspecificos(codigoRol, permisosAEliminar);
        
        // 4. Agregar nuevos permisos
        const adicionesExitosas = await agregarPermisosEspecificos(codigoRol, permisosAAgregar);
        
        const totalExitosas = eliminacionesExitosas + adicionesExitosas;
        const totalOperaciones = permisosAEliminar.length + permisosAAgregar.length;
        
        return totalExitosas > 0 || totalOperaciones === 0;
        
    } catch (error) {
        console.error(' Error crítico al gestionar permisos del rol:', error);
        return false;
    }
}   

async function eliminarPermisosEspecificos(codigoRol, permisosAEliminar) {
    if (permisosAEliminar.length === 0) {
        return 0;
    }
    
    try {
        const promises = permisosAEliminar.map(async (permiso) => {
            try {
                // Usar el nuevo endpoint para eliminar permiso específico
                const deleteResponse = await fetch(`${API_ENDPOINTS_ROLES.ROLES_PERMISOS.ELIMINAR_TODOS}/${codigoRol}/permiso/${permiso.codigo}`, {
                    method: 'DELETE'
                });
                
                if (deleteResponse.ok) {
                    return { success: true, permiso: permiso.codigo };
                } else {
                    const errorText = await deleteResponse.text();
                    console.warn(`⚠️ No se pudo eliminar el permiso ${permiso.codigo}:`, errorText);
                    return { success: false, permiso: permiso.codigo };
                }
                
            } catch (error) {
                console.warn(`⚠️ Error eliminando permiso ${permiso.codigo}:`, error);
                return { success: false, permiso: permiso.codigo };
            }
        });
        
        const results = await Promise.all(promises);
        return results.filter(r => r.success).length;
        
    } catch (error) {
        console.error(' Error en eliminación específica de permisos:', error);
        return 0;
    }
}

async function agregarPermisosEspecificos(codigoRol, permisosAAgregar) {
    if (permisosAAgregar.length === 0) {
        return 0;
    }
    
    try {
        const promises = permisosAAgregar.map(async (permiso) => {
            try {
                const asignacion = {
                    codigo_rol: codigoRol,
                    codigo_permiso: permiso.codigo
                };
                
                const response = await fetch(API_ENDPOINTS_ROLES.ROLES_PERMISOS.ASIGNAR, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(asignacion)
                });
                
                const responseData = await response.json();
                
                if (response.ok) {
                    return { success: true, permiso: permiso.codigo };
                } else {
                    // Si el error es "ya existe", lo consideramos éxito
                    if (responseData.error && responseData.error.includes('ALREADY_EXISTS')) {
                        return { success: true, permiso: permiso.codigo };
                    }
                    
                    console.warn(`⚠️ Error agregando permiso ${permiso.codigo}:`, response.status, responseData);
                    return { success: false, permiso: permiso.codigo };
                }
            } catch (error) {
                console.warn(`⚠️ Error agregando permiso ${permiso.codigo}:`, error);
                return { success: false, permiso: permiso.codigo };
            }
        });
        
        const results = await Promise.all(promises);
        return results.filter(r => r.success).length;
        
    } catch (error) {
        console.error(' Error en adición específica de permisos:', error);
        return 0;
    }
}

// ========== ELIMINAR ROL ==========
function cerrarModalConfirmacionRol() {
    const confirmModal = document.getElementById('confirmModalRol');
    if (confirmModal) {
        confirmModal.classList.remove('active');
    }
    rolAEliminar = null;
}

async function eliminarRolConfirmado() {
    const id = rolAEliminar;
    
    if (!id) {
        console.error(' No hay rol seleccionado para eliminar');
        return;
    }
    
    try {
        const url = `${API_ENDPOINTS_ROLES.ROLES.ELIMINAR}/${id}`;
        const response = await fetch(url, { 
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(' Error response:', errorText);
            throw new Error(`Error ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        if (result.success || result.ok) {
            mostrarAlertaRoles('✅ Rol eliminado correctamente', 'success');
            cerrarModalConfirmacionRol();
            await cargarRoles();
        } else {
            throw new Error(result.error || 'No se pudo eliminar el rol');
        }
        
    } catch (error) {
        console.error(' Error al eliminar el rol:', error);
        mostrarAlertaRoles('Error al eliminar el rol: ' + error.message, 'error');
    }
}

function confirmarEliminacionRol(id) {
    const rol = roles.find(p => p.id === id);
    
    if (!rol) {
        console.error(' Rol no encontrado para eliminar');
        mostrarAlertaRoles('Error: Rol no encontrado', 'error');
        return;
    }
    
    const rolNombre = rol.nombre || 'este rol';
    
    const confirmModal = document.getElementById('confirmModalRol');
    const rolNombreElement = document.getElementById('rolNombreEliminar');
    
    if (confirmModal && rolNombreElement) {
        rolNombreElement.textContent = `"${rolNombre}"`;
        
        const btnConfirmar = document.getElementById('btnConfirmarEliminarRol');
        if (btnConfirmar) {
            btnConfirmar.replaceWith(btnConfirmar.cloneNode(true));
            
            document.getElementById('btnConfirmarEliminarRol').addEventListener('click', function() {
                eliminarRolConfirmado(id);
            });
        }
        
        rolAEliminar = id;
        confirmModal.classList.add('active');
    } else {
        console.error(' No se pudo encontrar el modal de confirmación');
        if (confirm(`¿Estás seguro de que deseas eliminar el rol "${rolNombre}"? Esta acción no se puede deshacer.`)) {
            eliminarRol(id);
        }
    }
}

// ========== ALERTAS PARA ROLES ==========
function mostrarAlertaRoles(mensaje, tipo) {
    const alertContainer = document.getElementById('alertContainerRoles');
    if (!alertContainer) {
        return;
    }
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${tipo === 'success' ? 'success' : 'error'}`;
    alert.innerHTML = `
        <i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${mensaje}
    `;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alert);
    
    setTimeout(() => alert.remove(), 5000);
}

// ========== INTEGRACIÓN CON NAVEGACIÓN ==========
function configurarNavegacionRoles() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            
            if (target === 'roles') {
                cargarRoles();
            }
        });
    });
}

// ========== INICIALIZACIÓN EN DOM CONTENT LOADED ==========
document.addEventListener('DOMContentLoaded', function() {
    inicializarRoles();
    configurarNavegacionRoles();
});

// ========== CONFIGURACIÓN DE USUARIOS ==========
const API_ENDPOINTS_USUARIOS = {
    USUARIOS: {
        LISTAR: '/api/usuarios',
        CREAR: '/api/usuarios',
        ACTUALIZAR: '/api/usuarios',
        ELIMINAR: '/api/usuarios',
        COUNT: '/api/usuarios/count'
    },
    ROLES: {
        LISTAR: '/api/roles'
    }
};

// Variables de estado para usuarios
let usuarios = [];
let rolesUsuarios = [];
let usuarioAEliminar = null;

// ========== INICIALIZACIÓN DE USUARIOS ==========
function inicializarUsuarios() {
    const btnNuevoUsuario = document.getElementById('btnNuevoUsuario');
    const usuarioModal = document.getElementById('usuarioModal');
    const modalCloseUsuario = document.getElementById('modalCloseUsuario');
    const btnCancelarUsuario = document.getElementById('btnCancelarUsuario');
    const btnGuardarUsuario = document.getElementById('btnGuardarUsuario');

    const confirmModalUsuario = document.getElementById('confirmModalUsuario');
    const confirmCloseUsuario = document.getElementById('confirmCloseUsuario');
    const btnCancelarEliminarUsuario = document.getElementById('btnCancelarEliminarUsuario');
    const btnConfirmarEliminarUsuario = document.getElementById('btnConfirmarEliminarUsuario');

    // Event Listeners para el modal de usuario
    if (btnNuevoUsuario) {
        btnNuevoUsuario.addEventListener('click', () => {
            abrirModalUsuario();
        });
    }

    if (modalCloseUsuario) modalCloseUsuario.addEventListener('click', cerrarModalUsuario);
    if (btnCancelarUsuario) btnCancelarUsuario.addEventListener('click', cerrarModalUsuario);
    if (btnGuardarUsuario) btnGuardarUsuario.addEventListener('click', guardarUsuario);

    // Event Listeners para el modal de confirmación
    if (confirmCloseUsuario) confirmCloseUsuario.addEventListener('click', cerrarModalConfirmacionUsuario);
    if (btnCancelarEliminarUsuario) btnCancelarEliminarUsuario.addEventListener('click', cerrarModalConfirmacionUsuario);
    if (btnConfirmarEliminarUsuario) btnConfirmarEliminarUsuario.addEventListener('click', eliminarUsuarioConfirmado);

}

// ========== FUNCIONES PRINCIPALES DE USUARIOS ==========

// Función para actualizar contador de usuarios
async function loadUsuariosCount() {
    const usuariosCountElement = document.getElementById('menu-badge-usuarios');
    
    if (!usuariosCountElement) {
        console.error(' NO se encontró el elemento #menu-badge-usuarios');
        return;
    }
    
    try {
        const response = await fetch('/api/usuarios/count');
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            const total = data.total;
            usuariosCountElement.textContent = total;
        } else {
            throw new Error(data.error || 'Error en la respuesta');
        }
        
    } catch (error) {
        console.error(' Error en usuarios count:', error);
        usuariosCountElement.textContent = '0';
        usuariosCountElement.style.color = '#ff4444';
    }
}

async function cargarUsuarios() {
    const usuariosTableBody = document.getElementById('usuariosTableBody');
    if (usuariosTableBody) {
        usuariosTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px;">Cargando usuarios...</td></tr>';
    }
    
    try {
        if (rolesUsuarios.length === 0) {
            await cargarRolesParaCombobox();
        } else {
        }
        
        const response = await fetch(API_ENDPOINTS_USUARIOS.USUARIOS.LISTAR);
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        
        usuarios = result.usuarios || [];
        renderizarUsuarios();
        
    } catch (error) {
        console.error(' Error al cargar usuarios:', error);
        mostrarAlertaUsuarios('Error al cargar los usuarios: ' + error.message, 'error');
    }
}

async function cargarRolesParaCombobox() {
    
    if (rolesUsuarios.length > 0) {
        return;
    }
    
    try {
        const response = await fetch(API_ENDPOINTS_USUARIOS.ROLES.LISTAR);
        
        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.roles) {
            rolesUsuarios = result.roles;
        } else if (Array.isArray(result)) {
            rolesUsuarios = result;
        } else if (result.data && Array.isArray(result.data)) {
            rolesUsuarios = result.data;
        } else {
            rolesUsuarios = [];
            console.warn('⚠️ Estructura de respuesta inesperada:', result);
        }
        
        actualizarComboboxRoles();
        
    } catch (error) {
        console.error(' Error al cargar roles para combobox:', error);
        rolesUsuarios = [];
    }
}

function actualizarComboboxRoles() {
    const select = document.getElementById('usuarioRol');
    
    if (!select) {
        console.error(' No se encontró el elemento usuarioRol');
        return;
    }
    
    if (rolesUsuarios.length === 0) {
        console.warn('⚠️ No hay roles para mostrar');
        select.innerHTML = '<option value="">No hay roles disponibles</option>';
        return;
    }
    
    select.innerHTML = '<option value="">Seleccionar rol...</option>';
    
    rolesUsuarios.forEach(rol => {
        const id = rol.codigo; // Usar código del rol en lugar del ID
        const nombre = rol.nombre || 'Sin nombre';
        const codigo = rol.codigo || 'Sin código';
        
        const option = document.createElement('option');
        option.value = id;
        option.textContent = `${nombre} (${codigo})`;
        select.appendChild(option);
    });
    
}

function renderizarUsuarios() {
    const usuariosTableBody = document.getElementById('usuariosTableBody');
    if (!usuariosTableBody) return;
    
    usuariosTableBody.innerHTML = '';
    
    if (usuarios.length === 0) {
        usuariosTableBody.innerHTML = `
            <tr>
                <td colspan="9" style="text-align: center; padding: 30px;">
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3>No hay usuarios registrados</h3>
                        <p>Comienza creando tu primer usuario</p>
                        <button class="btn btn-primary" id="crearPrimerUsuario">
                            <i class="fas fa-plus"></i> Crear Usuario
                        </button>
                    </div>
                </td>
            </tr>
        `;
        
        document.getElementById('crearPrimerUsuario').addEventListener('click', (e) => {
            e.preventDefault();
            abrirModalUsuario();
        });
        return;
    }
    
    usuarios.forEach(usuario => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${usuario.rut || 'N/A'}</td>
            <td>${usuario.nombre || 'N/A'}</td>
            <td>${usuario.correo || 'N/A'}</td>
            <td>${usuario.telefono || 'N/A'}</td>
            <td>
                <span class="rol-badge" title="${usuario.rolDescripcion || 'Sin descripción'}">
                    ${usuario.rol || 'Sin rol'}
                </span>
            </td>
            <td>
                <span class="status ${usuario.aut2FA ? 'active' : 'inactive'}">
                    ${usuario.aut2FA ? 'Activado' : 'Desactivado'}
                </span>
            </td>
            <td><span class="status ${usuario.active ? 'active' : 'inactive'}">${usuario.active ? 'Activo' : 'Inactivo'}</span></td>
            <td>
                <div class="action-buttons">
                    <div class="action-btn edit" data-id="${usuario.id}" title="Editar usuario">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="action-btn delete" data-id="${usuario.id}" title="Eliminar usuario">
                        <i class="fas fa-trash"></i>
                    </div>
                </div>
            </td>
        `;
        usuariosTableBody.appendChild(tr);
    });
    
    document.querySelectorAll('.action-btn.edit').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            editarUsuario(id);
        });
    });
    
    document.querySelectorAll('.action-btn.delete').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            confirmarEliminacionUsuario(id);
        });
    });
    
}

// ========== MODAL Y FORMULARIO DE USUARIOS ==========
async function abrirModalUsuario(usuario = null) {
    await asegurarRolesCargados();
    
    const modal = document.getElementById('usuarioModal');
    const modalTitle = document.getElementById('modalTitleUsuario');
    
    if (!modal || !modalTitle) {
        console.error(' No se pudo encontrar el modal o su título');
        return;
    }
    
    if (usuario && usuario.id) {
        modalTitle.textContent = 'Editar Usuario';
        setValueIfExistsUsuario('usuarioId', usuario.id);
        setValueIfExistsUsuario('usuarioRut', usuario.rut);
        setValueIfExistsUsuario('usuarioNombre', usuario.nombre);
        setValueIfExistsUsuario('usuarioCorreo', usuario.correo);
        setValueIfExistsUsuario('usuarioTelefono', usuario.telefono);
        setValueIfExistsUsuario('usuarioEdad', usuario.edad);
        
        // Para edición, el campo de contraseña no es obligatorio
        const claveInput = document.getElementById('usuarioClave');
        if (claveInput) {
            claveInput.required = false;
            claveInput.placeholder = 'Dejar vacío para mantener la actual';
        }
        
        const rolSelect = document.getElementById('usuarioRol');
        if (rolSelect) {
            rolSelect.value = usuario.rol || '';
        }
        
        const activoCheckbox = document.getElementById('usuarioActivo');
        if (activoCheckbox) {
            activoCheckbox.checked = usuario.active !== false;
        }
        
        const aut2FACheckbox = document.getElementById('usuarioAut2FA');
        if (aut2FACheckbox) {
            aut2FACheckbox.checked = usuario.aut2FA === true;
        }
        
    } else {
        modalTitle.textContent = 'Nuevo Usuario';
        const usuarioForm = document.getElementById('usuarioForm');
        if (usuarioForm) {
            usuarioForm.reset();
        }
        
        setValueIfExistsUsuario('usuarioId', '');
        
        // Para creación, la contraseña es obligatoria
        const claveInput = document.getElementById('usuarioClave');
        if (claveInput) {
            claveInput.required = true;
            claveInput.placeholder = '••••••••';
        }
        
        const activoCheckbox = document.getElementById('usuarioActivo');
        if (activoCheckbox) {
            activoCheckbox.checked = true;
        }
        
        const aut2FACheckbox = document.getElementById('usuarioAut2FA');
        if (aut2FACheckbox) {
            aut2FACheckbox.checked = false;
        }
    }
    
    modal.classList.add('active');
}

function setValueIfExistsUsuario(elementId, value) {
    const element = document.getElementById(elementId);
    if (element) {
        if (element.type === 'checkbox') {
            element.checked = Boolean(value);
        } else {
            element.value = value || '';
        }
    } else {
        console.warn(`⚠️ No se encontró el elemento: ${elementId}`);
    }
}

function cerrarModalUsuario() {
    document.getElementById('usuarioModal').classList.remove('active');
}

function asegurarRolesCargados() {
    return new Promise(async (resolve) => {
        if (rolesUsuarios.length === 0) {
            await cargarRolesParaCombobox();
        }
        resolve();
    });
}

// ========== GUARDAR USUARIO ==========
async function guardarUsuario() {
    // Obtener valores del formulario con validación
    const idElement = document.getElementById('usuarioId');
    const rutElement = document.getElementById('usuarioRut');
    const nombreElement = document.getElementById('usuarioNombre');
    const correoElement = document.getElementById('usuarioCorreo');
    const telefonoElement = document.getElementById('usuarioTelefono');
    const edadElement = document.getElementById('usuarioEdad');
    const claveElement = document.getElementById('usuarioClave');
    const rolElement = document.getElementById('usuarioRol');
    const aut2FAElement = document.getElementById('usuarioAut2FA');
    const activoElement = document.getElementById('usuarioActivo');

    // Verificar que todos los elementos requeridos existan
    if (!rutElement || !nombreElement || !correoElement || !rolElement) {
        mostrarAlertaUsuarios('Error: No se pudieron encontrar todos los campos del formulario', 'error');
        return;
    }

    const id = idElement ? idElement.value : '';
    const rut = rutElement.value;
    const nombre = nombreElement.value;
    const correo = correoElement.value;
    const telefono = telefonoElement ? telefonoElement.value : '';
    const edad = edadElement ? parseInt(edadElement.value) || 0 : 0;
    const clave = claveElement ? claveElement.value : '';
    const rol = rolElement.value;
    const aut2FA = aut2FAElement ? aut2FAElement.checked : false;
    const active = activoElement ? activoElement.checked : true;

    // Validaciones
    if (!rut || !nombre || !correo || !rol) {
        mostrarAlertaUsuarios('Por favor, completa los campos obligatorios: RUT, Nombre, Email y Rol', 'error');
        return;
    }
    
    // Validación de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(correo)) {
        mostrarAlertaUsuarios('Por favor, ingresa un email válido', 'error');
        return;
    }
    
    // Para creación, validar contraseña
    if (!id && (!clave || clave.length < 6)) {
        mostrarAlertaUsuarios('La contraseña es obligatoria y debe tener al menos 6 caracteres', 'error');
        return;
    }
    
    try {
        const bodyData = {
            rut: rut.trim(),
            nombre: nombre.trim(),
            correo: correo.trim(),
            telefono: telefono.trim(),
            edad: edad,
            aut2FA: aut2FA,
            active: active,
            rol: rol.trim(),
            intentos_fallidos: 0,
            cuenta_bloqueada: false
        };
        
        // Solo incluir clave si se proporcionó (en edición puede estar vacía)
        if (clave && clave.length >= 6) {
            bodyData.clave = clave;
        }
        
        let url, method;
        
        if (id) {
            url = `/api/usuarios/${id}`;
            method = 'PUT';
            bodyData.id = id;
        } else {
            url = '/api/usuarios';
            method = 'POST';
        }
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyData)
        });
        
        if (!response.ok) {
            let errorMessage = `Error HTTP: ${response.status}`;
            try {
                const errorText = await response.text();
                console.error(' Error response text:', errorText);
                
                try {
                    const errorData = JSON.parse(errorText);
                    errorMessage = errorData.error || errorData.message || errorText;
                } catch {
                    errorMessage = errorText || `Error ${response.status}`;
                }
            } catch (e) {
                errorMessage = `Error ${response.status}: No se pudo leer la respuesta`;
            }
            throw new Error(errorMessage);
        }
        
        const result = await response.json();
        
        mostrarAlertaUsuarios(
            id ? '✅ Usuario actualizado correctamente' : '✅ Usuario creado correctamente', 
            'success'
        );
        
        cerrarModalUsuario();
        await cargarUsuarios();
        await loadUsuariosCount();
        
    } catch (error) {
        console.error(' Error completo al guardar usuario:', error);
        mostrarAlertaUsuarios('Error al guardar usuario: ' + error.message, 'error');
    }
}

// ========== EDITAR USUARIO ==========
async function editarUsuario(id) {
    if (!id) {
        console.error(' ID inválido recibido en editarUsuario');
        mostrarAlertaUsuarios('Error: ID de usuario inválido', 'error');
        return;
    }
    
    const usuario = usuarios.find(u => {
        return u.id === id || 
               u.id?.toString() === id ||
               u._id === id ||
               u._id?.toString() === id;
    });
    
    if (usuario) {
        await abrirModalUsuario(usuario);
    } else {
        console.error(' Usuario no encontrado para editar. ID:', id);
        mostrarAlertaUsuarios('No se pudo encontrar el usuario para editar', 'error');
    }
}

// ========== ELIMINAR USUARIO ==========
function cerrarModalConfirmacionUsuario() {
    const confirmModal = document.getElementById('confirmModalUsuario');
    if (confirmModal) {
        confirmModal.classList.remove('active');
    }
    usuarioAEliminar = null;
}

async function eliminarUsuarioConfirmado() {
    const id = usuarioAEliminar;
    
    if (!id) {
        console.error(' No hay usuario seleccionado para eliminar');
        return;
    }
    
    try {
        const url = `${API_ENDPOINTS_USUARIOS.USUARIOS.ELIMINAR}/${id}`;
        const response = await fetch(url, { 
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error(' Error response:', errorText);
            throw new Error(`Error ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            mostrarAlertaUsuarios('✅ Usuario eliminado correctamente', 'success');
            cerrarModalConfirmacionUsuario();
            
            await cargarUsuarios();
            await loadUsuariosCount();
            
        } else {
            throw new Error(result.error || 'No se pudo eliminar el usuario');
        }
        
    } catch (error) {
        console.error(' Error al eliminar el usuario:', error);
        mostrarAlertaUsuarios('Error al eliminar el usuario: ' + error.message, 'error');
    }
}

function confirmarEliminacionUsuario(id) {
    
    const usuario = usuarios.find(u => u.id === id);
    
    if (!usuario) {
        console.error(' Usuario no encontrado para eliminar');
        mostrarAlertaUsuarios('Error: Usuario no encontrado', 'error');
        return;
    }
    
    const usuarioNombre = usuario.nombre || 'este usuario';
    
    const confirmModal = document.getElementById('confirmModalUsuario');
    const usuarioNombreElement = document.getElementById('usuarioNombreEliminar');
    
    if (confirmModal && usuarioNombreElement) {
        usuarioNombreElement.textContent = `"${usuarioNombre}"`;
        
        const btnConfirmar = document.getElementById('btnConfirmarEliminarUsuario');
        if (btnConfirmar) {
            btnConfirmar.replaceWith(btnConfirmar.cloneNode(true));
            
            document.getElementById('btnConfirmarEliminarUsuario').addEventListener('click', function() {
                eliminarUsuarioConfirmado(id);
            });
        }
        
        usuarioAEliminar = id;
        confirmModal.classList.add('active');
        
    } else {
        console.error(' No se pudo encontrar el modal de confirmación');
        if (confirm(`¿Estás seguro de que deseas eliminar al usuario "${usuarioNombre}"? Esta acción no se puede deshacer.`)) {
            eliminarUsuario(id);
        }
    }
}

// ========== ALERTAS PARA USUARIOS ==========
function mostrarAlertaUsuarios(mensaje, tipo) {
    const alertContainer = document.getElementById('alertContainerUsuarios');
    if (!alertContainer) return;
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${tipo === 'success' ? 'success' : 'error'}`;
    alert.innerHTML = `
        <i class="fas ${tipo === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${mensaje}
    `;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alert);
    
    setTimeout(() => alert.remove(), 5000);
}

// ========== INTEGRACIÓN CON NAVEGACIÓN ==========
function configurarNavegacionUsuarios() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            
            if (target === 'usuarios') {
                
                // Actualizar contador al entrar a la sección
                loadUsuariosCount();
                
                cargarRolesParaCombobox().then(() => {
                    cargarUsuarios();
                }).catch(error => {
                    console.error(' Error cargando roles:', error);
                    cargarUsuarios();
                });
            }
        });
    });
}

// ========== INICIALIZACIÓN EN DOM CONTENT LOADED ==========
document.addEventListener('DOMContentLoaded', function() {
    inicializarUsuarios();
    configurarNavegacionUsuarios();
    
    setTimeout(() => {
        loadUsuariosCount();
    }, 100);
    
    setInterval(() => {
        loadUsuariosCount();
    }, 30000);

    // ========== FUNCIONES GLOBALES PARA EL DASHBOARD ==========

    // Hacer funciones disponibles globalmente
    window.verDetallesPedido = verDetallesPedido;
    window.cerrarModalDetallePedido = cerrarModalDetallePedido;
    window.cargarSeccion = cargarSeccion;

    // Función para cargar sección
    function cargarSeccion(seccion) {
        const menuItem = document.querySelector(`.menu-item[data-target="${seccion}"]`);
        if (menuItem) {
            menuItem.click();
        } else {
            console.error('No se encontró la sección:', seccion);
        }
    }

    // Función para cerrar modal de detalle (si no está definida)
    function cerrarModalDetallePedido() {
        document.getElementById('detallePedidoModal').classList.remove('active');
    }
});



