const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const router = express.Router();

// Cargar proto de usuarios
const usuarioDef = protoLoader.loadSync('./protos/usuario.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const usuarioProto = grpc.loadPackageDefinition(usuarioDef).usuarios;

// Cargar proto de roles
const rolDef = protoLoader.loadSync('./protos/rol.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const rolProto = grpc.loadPackageDefinition(rolDef).roles;

const usuarioClient = new usuarioProto.UsuariosService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

const rolClient = new rolProto.RolesService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// Función auxiliar para obtener descripción del rol
function obtenerDescripcionRol(codigo) {
  return new Promise(resolve => {
    rolClient.GetRolByCodigo({ codigo }, (err, rol) => {
      if (err) {
        console.error('Error obteniendo descripción del rol:', err);
        resolve(null);
      } else {
        resolve(rol.descripcion);
      }
    });
  });
}

// ========== RUTAS ESPECÍFICAS DEBEN IR PRIMERO ==========

// Contar usuarios - DEBE IR PRIMERO
router.get('/count', (req, res) => {
    usuarioClient.CountUsuarios({}, (err, response) => {  
        if (err) {
            console.error(' Error contando usuarios:', err);
            return res.status(500).json({ 
                success: false, 
                error: 'Error interno del servidor al contar usuarios: ' + err.message
            });
        }
        res.json({ 
            success: true, 
            total: response.total 
        });
    });
});

// OBTENER usuario por correo - GET /api/usuarios/correo/:correo
router.get('/correo/:correo', (req, res) => {
  const usuarioCorreo = req.params.correo;

  if (!usuarioCorreo) {
    return res.status(400).json({
      success: false,
      error: 'Correo de usuario es requerido'
    });
  }

  usuarioClient.GetUsuarioByCorreo({ correo: usuarioCorreo }, async (err, response) => {
    if (err) {
      console.error(' Error gRPC al obtener usuario por correo:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo obtener el usuario'}`
      });
    }

    // Si no se encuentra el usuario
    if (!response || !response.id) {
      return res.status(404).json({
        success: false,
        error: 'Usuario no encontrado'
      });
    }

    // Enriquecer con descripción del rol
    try {
      const rolDescripcion = await obtenerDescripcionRol(response.rol);
      const usuarioEnriquecido = {
        ...response,
        rolDescripcion: rolDescripcion || 'Sin descripción'
      };
      
      res.json({
        success: true,
        usuario: usuarioEnriquecido
      });
    } catch (error) {
      console.error('Error obteniendo descripción del rol:', error);
      res.json({
        success: true,
        usuario: response
      });
    }
  });
});

// Ruta POST para login
router.post('/login', (req, res) => {
  const { correo, clave } = req.body;

  usuarioClient.ValidarUsuario({ correo, clave }, (err, response) => {
    if (err) {
      console.error(' Error gRPC en login:', err);
      return res.status(500).json({ 
        success: false,
        error: 'Error del servidor en autenticación' 
      });
    }
    
    if (!response.valido) {
      return res.status(401).json({ 
        success: false,
        error: 'Credenciales inválidas' 
      });
    }
    
    res.json({ 
      success: true,
      message: 'Login exitoso'
    });
  });
});

// Listar usuarios con descripción de rol
router.get('/', (req, res) => {
  const { page = 1, pageSize = 10, q = '', onlyActive = false } = req.query;

  usuarioClient.ListUsuarios(
    {
      page: Number(page),
      pageSize: Number(pageSize),
      q,
      onlyActive: onlyActive === 'true'
    },
    async (err, response) => {
      if (err) {
        console.error(' Error gRPC al listar usuarios:', err);
        return res.status(500).json({ 
          success: false,
          error: err.message 
        });
      }

      const usuarios = response.usuarios || [];

      try {
        const enriquecidos = await Promise.all(
          usuarios.map(async usuario => {
            const rolDescripcion = await obtenerDescripcionRol(usuario.rol);
            return {
              ...usuario,
              rolDescripcion: rolDescripcion || 'Sin descripción'
            };
          })
        );

        res.json({
          success: true,
          usuarios: enriquecidos,
          page: response.page,
          pageSize: response.pageSize,
          total: response.total
        });
      } catch (error) {
        console.error('Error enriqueciendo usuarios con roles:', error);
        res.json({
          success: true,
          usuarios: usuarios,
          page: response.page,
          pageSize: response.pageSize,
          total: response.total
        });
      }
    }
  );
});

// ========== RUTAS CON PARÁMETROS DEBEN IR DESPUÉS ==========

// OBTENER usuario por ID - GET /api/usuarios/:id
router.get('/:id', (req, res) => {
  const usuarioId = req.params.id;

  if (!usuarioId) {
    return res.status(400).json({
      success: false,
      error: 'ID de usuario es requerido'
    });
  }

  // Si el ID es "count", redirigir al endpoint correcto
  if (usuarioId === 'count') {
    return res.redirect('/api/usuarios/count');
  }

  usuarioClient.GetUsuario({ id: usuarioId }, async (err, response) => {
    if (err) {
      console.error(' Error gRPC al obtener usuario:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo obtener el usuario'}`
      });
    }

    // Enriquecer con descripción del rol
    try {
      const rolDescripcion = await obtenerDescripcionRol(response.rol);
      const usuarioEnriquecido = {
        ...response,
        rolDescripcion: rolDescripcion || 'Sin descripción'
      };
      
      res.json({
        success: true,
        usuario: usuarioEnriquecido
      });
    } catch (error) {
      console.error('Error obteniendo descripción del rol:', error);
      res.json({
        success: true,
        usuario: response
      });
    }
  });
});

// CREAR usuario - POST /api/usuarios
router.post('/', (req, res) => {
  const { 
    rut, 
    nombre, 
    correo, 
    clave, 
    rol, 
    telefono = '',
    edad = 0,
    aut2FA = false,
    active = true,
    intentos_fallidos = 0,
    cuenta_bloqueada = false
  } = req.body;

  // Validaciones básicas - QUITAR "codigo" de la validación
  if (!rut || !nombre || !correo || !clave || !rol) {
    return res.status(400).json({
      success: false,
      error: 'Faltan campos requeridos: rut, nombre, correo, clave, rol'
    });
  }

  const createRequest = {
    rut: rut.toString().trim(),
    nombre: nombre.toString().trim(),
    correo: correo.toString().trim(),
    clave: clave.toString().trim(),
    rol: rol.toString().trim(),
    telefono: telefono ? telefono.toString().trim() : '',
    edad: Number(edad) || 0,
    aut2FA: Boolean(aut2FA),
    active: Boolean(active),
    intentos_fallidos: Number(intentos_fallidos) || 0,
    cuenta_bloqueada: Boolean(cuenta_bloqueada)
  };

  usuarioClient.CreateUsuario(createRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al crear usuario:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo crear el usuario'}`
      });
    }
    
    res.json({
      success: true,
      usuario: response,
      message: 'Usuario creado exitosamente'
    });
  });
});

// ACTUALIZAR usuario - PUT /api/usuarios/:id
router.put('/:id', (req, res) => {
  const usuarioId = req.params.id;
  const { 
    rut, 
    nombre, 
    correo, 
    clave, 
    rol, 
    telefono,
    edad,
    aut2FA,
    active,
    intentos_fallidos,
    cuenta_bloqueada
  } = req.body;

  // Validaciones
  if (!usuarioId) {
    return res.status(400).json({
      success: false,
      error: 'ID de usuario es requerido'
    });
  }

  const updateRequest = {
    id: usuarioId,
    rut: rut ? rut.toString().trim() : undefined,
    nombre: nombre ? nombre.toString().trim() : undefined,
    correo: correo ? correo.toString().trim() : undefined,
    clave: clave ? clave.toString().trim() : undefined,
    rol: rol ? rol.toString().trim() : undefined,
    telefono: telefono !== undefined ? telefono.toString().trim() : undefined,
    edad: edad !== undefined ? Number(edad) : undefined,
    aut2FA: aut2FA !== undefined ? Boolean(aut2FA) : undefined,
    active: active !== undefined ? Boolean(active) : undefined,
    intentos_fallidos: intentos_fallidos !== undefined ? Number(intentos_fallidos) : undefined,
    cuenta_bloqueada: cuenta_bloqueada !== undefined ? Boolean(cuenta_bloqueada) : undefined
  };

  // Eliminar campos undefined
  Object.keys(updateRequest).forEach(key => {
    if (updateRequest[key] === undefined) {
      delete updateRequest[key];
    }
  });

  usuarioClient.UpdateUsuario(updateRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al actualizar usuario:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo actualizar el usuario'}`
      });
    }
    
    res.json({
      success: true,
      usuario: response,
      message: 'Usuario actualizado exitosamente'
    });
  });
});

// ELIMINAR usuario - DELETE /api/usuarios/:id
router.delete('/:id', (req, res) => {
  const usuarioId = req.params.id;

  if (!usuarioId) {
    return res.status(400).json({
      success: false,
      error: 'ID de usuario es requerido'
    });
  }

  usuarioClient.DeleteUsuario({ id: usuarioId }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al eliminar usuario:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo eliminar el usuario'}`
      });
    }
    
    res.json({
      success: true,
      ok: response.ok,
      message: 'Usuario eliminado exitosamente'
    });
  });
});

module.exports = router;