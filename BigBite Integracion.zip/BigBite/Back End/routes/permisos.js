const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const router = express.Router();

const permisoDef = protoLoader.loadSync('./protos/permiso.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const permisoProto = grpc.loadPackageDefinition(permisoDef).permisos;

const client = new permisoProto.PermisosService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// LISTAR permisos - GET /api/permisos
router.get('/', (req, res) => {
  client.ListPermisos({}, (err, response) => {
    if (err) {
      console.error('Error listando permisos:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al listar permisos' 
      });
    }
    res.json({ 
      success: true, 
      permisos: response.permisos
    });
  });
});

// CREAR permiso - POST /api/permisos
router.post('/', (req, res) => {
  
  const { codigo, nombre, descripcion } = req.body;

  if (!codigo || !nombre) {
    return res.status(400).json({
      success: false,
      error: 'Faltan campos requeridos: codigo, nombre'
    });
  }

  const createRequest = {
    codigo: codigo.toString().trim(),
    nombre: nombre.toString().trim(),
    descripcion: descripcion ? descripcion.toString().trim() : ''
  };

  client.CreatePermiso(createRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al crear permiso:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo crear el permiso'}`
      });
    }
    
    res.json({
      success: true,
      permiso: response,
      message: 'Permiso creado exitosamente'
    });
  });
});

// ACTUALIZAR permiso - PUT /api/permisos/:id
router.put('/:id', (req, res) => {
  const permisoId = req.params.id;
  const { codigo, nombre, descripcion } = req.body;

  if (!permisoId) {
    return res.status(400).json({
      success: false,
      error: 'ID de permiso es requerido'
    });
  }

  const updateRequest = {
    id: permisoId,
    codigo: codigo ? codigo.toString().trim() : undefined,
    nombre: nombre ? nombre.toString().trim() : undefined,
    descripcion: descripcion !== undefined ? descripcion.toString().trim() : undefined
  };

  client.UpdatePermiso(updateRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al actualizar permiso:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo actualizar el permiso'}`
      });
    }
    
    res.json({
      success: true,
      permiso: response,
      message: 'Permiso actualizado exitosamente'
    });
  });
});

// ELIMINAR permiso - DELETE /api/permisos/:id
router.delete('/:id', (req, res) => {
  const permisoId = req.params.id;

  if (!permisoId) {
    return res.status(400).json({
      success: false,
      error: 'ID de permiso es requerido'
    });
  }

  client.DeletePermiso({ id: permisoId }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al eliminar permiso:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo eliminar el permiso'}`
      });
    }
    
    res.json({
      success: true,
      ok: response.ok,
      message: 'Permiso eliminado exitosamente'
    });
  });
});

module.exports = router;