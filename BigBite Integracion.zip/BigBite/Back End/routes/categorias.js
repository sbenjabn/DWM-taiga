const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const router = express.Router();

const categoriaDef = protoLoader.loadSync('./protos/categoria.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const categoriaProto = grpc.loadPackageDefinition(categoriaDef).categorias;

const client = new categoriaProto.CategoriasService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// GET /api/categorias - Listar categorías (esto ya existe)
router.get('/', (req, res) => {
  const { page = 1, pageSize = 10, q = '', onlyActive = false } = req.query;
  client.ListCategorias({ page: Number(page), pageSize: Number(pageSize), q, onlyActive: onlyActive === 'true' }, (err, response) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(response);
  });
});

// POST /api/categorias - Crear categoría (NECESITAS AGREGAR ESTO)
router.post('/', (req, res) => {
  const { codigo, nombre, descripcion } = req.body;

  if (!codigo || !nombre) {
    return res.status(400).json({
      success: false,
      error: 'Código y nombre son obligatorios'
    });
  }

  client.CreateCategoria({
    codigo,
    nombre, 
    descripcion: descripcion || ''
  }, (err, response) => {
    if (err) {
      console.error(' Error gRPC crear categoría:', err);
      return res.status(500).json({
        success: false,
        error: 'Error al crear categoría: ' + err.message
      });
    }
    
    res.json({
      success: true,
      categoria: response
    });
  });
});

//PUT
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { codigo, nombre, descripcion } = req.body;
  
  if (!codigo || !nombre) {
    return res.status(400).json({
      success: false,
      error: 'Código y nombre son obligatorios'
    });
  }

  client.UpdateCategoria({
    id: id,
    codigo: codigo,
    nombre: nombre,
    descripcion: descripcion || ''
  }, (err, response) => {
    if (err) {
      console.error(' Error gRPC actualizar categoría:', err);
      return res.status(500).json({
        success: false,
        error: 'Error al actualizar categoría: ' + err.message
      });
    }
    
    res.json({
      success: true,
      categoria: response
    });
  });
});

//DELETE
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  
  if (!id) {
    return res.status(400).json({
      success: false,
      error: 'ID es obligatorio'
    });
  }

  client.DeleteCategoria({ id }, (err, response) => {
    if (err) {
      console.error(' Error gRPC eliminar categoría:', err);
      return res.status(500).json({
        success: false,
        error: 'Error al eliminar categoría: ' + err.message
      });
    }
    
    res.json({
      success: true,
      ok: response.ok
    });
  });
});

// GET /api/categorias/count - Contar categorías (esto ya existe)
router.get('/count', (req, res) => {
  client.CountCategorias({}, (err, response) => {  
    if (err) {
      console.error('Error counting categorias:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al contar categorias' 
      });
    }
    res.json({ 
      success: true, 
      total: response.total 
    });
  });
});

module.exports = router;