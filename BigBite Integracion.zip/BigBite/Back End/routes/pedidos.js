const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const router = express.Router();

const pedidoDef = protoLoader.loadSync('./protos/pedido.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const pedidoProto = grpc.loadPackageDefinition(pedidoDef).pedidos;

const client = new pedidoProto.PedidosService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// Contar total de pedidos
router.get('/count', (req, res) => {
  client.CountPedidos({}, (err, response) => {
    if (err) {
      console.error('Error counting pedidos:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al contar pedidos' 
      });
    }
    res.json({ 
      success: true, 
      total: response.total 
    });
  });
});

// Contar pedidos por estado
router.get('/count-by-estado', (req, res) => {
  client.CountByEstado({}, (err, response) => {
    if (err) {
      console.error('Error counting pedidos por estado:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al contar pedidos por estado' 
      });
    }
    res.json({ 
      success: true, 
      data: response 
    });
  });
});

// POST /api/pedidos - Crear nuevo pedido
router.post('/', (req, res) => {
  const { cliente_id, detalles, total } = req.body;
  
  // Validaciones básicas
  if (!cliente_id || !detalles || !Array.isArray(detalles) || detalles.length === 0) {
    return res.status(400).json({
      success: false,
      error: 'cliente_id y detalles son obligatorios'
    });
  }

  // Generar número de pedido único
  const num_pedido = 'PED' + Date.now();
  
  // Preparar datos para gRPC según tu proto
  const pedidoRequest = {
    num_pedido: num_pedido,
    fecha_pedido: {
      seconds: Math.floor(Date.now() / 1000),
      nanos: 0
    },
    rut_cliente: cliente_id,
    fuente: 1, // DOMICILIO
    estado: 0, // PENDIENTE
    medio: 3, // EFECTIVO
    info_entrega: 'Pedido desde aplicación web',
    total_pedido: total
  };

  // Llamar al servicio gRPC
  client.CreatePedido(pedidoRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC crear pedido:', err);
      return res.status(500).json({
        success: false,
        error: 'Error al crear pedido: ' + err.message
      });
    }
    
    res.json({
      success: true,
      pedido: response,
      numero_pedido: response.num_pedido,
      mensaje: 'Pedido creado exitosamente'
    });
  });
});

// GET /api/pedidos - Listar pedidos
router.get('/', (req, res) => {
  const { page = 1, pageSize = 10, q = '', onlyActive = false, rut_cliente, estado } = req.query;
  
  const request = {
    page: Number(page),
    pageSize: Number(pageSize),
    q: q,
    onlyActive: onlyActive === 'true'
  };

  // Agregar filtros opcionales
  if (rut_cliente) request.rut_cliente = rut_cliente;
  if (estado) request.estado = Number(estado);

  client.ListPedidos(request, (err, response) => {
    if (err) {
      console.error('Error listando pedidos:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      ...response
    });
  });
});

// GET /api/pedidos/:id - Obtener pedido por ID
router.get('/:id', (req, res) => {
  const { id } = req.params;
  
  client.GetPedido({ id }, (err, response) => {
    if (err) {
      console.error('Error obteniendo pedido:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      pedido: response
    });
  });
});

// GET /api/pedidos/numero/:num_pedido - Obtener pedido por número
router.get('/numero/:num_pedido', (req, res) => {
  const { num_pedido } = req.params;
  
  client.GetByNumero({ num_pedido }, (err, response) => {
    if (err) {
      console.error('Error obteniendo pedido por número:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      pedido: response
    });
  });
});

// GET /api/pedidos/estado/:estado - Listar pedidos por estado
router.get('/estado/:estado', (req, res) => {
  const { estado } = req.params;
  const { page = 1, pageSize = 10 } = req.query;
  
  client.GetByEstado({
    estado: Number(estado),
    page: Number(page),
    pageSize: Number(pageSize)
  }, (err, response) => {
    if (err) {
      console.error('Error listando pedidos por estado:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      ...response
    });
  });
});

// GET /api/pedidos/cliente/:rut_cliente - Listar pedidos por cliente
router.get('/cliente/:rut_cliente', (req, res) => {
  const { rut_cliente } = req.params;
  const { page = 1, pageSize = 10 } = req.query;
  
  client.ListPedidos({
    rut_cliente: rut_cliente,
    page: Number(page),
    pageSize: Number(pageSize)
  }, (err, response) => {
    if (err) {
      console.error('Error listando pedidos por cliente:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      ...response
    });
  });
});

// PUT /api/pedidos/:id - Actualizar pedido
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { num_pedido, rut_cliente, fuente, estado, medio, info_entrega, total_pedido } = req.body;
  
  const updateRequest = {
    id: id,
    num_pedido: num_pedido,
    rut_cliente: rut_cliente,
    fuente: fuente,
    estado: estado,
    medio: medio,
    info_entrega: info_entrega,
    total_pedido: total_pedido
  };

  // Eliminar campos undefined
  Object.keys(updateRequest).forEach(key => {
    if (updateRequest[key] === undefined) {
      delete updateRequest[key];
    }
  });

  client.UpdatePedido(updateRequest, (err, response) => {
    if (err) {
      console.error('Error actualizando pedido:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      pedido: response
    });
  });
});

// DELETE /api/pedidos/:id - Eliminar pedido
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  
  client.DeletePedido({ id }, (err, response) => {
    if (err) {
      console.error('Error eliminando pedido:', err);
      return res.status(500).json({ 
        success: false,
        error: err.message 
      });
    }
    res.json({
      success: true,
      ok: response.ok,
      mensaje: 'Pedido eliminado exitosamente'
    });
  });
});

// Endpoints de conteo que ya tenías
router.get('/count', (req, res) => {
  client.CountPedidos({}, (err, response) => {
    if (err) {
      console.error('Error counting pedidos:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al contar pedidos' 
      });
    }
    res.json({ 
      success: true, 
      total: response.total 
    });
  });
});

//***********************************************************/

//***********************************************************/

module.exports = router;