const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const router = express.Router();

const rolDef = protoLoader.loadSync('./protos/rol.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const rolProto = grpc.loadPackageDefinition(rolDef).roles;

const client = new rolProto.RolesService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// LISTAR roles - GET /api/roles
router.get('/', (req, res) => {
  client.ListRoles({}, (err, response) => {
    if (err) {
      console.error('Error listando roles:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al listar roles' 
      });
    }
    res.json({ 
      success: true, 
      roles: response.roles
    });
  });
});

// CREAR rol - POST /api/roles
router.post('/', (req, res) => {
  
  const { codigo, nombre, descripcion } = req.body;

  if (!codigo || !nombre) {
    return res.status(400).json({
      success: false,
      error: 'Faltan campos requeridos: codigo, nombre'
    });
  }

  const createRequest = {
    codigo: codigo.toString().trim(),
    nombre: nombre.toString().trim(),
    descripcion: descripcion ? descripcion.toString().trim() : ''
  };

  client.CreateRol(createRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al crear rol:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo crear el rol'}`
      });
    }
    
    res.json({
      success: true,
      rol: response,
      message: 'Rol creado exitosamente'
    });
  });
});

// ACTUALIZAR rol - PUT /api/roles/:id
router.put('/:id', (req, res) => {
  const rolId = req.params.id;
  
  const { codigo, nombre, descripcion } = req.body;

  if (!rolId) {
    return res.status(400).json({
      success: false,
      error: 'ID de rol es requerido'
    });
  }

  const updateRequest = {
    id: rolId,
    codigo: codigo ? codigo.toString().trim() : undefined,
    nombre: nombre ? nombre.toString().trim() : undefined,
    descripcion: descripcion !== undefined ? descripcion.toString().trim() : undefined
  };

  client.UpdateRol(updateRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al actualizar rol:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo actualizar el rol'}`
      });
    }
    
    res.json({
      success: true,
      rol: response,
      message: 'Rol actualizado exitosamente'
    });
  });
});

// ELIMINAR rol - DELETE /api/roles/:id
router.delete('/:id', (req, res) => {
  const rolId = req.params.id;

  if (!rolId) {
    return res.status(400).json({
      success: false,
      error: 'ID de rol es requerido'
    });
  }

  client.DeleteRol({ id: rolId }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al eliminar rol:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo eliminar el rol'}`
      });
    }
    
    res.json({
      success: true,
      ok: response.ok,
      message: 'Rol eliminado exitosamente'
    });
  });
});

// OBTENER rol por código - GET /api/roles/codigo/:codigo
router.get('/codigo/:codigo', (req, res) => {
  const codigoRol = req.params.codigo;

  client.GetRolByCodigo({ codigo: codigoRol }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al obtener rol por código:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo obtener el rol'}`
      });
    }
    
    res.json({
      success: true,
      rol: response
    });
  });
});

module.exports = router;