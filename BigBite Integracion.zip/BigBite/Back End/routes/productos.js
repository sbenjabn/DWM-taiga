const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const router = express.Router();

const productoDef = protoLoader.loadSync('./protos/producto.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const productoProto = grpc.loadPackageDefinition(productoDef).productos;

const client = new productoProto.ProductosService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// CREAR producto - POST /api/productos
router.post('/', (req, res) => {
  
  const { 
    codigo, 
    nombre, 
    descripcion, 
    precio, 
    id_categoria, 
    ingredientes, 
    stock_disponible, 
    url_imagen, 
    active = true 
  } = req.body;

  // Validaciones básicas
  if (!codigo || !nombre || !id_categoria) {
    return res.status(400).json({
      success: false,
      error: 'Faltan campos requeridos: codigo, nombre, id_categoria'
    });
  }

  if (precio === undefined || precio < 0) {
    return res.status(400).json({
      success: false,
      error: 'El precio es requerido y debe ser no negativo'
    });
  }

  const createRequest = {
    codigo: codigo.toString().trim(),
    nombre: nombre.toString().trim(),
    descripcion: descripcion ? descripcion.toString().trim() : '',
    precio: Number(precio),
    id_categoria: id_categoria.toString().trim(),
    ingredientes: Array.isArray(ingredientes) ? ingredientes : [],
    stock_disponible: stock_disponible ? Number(stock_disponible) : 0,
    url_imagen: url_imagen ? url_imagen.toString().trim() : '',
    active: Boolean(active)
  };

  client.CreateProducto(createRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al crear producto:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo crear el producto'}`
      });
    }
    
    res.json({
      success: true,
      producto: response,
      message: 'Producto creado exitosamente'
    });
  });
});

// ACTUALIZAR producto - PUT /api/productos/:id
router.put('/:id', (req, res) => {
  const productId = req.params.id;
  const { 
    codigo, 
    nombre, 
    descripcion, 
    precio, 
    id_categoria, 
    ingredientes, 
    stock_disponible, 
    url_imagen, 
    active 
  } = req.body;

  // Validaciones
  if (!productId) {
    return res.status(400).json({
      success: false,
      error: 'ID de producto es requerido'
    });
  }

  const updateRequest = {
    id: productId,
    codigo: codigo ? codigo.toString().trim() : undefined,
    nombre: nombre ? nombre.toString().trim() : undefined,
    descripcion: descripcion !== undefined ? descripcion.toString().trim() : undefined,
    precio: precio !== undefined ? Number(precio) : undefined,
    id_categoria: id_categoria ? id_categoria.toString().trim() : undefined,
    ingredientes: ingredientes !== undefined ? (Array.isArray(ingredientes) ? ingredientes : []) : undefined,
    stock_disponible: stock_disponible !== undefined ? Number(stock_disponible) : undefined,
    url_imagen: url_imagen !== undefined ? url_imagen.toString().trim() : undefined,
    active: active !== undefined ? Boolean(active) : undefined
  };

  // Eliminar campos undefined
  Object.keys(updateRequest).forEach(key => {
    if (updateRequest[key] === undefined) {
      delete updateRequest[key];
    }
  });

  client.UpdateProducto(updateRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al actualizar producto:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo actualizar el producto'}`
      });
    }
    
    res.json({
      success: true,
      producto: response,
      message: 'Producto actualizado exitosamente'
    });
  });
});

// ELIMINAR producto - DELETE /api/productos/:id
router.delete('/:id', (req, res) => {
  const productId = req.params.id;

  if (!productId) {
    return res.status(400).json({
      success: false,
      error: 'ID de producto es requerido'
    });
  }

  client.DeleteProducto({ id: productId }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al eliminar producto:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo eliminar el producto'}`
      });
    }
    
    res.json({
      success: true,
      ok: response.ok,
      message: 'Producto eliminado exitosamente'
    });
  });
});

// Listar productos
router.get('/', (req, res) => {
  const { page = 1, pageSize = 10, q = '', onlyActive = false } = req.query;
  client.ListProductos({ page: Number(page), pageSize: Number(pageSize), q, onlyActive: onlyActive === 'true' }, (err, response) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(response);
  });
});

// Contar productos
router.get('/count', (req, res) => {
  client.CountProductos({}, (err, response) => {  
    if (err) {
      console.error('Error counting productos:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al contar productos' 
      });
    }
    res.json({ 
      success: true, 
      total: response.total 
    });
  });
});

// OBTENER producto por ID - GET /api/productos/:id
router.get('/:id', (req, res) => {
    const productId = req.params.id;
    
    if (!productId) {
        return res.status(400).json({
            success: false,
            error: 'ID de producto es requerido'
        });
    }
    
    client.GetProducto({ id: productId }, (err, response) => {
        if (err) {
            console.error(' Error gRPC al buscar producto por ID:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message}`
            });
        }
        
        if (response && response.id) {
            res.json({
                success: true,
                producto: response
            });
        } else {
            res.status(404).json({
                success: false,
                error: 'Producto no encontrado'
            });
        }
    });
});



module.exports = router;