const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const { MongoClient } = require('mongodb');
const router = express.Router();

// === CONEXIÓN MONGODB - USANDO TUS VARIABLES EXISTENTES ===
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const MONGODB_DB = process.env.MONGODB_DB || "BigBite";
let db;

// Conectar a MongoDB
MongoClient.connect(MONGODB_URI)
    .then(client => {
        db = client.db(MONGODB_DB);
    })
    .catch(error => {
        console.error(' Error conectando MongoDB en routes:', error);
    });

const rolPermisoDef = protoLoader.loadSync('./protos/rolPermiso.proto', {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});
const rolPermisoProto = grpc.loadPackageDefinition(rolPermisoDef).rolPermisos;

const client = new rolPermisoProto.RolesPermisosService(
  `localhost:${process.env.GRPC_PORT || 50051}`,
  grpc.credentials.createInsecure()
);

// ASIGNAR permiso a rol - POST /api/roles-permisos
router.post('/', (req, res) => {
  
  const { codigo_rol, codigo_permiso } = req.body;

  if (!codigo_rol || !codigo_permiso) {
    return res.status(400).json({
      success: false,
      error: 'Faltan campos requeridos: codigo_rol, codigo_permiso'
    });
  }

  const createRequest = {
    codigo_rol: codigo_rol.toString().trim(),
    codigo_permiso: codigo_permiso.toString().trim()
  };

  client.CreateRolPermiso(createRequest, (err, response) => {
    if (err) {
      console.error(' Error gRPC al asignar permiso a rol:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo asignar el permiso al rol'}`
      });
    }
    
    res.json({
      success: true,
      rol_permiso: response,
      message: 'Permiso asignado al rol exitosamente'
    });
  });
});

// OBTENER permisos por rol - POST /api/roles-permisos/permisos
router.post('/permisos', (req, res) => {
    const { codigo_rol } = req.body;

    if (!codigo_rol) {
        return res.status(400).json({
            success: false,
            error: 'El campo codigo_rol es requerido'
        });
    }

    client.GetPermisosPorRol({ codigo_rol: codigo_rol }, (err, response) => {
        if (err) {
            console.error(' Error gRPC al obtener permisos por rol:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudieron obtener los permisos del rol'}`
            });
        }
        
        res.json({
            success: true,
            permisos: response.permisos || []
        });
    });
});

// OBTENER permisos por rol - GET /api/roles-permisos/permisos/:codigoRol
router.get('/permisos/:codigoRol', (req, res) => {
  const codigoRol = req.params.codigoRol;

  client.GetPermisosPorRol({ codigo_rol: codigoRol }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al obtener permisos por rol:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudieron obtener los permisos del rol'}`
      });
    }
    
    res.json({
      success: true,
      permisos: response.permisos || []
    });
  });
});

// OBTENER roles por permiso - GET /api/roles-permisos/roles/:codigoPermiso
router.get('/roles/:codigoPermiso', (req, res) => {
  const codigoPermiso = req.params.codigoPermiso;

  client.GetRolesPorPermiso({ codigo_permiso: codigoPermiso }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al obtener roles por permiso:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudieron obtener los roles del permiso'}`
      });
    }
    
    res.json({
      success: true,
      roles: response.roles || []
    });
  });
});

// LISTAR todas las asignaciones roles-permisos - GET /api/roles-permisos
router.get('/', (req, res) => {
  client.ListRolesPermisos({}, (err, response) => {
    if (err) {
      console.error('Error listando roles-permisos:', err);
      return res.status(500).json({ 
        success: false, 
        error: 'Error interno del servidor al listar asignaciones roles-permisos' 
      });
    }
    res.json({ 
      success: true, 
      roles_permisos: response.roles_permisos
    });
  });
});

// ELIMINAR asignación rol-permiso - DELETE /api/roles-permisos/:id
router.delete('/:id', (req, res) => {
  const asignacionId = req.params.id;

  if (!asignacionId) {
    return res.status(400).json({
      success: false,
      error: 'ID de asignación es requerido'
    });
  }

  client.DeleteRolPermiso({ id: asignacionId }, (err, response) => {
    if (err) {
      console.error(' Error gRPC al eliminar asignación rol-permiso:', err);
      return res.status(500).json({
        success: false,
        error: `Error del servidor: ${err.message || 'No se pudo eliminar la asignación'}`
      });
    }
    
    res.json({
      success: true,
      ok: response.ok,
      message: 'Asignación eliminada exitosamente'
    });
  });
});

// ELIMINAR todos los permisos de un rol - DELETE /api/roles-permisos/rol/:codigoRol
// ELIMINAR todos los permisos de un rol - DELETE /api/roles-permisos/rol/:codigoRol
router.delete('/rol/:codigoRol', async (req, res) => {
    const codigoRol = req.params.codigoRol;

    try {
        // Esto SOLO elimina de la colección RolesPermisos, NO de Permisos
        const result = await db.collection("RolesPermisos").deleteMany({ 
            codigo_rol: codigoRol 
        });
        
        res.json({
            success: true,
            message: `${result.deletedCount} relaciones eliminadas del rol ${codigoRol} en RolesPermisos`,
            deletedCount: result.deletedCount
        });

    } catch (error) {
        console.error(' Error eliminando relaciones del rol:', error);
        res.status(500).json({
            success: false,
            error: `Error del servidor: ${error.message}`
        });
    }
});

// ELIMINAR permiso específico de un rol - DELETE /api/roles-permisos/rol/:codigoRol/permiso/:codigoPermiso
// ELIMINAR permiso específico de un rol - DELETE /api/roles-permisos/rol/:codigoRol/permiso/:codigoPermiso
router.delete('/rol/:codigoRol/permiso/:codigoPermiso', async (req, res) => {
    const { codigoRol, codigoPermiso } = req.params;

    try {
        // SOLUCIÓN DIRECTA: Eliminar usando MongoDB directamente
        const result = await db.collection("RolesPermisos").deleteOne({ 
            codigo_rol: codigoRol, 
            codigo_permiso: codigoPermiso 
        });
        
        if (result.deletedCount === 0) {
            return res.status(404).json({
                success: false,
                error: `No se encontró el permiso ${codigoPermiso} asignado al rol ${codigoRol}`
            });
        }

        res.json({
            success: true,
            message: `Permiso ${codigoPermiso} eliminado del rol ${codigoRol}`,
            deletedCount: result.deletedCount
        });

    } catch (error) {
        console.error(' Error eliminando permiso específico:', error);
        res.status(500).json({
            success: false,
            error: `Error del servidor: ${error.message}`
        });
    }
});

module.exports = router;