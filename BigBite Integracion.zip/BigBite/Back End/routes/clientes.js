const express = require('express');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const { MongoClient } = require('mongodb');
const router = express.Router();

// Configuración de conexión MongoDB
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const MONGODB_DB = process.env.MONGODB_DB || "BigBite";
let db;

// Conectar a MongoDB
MongoClient.connect(MONGODB_URI)
    .then(client => {
        db = client.db(MONGODB_DB);
    })
    .catch(error => {
        console.error(' Error conectando MongoDB en routes/clientes:', error);
    });

// Cargar proto de clientes
const clienteDef = protoLoader.loadSync('./protos/cliente.proto', {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
});

const clienteProto = grpc.loadPackageDefinition(clienteDef).clientes;

// Cliente gRPC
const client = new clienteProto.ClientesService(
    `localhost:${process.env.GRPC_PORT || 50051}`,
    grpc.credentials.createInsecure()
);

// CREAR cliente - POST /api/clientes
router.post('/', (req, res) => {

    const { 
        rut, 
        correo, 
        nombre, 
        telefono, 
        direccion, 
        edad, 
        intentos_fallidos = 0, 
        cuenta_bloqueada = false, 
        active = true,
        clave 
    } = req.body;

    // Validaciones básicas
    if (!rut || !correo || !nombre || !clave) {
        return res.status(400).json({
            success: false,
            error: 'Faltan campos requeridos: rut, correo, nombre, clave'
        });
    }

    const createRequest = {
        rut: rut.toString().trim(),
        correo: correo.toString().trim(),
        nombre: nombre.toString().trim(),
        telefono: telefono ? telefono.toString().trim() : '',
        direccion: direccion ? direccion.toString().trim() : '',
        edad: edad || 0,
        intentos_fallidos: intentos_fallidos || 0,
        cuenta_bloqueada: cuenta_bloqueada || false,
        active: active !== false,
        clave: clave.toString().trim()
    };

    client.CreateCliente(createRequest, (err, response) => {
        if (err) {
            console.error(' Error gRPC al crear cliente:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo crear el cliente'}`
            });
        }

        res.json({
            success: true,
            cliente: response
        });
    });
});

// OBTENER cliente por ID - GET /api/clientes/:id
router.get('/:id', (req, res) => {
    const id = req.params.id;
    client.GetCliente({ id }, (err, response) => {
        if (err) {
            console.error(' Error gRPC al obtener cliente:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo obtener el cliente'}`
            });
        }

        res.json({
            success: true,
            cliente: response
        });
    });
});

// OBTENER cliente por RUT - GET /api/clientes/rut/:rut
router.get('/rut/:rut', (req, res) => {
    const rut = req.params.rut;

    client.GetClienteByRut({ rut }, (err, response) => {
        if (err) {
            console.error(' Error gRPC al obtener cliente por RUT:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo obtener el cliente'}`
            });
        }

        res.json({
            success: true,
            cliente: response
        });
    });
});

// OBTENER cliente por CORREO - GET /api/clientes/correo/:correo
router.get('/correo/:correo', (req, res) => {
    const correo = req.params.correo;

    client.GetClienteByCorreo({ correo }, (err, response) => {
        if (err) {
            console.error(' Error gRPC al obtener cliente por correo:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo obtener el cliente'}`
            });
        }

        res.json({
            success: true,
            cliente: response
        });
    });
});

// LISTAR clientes - GET /api/clientes
router.get('/', (req, res) => {
    const { 
        page = 1, 
        pageSize = 10, 
        q = "", 
        onlyActive = false 
    } = req.query;

    const listRequest = {
        page: parseInt(page),
        pageSize: parseInt(pageSize),
        q: q.toString().trim(),
        onlyActive: onlyActive === 'true'
    };

    client.ListClientes(listRequest, (err, response) => {
        if (err) {
            console.error(' Error gRPC al listar clientes:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudieron listar los clientes'}`
            });
        }

        res.json({
            success: true,
            clientes: response.clientes || [],
            page: response.page || 1,
            pageSize: response.pageSize || 10,
            total: response.total || 0
        });
    });
});

// ACTUALIZAR cliente - PUT /api/clientes/:id
router.put('/:id', (req, res) => {
    const id = req.params.id;

    const updateRequest = {
        ...req.body,
        id: id
    };

    // No enviar campos undefined
    Object.keys(updateRequest).forEach(key => {
        if (updateRequest[key] === undefined) {
            delete updateRequest[key];
        }
    });


    client.UpdateCliente(updateRequest, (err, response) => {
        if (err) {
            console.error(' Error gRPC al actualizar cliente:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo actualizar el cliente'}`
            });
        }

        res.json({
            success: true,
            cliente: response
        });
    });
});

// ELIMINAR cliente - DELETE /api/clientes/:id
router.delete('/:id', (req, res) => {
    const id = req.params.id;

    client.DeleteCliente({ id }, (err, response) => {
        if (err) {
            console.error(' Error gRPC al eliminar cliente:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo eliminar el cliente'}`
            });
        }

        res.json({
            success: true,
            ok: response.ok,
            message: 'Cliente eliminado exitosamente'
        });
    });
});

// LOGIN cliente - POST /api/clientes/login
router.post('/login', async (req, res) => {
    const { correo, clave } = req.body;

    if (!correo || !clave) {
        return res.status(400).json({
            success: false,
            error: 'Faltan campos requeridos: correo, clave'
        });
    }

    const validarRequest = {
        correo: correo.toString().trim(),
        clave: clave.toString().trim()
    };


    client.ValidarCliente(validarRequest, async (err, response) => {
        if (err) {
            console.error(' Error gRPC al validar cliente:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudo validar el cliente'}`
            });
        }


        if (response.valido) {
            try {
                // OBTENER DATOS COMPLETOS DEL CLIENTE después de la validación
                
                // Buscar cliente por correo para obtener todos los datos
                client.GetClienteByCorreo({ correo: correo }, (err, clienteData) => {
                    if (err) {
                        console.error(' Error obteniendo datos del cliente:', err);
                        // Si falla, al menos devolver que es válido
                        return res.json({
                            success: true,
                            valido: true,
                            cliente: {
                                correo: correo,
                                nombre: 'Cliente'
                            }
                        });
                    }

                    res.json({
                        success: true,
                        valido: true,
                        cliente: {
                            id: clienteData.id,
                            rut: clienteData.rut,
                            correo: clienteData.correo,
                            nombre: clienteData.nombre,
                            telefono: clienteData.telefono,
                            direccion: clienteData.direccion
                        }
                    });
                });
                
            } catch (error) {
                console.error(' Error en proceso de login:', error);
                res.json({
                    success: true,
                    valido: true,
                    cliente: {
                        correo: correo,
                        nombre: 'Cliente'
                    }
                });
            }
        } else {
            res.json({
                success: false,
                valido: false,
                error: 'Credenciales inválidas'
            });
        }
    });
});

// CONTAR clientes - GET /api/clientes/count
router.get('/count/total', (req, res) => {

    client.CountClientes({}, (err, response) => {
        if (err) {
            console.error('Error gRPC al contar clientes:', err);
            return res.status(500).json({
                success: false,
                error: `Error del servidor: ${err.message || 'No se pudieron contar los clientes'}`
            });
        }

        res.json({
            success: true,
            total: response.total
        });
    });
});

module.exports = router;