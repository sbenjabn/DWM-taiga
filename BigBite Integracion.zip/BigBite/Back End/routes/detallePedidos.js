const express = require('express');
const router = express.Router();
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// Cargar el proto de detallePedido
const detallePedidoDef = protoLoader.loadSync(
  path.join(__dirname, '../protos/detallePedido.proto'),
  {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
  }
);

const detallePedidoProto = grpc.loadPackageDefinition(detallePedidoDef).detallePedidos;
const client = new detallePedidoProto.DetallePedidosService(
  'localhost:50051',
  grpc.credentials.createInsecure()
);

// Helper gRPC (igual que en tus otras rutas)
function grpcCallback(res, transform = null) {
  return (error, response) => {
    if (error) {
      console.error('Error gRPC:', error);
      const status = error.code === grpc.status.NOT_FOUND ? 404 : 500;
      res.status(status).json({ 
        error: error.details || 'Error del servidor gRPC'
      });
    } else {
      const result = transform ? transform(response) : response;
      res.json(result);
    }
  };
}

// Crear detalle de pedido
router.post('/', (req, res) => {
  const { num_pedido, cod_producto, cantidad } = req.body;

  if (!num_pedido || !cod_producto || !cantidad) {
    return res.status(400).json({
      error: "Los campos num_pedido, cod_producto y cantidad son obligatorios"
    });
  }

  const request = {
    num_pedido,
    cod_producto,
    cantidad: parseInt(cantidad)
  };

  client.CreateDetallePedido(request, grpcCallback(res, (response) => ({
    id: response.id,
    num_pedido: response.num_pedido,
    cod_producto: response.cod_producto,
    cantidad: response.cantidad
  })));
});

// Obtener detalle de pedido por ID
router.get('/:id', (req, res) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ error: "ID es requerido" });
  }

  const request = { id };

  client.GetDetallePedido(request, grpcCallback(res, (response) => ({
    id: response.id,
    num_pedido: response.num_pedido,
    cod_producto: response.cod_producto,
    cantidad: response.cantidad
  })));
});

// Listar detalles por número de pedido
router.get('/pedido/:num_pedido', (req, res) => {
  const { num_pedido } = req.params;

  if (!num_pedido) {
    return res.status(400).json({ error: "num_pedido es requerido" });
  }

  const request = { num_pedido };

  client.ListDetallePedido(request, grpcCallback(res, (response) => {
   
    return {
      detallePedido: response.detallePedido.map(detalle => ({
        id: detalle.id,
        num_pedido: detalle.num_pedido,
        cod_producto: detalle.cod_producto,
        cantidad: detalle.cantidad
      }))
    };
  }));
});

// Eliminar detalle de pedido
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ error: "ID es requerido" });
  }

  const request = { id };

  client.DeleteDetallePedido(request, grpcCallback(res, (response) => ({
    ok: response.ok,
    message: "Detalle de pedido eliminado"
  })));
});

module.exports = router;