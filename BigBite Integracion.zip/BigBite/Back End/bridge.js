const path = require('path');
const express = require('express');
require('dotenv').config();

const app = express();
app.use(express.json());

//Servir archivos estáticos desde frontend/
const frontendPath = path.join(__dirname, '../front end');
app.use(express.static(frontendPath));

//Ruta explícita para listarProductos.html
app.get('/listarProductos.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'listarProductos.html'));
});

//Ruta explícita para listarCategorias.html
app.get('/listarCategorias.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'listarCategorias.html'));
});

//Ruta explícita para listarUsuarios.html
app.get('/listarUsuarios.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'listarUsuarios.html'));
});

//Ruta explícita para listarPedidos.html
app.get('/listarPedidos.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'listarPedidos.html'));
});

app.get('/pedidos.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'pedidos.html'));
});

// Rutas REST → gRPC
const productosRouter = require('./routes/productos');
app.use('/api/productos', productosRouter);

const categoriasRouter = require('./routes/categorias');
app.use('/api/categorias', categoriasRouter);

const usuariosRouter = require('./routes/usuarios');
app.use('/api/usuarios', usuariosRouter);

const clientesRouter = require('./routes/clientes');
app.use('/api/clientes', clientesRouter);

const pedidosRouter = require('./routes/pedidos');
app.use('/api/pedidos', pedidosRouter);

const detallePedidosRouter = require('./routes/detallePedidos');
app.use('/api/detalle-pedidos', detallePedidosRouter);

const permisosRouter = require('./routes/permisos');
app.use('/api/permisos', permisosRouter);

const rolesRouter = require('./routes/roles');
app.use('/api/roles', rolesRouter);

const rolesPermisosRouter = require('./routes/roles-permisos');
app.use('/api/roles-permisos', rolesPermisosRouter);

// Ruta para el panel de administración
app.get('/administracion.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'administracion.html'));
});



const PORT = 3000;
app.listen(PORT, () => {
  console.log(`REST bridge corriendo en http://localhost:${PORT}`);
});