const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const { MongoClient, ObjectId } = require("mongodb");
const bcrypt = require('bcrypt');
const SALT_ROUNDS = 10;

require("dotenv").config();

const productoDef = protoLoader.loadSync("./protos/producto.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const categoriaDef = protoLoader.loadSync("./protos/categoria.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const permisoDef = protoLoader.loadSync("./protos/permiso.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const rolDef = protoLoader.loadSync("./protos/rol.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const rolPermisoDef = protoLoader.loadSync("./protos/rolpermiso.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const usuarioDef = protoLoader.loadSync("./protos/usuario.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const clienteDef = protoLoader.loadSync("./protos/cliente.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const pedidoDef = protoLoader.loadSync("./protos/pedido.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const detallePedidoDef = protoLoader.loadSync("./protos/detallePedido.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const ventaDef = protoLoader.loadSync("./protos/venta.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const detalleVentaDef = protoLoader.loadSync("./protos/detalleVenta.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const productoProto = grpc.loadPackageDefinition(productoDef).productos;
const categoriaProto = grpc.loadPackageDefinition(categoriaDef).categorias;
const permisoProto = grpc.loadPackageDefinition(permisoDef).permisos;
const rolProto = grpc.loadPackageDefinition(rolDef).roles;
const rolPermisoProto = grpc.loadPackageDefinition(rolPermisoDef).rolPermisos;
const usuarioProto = grpc.loadPackageDefinition(usuarioDef).usuarios;
const clienteProto = grpc.loadPackageDefinition(clienteDef).clientes;
const pedidoProto = grpc.loadPackageDefinition(pedidoDef).pedidos;
const detallePedidoProto = grpc.loadPackageDefinition(detallePedidoDef).detallePedidos;
const ventaProto = grpc.loadPackageDefinition(ventaDef).ventas;
const detalleVentaProto = grpc.loadPackageDefinition(detalleVentaDef).detalleVentas;

//enum de pedido.proto y venta.proto
const EstadoPedido = pedidoProto.EstadoPedido;
const MedioPago = pedidoProto.MedioPago;
const FuentePedido = pedidoProto.FuentePedido;

//Datos conexión
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const MONGODB_DB = process.env.MONGODB_DB || "BigBite";
const GRPC_PORT = process.env.GRPC_PORT || "50051";

let db, productosCol, categoriasCol, permisosCol, rolesCol, rolesPermisosCol, usuariosCol,
    clientesCol, pedidosCol, detallePedidoCol, ventasCol, detalleVentaCol;


//Conversión fechas
function dateToTimestamp(date) {
  const d = new Date(date);
  return {
    seconds: Math.floor(d.getTime() / 1000),
    nanos: (d.getMilliseconds() % 1000) * 1e6
  };
};

function timestampToDate(timestamp) {
  if (!timestamp) return new Date();
  return new Date(timestamp.seconds * 1000 + timestamp.nanos / 1e6);
}

const toDetalleVenta = (doc) => ({
  id: doc._id.toString(),
  num_venta: doc.num_venta,
  cod_producto: doc.cod_producto,
  cantidad: doc.cantidad
});

const toVenta = (doc) => ({
    id: doc._id.toString(),
    num_venta: doc.num_venta,
    num_pedido: doc.num_pedido,
    fecha_venta: dateToTimestamp(doc.fecha_venta),
    rut_cliente: doc.rut_cliente,
    rut_vendedor: doc.rut_vendedor,
    medio: doc.medio
});

const toDetallePedido = (doc) => ({
  id: doc._id.toString(),
  num_pedido: doc.num_pedido,
  cod_producto: doc.cod_producto,
  cantidad: doc.cantidad
});

const toPedido = (doc) => ({
    id: doc._id.toString(),
    num_pedido: doc.num_pedido,
    fecha_pedido: dateToTimestamp(doc.fecha_pedido),
    rut_cliente: doc.rut_cliente,
    fuente: doc.fuente,
    estado: doc.estado,
    medio: doc.medio,
    info_entrega: doc.info_entrega,
    total_pedido:doc.total_pedido
});

const toUsuario = (doc) => ({
  id: doc._id.toString(),
  rut: doc.rut,
  correo: doc.correo,
  nombre: doc.nombre,
  telefono: doc.telefono,
  edad: doc.edad,
  intentos_fallidos: doc.intentos_fallidos,
  aut2FA: !!doc.aut2FA,
  cuenta_bloqueada: !!doc.cuenta_bloqueada,
  active: !!doc.active,
  rol: doc.rol,
  clave: doc.clave,
  creado_en: doc.creado_en?.toISOString() || "",
  actualizado_en: doc.actualizado_en?.toISOString() || ""
});

const toCliente = (doc) => ({
  id: doc._id.toString(),
  rut: doc.rut,
  correo: doc.correo,
  nombre: doc.nombre,
  telefono: doc.telefono,
  direccion:doc.direccion,
  edad: doc.edad,
  intentos_fallidos: doc.intentos_fallidos,
  cuenta_bloqueada: !!doc.cuenta_bloqueada,
  active: !!doc.active,
  clave: doc.clave,
  creado_en: doc.creado_en?.toISOString() || "",
  actualizado_en: doc.actualizado_en?.toISOString() || ""
});

const toRolPermiso = (doc) => ({
  id: doc._id.toString(),
  codigo_rol: doc.codigo_rol,
  codigo_permiso: doc.codigo_permiso
});

const toRol = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion
});

const toPermiso = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion
});

const toCategoria = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion
});

const toProducto = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion,
  precio: doc.precio,
  id_categoria: doc.id_categoria,
  ingredientes: doc.ingredientes || [],
  stock_disponible: doc.stock_disponible,
  url_imagen: doc.url_imagen,
  active: !!doc.active,
  creado_en: doc.creado_en?.toISOString() || "",
  actualizado_en: doc.actualizado_en?.toISOString() || ""
});

//Productos
const handlerProductos = {
  async CreateProducto(call, cb) {
    const { codigo, nombre, descripcion, precio, id_categoria, ingredientes = [], stock_disponible, url_imagen, active = true } = call.request;
    const now = new Date();
    const doc = { codigo, nombre, descripcion, precio, id_categoria, ingredientes, stock_disponible, url_imagen, active, creado_en: now, actualizado_en: now };
    const { insertedId } = await productosCol.insertOne(doc);
    const created = await productosCol.findOne({ _id: insertedId });
    cb(null, toProducto(created));
  },
  async GetProducto(call, cb) {
    const { id } = call.request;
    const producto = await productosCol.findOne({ _id: new ObjectId(id) });
    if (!producto) return cb({ code: grpc.status.NOT_FOUND, message: "Producto no encontrado" });
    cb(null, toProducto(producto));
  },
    async GetProductoByCodigo(call, cb) {
    const { codigo } = call.request;
    const producto = await productosCol.findOne({ codigo });
    if (!producto) return cb({ code: grpc.status.NOT_FOUND, message: "Producto no encontrado" });
    cb(null, toProducto(producto));
  },
  async ListProductos(call, cb) {
    const { page = 1, pageSize = 10, q = "", onlyActive = false } = call.request;
    const filter = {};
    if (q) filter.nombre = { $regex: q, $options: "i" };
    if (onlyActive) filter.active = true;
    const skip = (page - 1) * pageSize;
    const [productos, total] = await Promise.all([
      productosCol.find(filter).skip(skip).limit(pageSize).toArray(),
      productosCol.countDocuments(filter)
    ]);
    cb(null, { productos: productos.map(toProducto), page, pageSize, total });
  },
  async UpdateProducto(call, cb) {
    const { id, ...fields } = call.request;
    const update = { ...fields, actualizado_en: new Date() };
    await productosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await productosCol.findOne({ _id: new ObjectId(id) });
    cb(null, toProducto(updated));
  },
  async DeleteProducto(call, cb) {
    const { id } = call.request;
    const result = await productosCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  },
  async CountProductos(call, callback) {
      try {
          const total = await productosCol.countDocuments();
          callback(null, { total });
      } catch (error) {
          console.error('Error al contar productos:', error);
          callback({
              code: grpc.status.INTERNAL,
              message: 'Error contando productos'
          });
      }
}};

// Categorías
const handlerCategorias = {
  async CreateCategoria(call, cb) {
    const { codigo, nombre, descripcion } = call.request;
    const doc = { codigo, nombre, descripcion };
    const { insertedId } = await categoriasCol.insertOne(doc);
    const created = await categoriasCol.findOne({ _id: insertedId });
    cb(null, toCategoria(created));
  },
  async GetCategoria(call, cb) {
    const { id } = call.request;
    const categoria = await categoriasCol.findOne({ _id: new ObjectId(id) });
    if (!categoria) return cb({ code: grpc.status.NOT_FOUND, message: "Categoría no encontrada" });
    cb(null, toCategoria(categoria));
  },
  async ListCategorias(call, cb) {
    const categorias = await categoriasCol.find().toArray();
    cb(null, { categorias: categorias.map(toCategoria) });
  },
  async UpdateCategoria(call, cb) {
  const { id, codigo, nombre, descripcion } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo !== undefined) update.codigo = codigo;
  if (nombre !== undefined) update.nombre = nombre;
  if (descripcion !== undefined) update.descripcion = descripcion;

  const exists = await categoriasCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Categoría con id '${id}' no encontrada` });

  await categoriasCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await categoriasCol.findOne({ _id: new ObjectId(id) });
  cb(null, toCategoria(updated));
},

async DeleteCategoria(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const result = await categoriasCol.deleteOne({ _id: new ObjectId(id) });
  cb(null, { ok: result.deletedCount > 0 });
},
  async CountCategorias(call, callback) {
      try {
          const total = await categoriasCol.countDocuments();
          callback(null, { total });
      } catch (error) {
          console.error('Error al contar categorias:', error);
          callback({
              code: grpc.status.INTERNAL,
              message: 'Error contando categorias'
          });
      }
}};

// Permisos
const handlerPermisos ={
  async CreatePermiso(call, cb) {
    const { codigo, nombre, descripcion } = call.request;
    const doc = { codigo, nombre, descripcion };
    const { insertedId } = await permisosCol.insertOne(doc);
    const created = await permisosCol.findOne({ _id: insertedId });
    cb(null, toPermiso(created));
  },
  async GetPermiso(call, cb) {
    const { id } = call.request;
    const permiso = await permisosCol.findOne({ _id: new ObjectId(id) });
    if (!permiso) return cb({ code: grpc.status.NOT_FOUND, message: "Permiso no encontrado" });
    cb(null, toPermiso(permiso));
  },
  async ListPermisos(call, cb) {
    const permisos = await permisosCol.find().toArray();
    cb(null, { permisos: permisos.map(toPermiso) });
  },
  async UpdatePermiso(call, cb) {
  const { id, codigo, nombre, descripcion } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo !== undefined) update.codigo = codigo;
  if (nombre !== undefined) update.nombre = nombre;
  if (descripcion !== undefined) update.descripcion = descripcion;

  const exists = await permisosCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Permiso con id '${id}' no encontrado` });

  await permisosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await permisosCol.findOne({ _id: new ObjectId(id) });
  cb(null, toPermiso(updated));
},

async DeletePermiso(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const result = await permisosCol.deleteOne({ _id: new ObjectId(id) });
  cb(null, { ok: result.deletedCount > 0 });
}};

// Roles
const handlerRoles = {
  async CreateRol(call, cb) {
    const { codigo, nombre, descripcion } = call.request;
    const doc = { codigo, nombre, descripcion };
    const { insertedId } = await rolesCol.insertOne(doc);
    const created = await rolesCol.findOne({ _id: insertedId });
    cb(null, toRol(created));
  },
  async GetRol(call, cb) {
    const { id } = call.request;
    const rol = await rolesCol.findOne({ _id: new ObjectId(id) });
    if (!rol) return cb({ code: grpc.status.NOT_FOUND, message: "Rol no encontrado" });
    cb(null, toRol(rol));
  },
  async ListRoles(call, cb) {
    const roles = await rolesCol.find().toArray();
    cb(null, { roles: roles.map(toRol) });
  },
  async UpdateRol(call, cb) {
  const { id, codigo, nombre, descripcion } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo !== undefined) update.codigo = codigo;
  if (nombre !== undefined) update.nombre = nombre;
  if (descripcion !== undefined) update.descripcion = descripcion;

  const exists = await rolesCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Rol con id '${id}' no encontrado` });

  await rolesCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await rolesCol.findOne({ _id: new ObjectId(id) });
  cb(null, toRol(updated));
},

async DeleteRol(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  try {
    // 1. Primero obtener el rol para saber su código
    const rol = await rolesCol.findOne({ _id: new ObjectId(id) });
    
    if (!rol) {
      return cb({ 
        code: grpc.status.NOT_FOUND, 
        message: `Rol con id '${id}' no encontrado` 
      });
    }

    const codigoRol = rol.codigo;

    // 2. Eliminar SOLO las RELACIONES en RolesPermisos que tengan este código de rol
    // NO eliminamos los permisos de la colección Permisos
    const resultRelaciones = await rolesPermisosCol.deleteMany({ 
      codigo_rol: codigoRol 
    });
    
    // 3. Finalmente eliminar el rol de la colección Roles
    const resultRol = await rolesCol.deleteOne({ _id: new ObjectId(id) });
    
    cb(null, { 
      ok: resultRol.deletedCount > 0,
      message: `Rol ${codigoRol} eliminado y ${resultRelaciones.deletedCount} relaciones en RolesPermisos eliminadas`
    });

  } catch (error) {
    console.error('❌ Error eliminando rol y relaciones:', error);
    cb({
      code: grpc.status.INTERNAL,
      message: 'Error del servidor: ' + error.message
    });
  }
},
  async GetRolByCodigo(call, cb) {
    const { codigo } = call.request;
    const rol = await rolesCol.findOne({ codigo });
    if (!rol) return cb({ code: grpc.status.NOT_FOUND, message: "Rol no encontrado" });
    cb(null, toRol(rol));
}};

// Roles Permisos
const handlerRolesPermisos = {
// Función para asignar permiso a rol
async CreateRolPermiso(call, callback) {
    
    const { codigo_rol, codigo_permiso } = call.request;
    
    // Validaciones
    if (!codigo_rol || !codigo_permiso) {
        return callback({
            code: grpc.status.INVALID_ARGUMENT,
            message: 'El código del rol y del permiso son requeridos'
        });
    }
    
    try {
        // Verificar si el rol existe
        const rol = await rolesCol.findOne({ codigo: codigo_rol });
        if (!rol) {
            return callback({
                code: grpc.status.NOT_FOUND,
                message: `El rol con código ${codigo_rol} no existe`
            });
        }
        
        // Verificar si el permiso existe
        const permiso = await permisosCol.findOne({ codigo: codigo_permiso });
        if (!permiso) {
            return callback({
                code: grpc.status.NOT_FOUND,
                message: `El permiso con código ${codigo_permiso} no existe`
            });
        }
        
        // Verificar si la relación ya existe
        const existingRelation = await rolesPermisosCol.findOne({ 
            codigo_rol: codigo_rol, 
            codigo_permiso: codigo_permiso 
        });
        
        if (existingRelation) {
            return callback({
                code: grpc.status.ALREADY_EXISTS,
                message: 'El permiso ya está asignado a este rol'
            });
        }
        
        // Crear la relación
        const rolPermiso = {
            codigo_rol: codigo_rol,
            codigo_permiso: codigo_permiso,
            created_at: new Date(),
            updated_at: new Date()
        };
        
        const result = await rolesPermisosCol.insertOne(rolPermiso);
        const created = await rolesPermisosCol.findOne({ _id: result.insertedId });
        
        callback(null, toRolPermiso(created));
        
    } catch (error) {
        console.error('Error asignando permiso al rol:', error);
        callback({
            code: grpc.status.INTERNAL,
            message: 'Error del servidor: ' + error.message
        });
    }
},

  async GetRolPermiso(call, cb) {
    const { id } = call.request;
    const rolPermiso = await rolesPermisosCol.findOne({ _id: new ObjectId(id) });
    if (!rolPermiso) return cb({ code: grpc.status.NOT_FOUND, message: "Rol/permiso no encontrado" });
    cb(null, toRolPermiso(rolPermiso));
  },
  async ListRolesPermisos(call, cb) {
    const rolesPermisos = await rolesPermisosCol.find().toArray();
    cb(null, { roles_permisos: rolesPermisos.map(toRolPermiso) });
  },
  async UpdateRolPermiso(call, cb) {
  const { id, codigo_rol, codigo_permiso } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo_rol !== undefined) update.codigo_rol = codigo_rol;
  if (codigo_permiso !== undefined) update.codigo_permiso = codigo_permiso;
  
  const exists = await rolesPermisosCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Rol/permiso con id '${id}' no encontrado` });

  await rolesPermisosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await rolesPermisosCol.findOne({ _id: new ObjectId(id) });
  cb(null, toRolPermiso(updated));
},

// Función corregida para eliminar permisos de un rol
async DeleteRolPermiso(call, callback) {
    const { codigo_rol } = call.request;
    
    // Validar que tenemos el código del rol
    if (!codigo_rol) {
        return callback({
            code: grpc.status.INVALID_ARGUMENT,
            message: 'El código del rol es requerido'
        });
    }
    
    try {
        // Buscar y eliminar por código_rol
        const result = await rolesPermisosCol.deleteMany({ codigo_rol: codigo_rol });
        
        callback(null, {
            success: true,
            message: `Se eliminaron ${result.deletedCount} permisos del rol ${codigo_rol}`
        });
        
    } catch (error) {
        console.error('Error eliminando permisos del rol:', error);
        callback({
            code: grpc.status.INTERNAL,
            message: 'Error del servidor: ' + error.message
        });
    }
},
// Función para eliminar permiso específico de un rol
async DeleteRolPermisoEspecifico(call, callback) {
    const { codigo_rol, codigo_permiso } = call.request;
    
    // Validaciones
    if (!codigo_rol || !codigo_permiso) {
        return callback({
            code: grpc.status.INVALID_ARGUMENT,
            message: 'El código del rol y del permiso son requeridos'
        });
    }
    
    try {
        // Buscar y eliminar la relación específica
        const result = await rolesPermisosCol.deleteOne({ 
            codigo_rol: codigo_rol, 
            codigo_permiso: codigo_permiso 
        });
        
        if (result.deletedCount === 0) {
            return callback({
                code: grpc.status.NOT_FOUND,
                message: `No se encontró el permiso ${codigo_permiso} asignado al rol ${codigo_rol}`
            });
        }
        
        callback(null, {
            success: true,
            message: `Permiso ${codigo_permiso} eliminado del rol ${codigo_rol} exitosamente`
        });
        
    } catch (error) {
        console.error('Error eliminando permiso específico del rol:', error);
        callback({
            code: grpc.status.INTERNAL,
            message: 'Error del servidor: ' + error.message
        });
    }
},

// Función para obtener permisos de un rol
// Función para obtener permisos de un rol - CORREGIDA
async GetPermisosPorRol(call, callback) {
    const { codigo_rol } = call.request;
    
    if (!codigo_rol) {
        return callback({
            code: grpc.status.INVALID_ARGUMENT,
            message: 'El código del rol es requerido'
        });
    }
    
    // USAR LOS NOMBRES EXISTENTES:
    // Buscar todos los permisos asociados al rol
    rolesPermisosCol.find({ codigo_rol: codigo_rol }).toArray()
        .then(rolPermisos => {
            // Si no hay relaciones, devolver array vacío
            if (rolPermisos.length === 0) {
                return callback(null, {
                    success: true,
                    permisos: []
                });
            }
            
            // Obtener los detalles de cada permiso
            const permisosPromises = rolPermisos.map(rolPermiso => 
                permisosCol.findOne({ codigo: rolPermiso.codigo_permiso })
            );
            
            return Promise.all(permisosPromises);
        })
        .then(permisos => {
            // Filtrar permisos nulos (por si algún permiso fue eliminado)
            const permisosFiltrados = permisos.filter(permiso => permiso !== null);
            
            callback(null, {
                success: true,
                permisos: permisosFiltrados.map(permiso => ({
                    id: permiso._id ? permiso._id.toString() : '',
                    codigo: permiso.codigo || '',
                    nombre: permiso.nombre || '',
                    descripcion: permiso.descripcion || ''
                }))
            });
        })
        .catch(error => {
            console.error('Error obteniendo permisos del rol:', error);
            callback({
                code: grpc.status.INTERNAL,
                message: 'Error del servidor: ' + error.message
            });
        });
},

async GetRolesPorPermiso(call, cb) {
  const { codigo_permiso } = call.request;
  if (!codigo_permiso) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'codigo_permiso' es obligatorio" });

  const asociaciones = await rolesPermisosCol.find({ codigo_permiso }).toArray();
  const codigosRol = asociaciones.map(a => a.codigo_rol);

  const roles = await rolesCol.find({ codigo: { $in: codigosRol } }).toArray();
  const response = {
    roles: roles.map(r => ({
      id: r._id.toString(),
      codigo: r.codigo,
      nombre: r.nombre,
      descripcion: r.descripcion
    }))
  };

  cb(null, response);
}};

// Usuarios
const handlerUsuarios = {
  async CreateUsuario(call, cb) {
  const { 
    rut, 
    correo, 
    nombre, 
    telefono, 
    edad, 
    intentos_fallidos = 0, 
    aut2FA = false, 
    cuenta_bloqueada = false, 
    active = true, 
    rol, 
    clave 
  } = call.request;
  
  const now = new Date();
  
  // Validar campos requeridos - QUITAR "codigo" de la validación
  if (!rut || !correo || !nombre || !rol || !clave) {
    return cb({
      code: grpc.status.INVALID_ARGUMENT,
      message: 'Los campos rut, correo, nombre, rol y clave son requeridos'
    });
  }
  
  // Verificar si el rut ya existe
  const rutExistente = await usuariosCol.findOne({ rut });
  if (rutExistente) {
    return cb({
      code: grpc.status.ALREADY_EXISTS,
      message: 'Ya existe un usuario con este RUT'
    });
  }
  
  // Verificar si el correo ya existe
  const correoExistente = await usuariosCol.findOne({ correo });
  if (correoExistente) {
    return cb({
      code: grpc.status.ALREADY_EXISTS,
      message: 'Ya existe un usuario con este correo'
    });
  }

  // Encriptar la clave antes de guardar
  const claveEncriptada = await bcrypt.hash(clave, SALT_ROUNDS);

  const doc = { 
    rut, 
    correo, 
    nombre, 
    telefono, 
    edad: edad || 0, 
    intentos_fallidos, 
    aut2FA, 
    cuenta_bloqueada, 
    active, 
    rol,
    clave: claveEncriptada, 
    creado_en: now, 
    actualizado_en: now 
  };
  
  try {
    const { insertedId } = await usuariosCol.insertOne(doc);
    const created = await usuariosCol.findOne({ _id: insertedId });
    cb(null, toUsuario(created));
  } catch (error) {
    console.error('❌ Error creando usuario:', error);
    cb({
      code: grpc.status.INTERNAL,
      message: 'Error interno del servidor al crear usuario'
    });
  }
},

  async GetUsuario(call, cb) {
  const { id } = call.request;

  // Validar que el ID sea un ObjectId válido
  if (!id || !ObjectId.isValid(id)) {
    console.error('❌ ID inválido recibido:', id);
    return cb({
      code: grpc.status.INVALID_ARGUMENT,
      message: 'ID de usuario inválido'
    });
  }

  try {
    const objectId = new ObjectId(id);
    const usuario = await usuariosCol.findOne({ _id: objectId });
    
    if (!usuario) {
      return cb({
        code: grpc.status.NOT_FOUND,
        message: 'Usuario no encontrado'
      });
    }

    cb(null, toUsuario(usuario));
  } catch (error) {
    console.error('❌ Error al crear ObjectId:', error);
    cb({
      code: grpc.status.INVALID_ARGUMENT,
      message: 'ID de usuario inválido'
    });
  }
},
  async ListUsuarios(call, cb) {
    const { page = 1, pageSize = 10, q = "", onlyActive = false } = call.request;
    const filter = {};
    if (q) filter.nombre = { $regex: q, $options: "i" };
    if (onlyActive) filter.active = true;
    const skip = (page - 1) * pageSize;
    const [usuarios, total] = await Promise.all([
      usuariosCol.find(filter).skip(skip).limit(pageSize).toArray(),
      usuariosCol.countDocuments(filter)
    ]);
    cb(null, { usuarios: usuarios.map(toUsuario), page, pageSize, total });
  },
  async UpdateUsuario(call, cb) {
  const { id, ...fields } = call.request;
  
  // Validar ID
  if (!id || !ObjectId.isValid(id)) {
    return cb({
      code: grpc.status.INVALID_ARGUMENT,
      message: 'ID de usuario inválido'
    });
  }

  try {
    const objectId = new ObjectId(id);
    
    // Verificar si el usuario existe
    const usuarioExistente = await usuariosCol.findOne({ _id: objectId });
    if (!usuarioExistente) {
      return cb({
        code: grpc.status.NOT_FOUND,
        message: 'Usuario no encontrado'
      });
    }

    const update = { 
      ...fields, 
      actualizado_en: new Date() 
    };

    // Si se está actualizando la clave, encriptarla
    if (fields.clave) {
      update.clave = await bcrypt.hash(fields.clave, SALT_ROUNDS);
    }

    await usuariosCol.updateOne({ _id: objectId }, { $set: update });
    const updated = await usuariosCol.findOne({ _id: objectId });
    cb(null, toUsuario(updated));
  } catch (error) {
    console.error('❌ Error actualizando usuario:', error);
    cb({
      code: grpc.status.INTERNAL,
      message: 'Error interno del servidor'
    });
  }
},
  async DeleteUsuario(call, cb) {
    const { id } = call.request;
    const result = await usuariosCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  },
  async GetUsuariosPorRol(call, cb) {
  const { rol } = call.request;
  if (!rol) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'rol' es obligatorio" });

  const usuarios = await usuariosCol.find({ rol }).toArray();
  const response = {
    usuarios: usuarios.map(u => ({
      id: u._id.toString(),
      nombre: u.nombre,
      correo: u.correo,
      rol: u.rol
    }))
  };

  cb(null, response);
},
async ValidarUsuario(call, cb) {
  try {
    const { correo, clave } = call.request;

    // Buscar usuario por correo
    const usuario = await usuariosCol.findOne({ correo });

    if (!usuario || !usuario.clave) {
      return cb(null, { valido: false }); // Usuario no encontrado o sin clave
    }

    // Comparar clave ingresada con la encriptada
    const esValida = await bcrypt.compare(clave.trim(), usuario.clave);
    cb(null, { valido: esValida });
  } catch (error) {
    cb({ code: grpc.status.INTERNAL, message: error.message });
  }
},

async CountUsuarios(call, callback) {
    try {
        const total = await usuariosCol.countDocuments();
        callback(null, { total });
    } catch (error) {
        console.error('❌ Error al contar usuarios:', error);
        callback({
            code: grpc.status.INTERNAL,
            message: 'Error contando usuarios: ' + error.message
        });
    }
},

  async GetUsuarioByCodigo(call, cb) {
    const { codigo } = call.request;
    const usuario = await usuariosCol.findOne({ codigo });
    if (!usuario) return cb({ code: grpc.status.NOT_FOUND, message: "Usuario no encontrado" });
    cb(null, toUsuario(usuario));
  },

  async GetUsuarioByCorreo(call, cb) {
    const { correo } = call.request;
    const usuario = await usuariosCol.findOne({ correo });
    if (!usuario) return cb({ code: grpc.status.NOT_FOUND, message: "Usuario no encontrado" });
    cb(null, toUsuario(usuario));
  }
};

// Clientes
const handlerClientes = {
  // CREAR cliente
  async CreateCliente(call, cb) {
    const { 
      rut, 
      correo, 
      nombre, 
      telefono, 
      direccion, 
      edad, 
      intentos_fallidos = 0, 
      cuenta_bloqueada = false, 
      active = true,
      clave 
    } = call.request;

    try {
      // Validaciones
      if (!rut || !correo || !nombre || !clave) {
        return cb({
          code: grpc.status.INVALID_ARGUMENT,
          message: "Los campos rut, correo, nombre y clave son obligatorios"
        });
      }

      // Verificar si ya existe un cliente con el mismo RUT o correo
      const clienteExistente = await clientesCol.findOne({
        $or: [
          { rut: rut.trim() },
          { correo: correo.trim().toLowerCase() }
        ]
      });

      if (clienteExistente) {
        return cb({
          code: grpc.status.ALREADY_EXISTS,
          message: "Ya existe un cliente con ese RUT o correo"
        });
      }

      // Encriptar la clave
      const claveEncriptada = await bcrypt.hash(clave, SALT_ROUNDS);

      const now = new Date();
      const doc = { 
        rut: rut.trim(),
        correo: correo.trim().toLowerCase(),
        nombre: nombre.trim(),
        telefono: telefono ? telefono.trim() : '',
        direccion: direccion ? direccion.trim() : '',
        edad: edad || 0,
        intentos_fallidos: intentos_fallidos || 0,
        cuenta_bloqueada: cuenta_bloqueada || false,
        active: active !== false,
        clave: claveEncriptada,
        creado_en: now,
        actualizado_en: now
      };

      const { insertedId } = await clientesCol.insertOne(doc);
      const created = await clientesCol.findOne({ _id: insertedId });

      cb(null, toCliente(created));

    } catch (error) {
      console.error('❌ Error creando cliente:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // OBTENER cliente por ID
  async GetCliente(call, cb) {
    const { id } = call.request;
    
    try {
      const cliente = await clientesCol.findOne({ _id: new ObjectId(id) });
      if (!cliente) {
        return cb({ 
          code: grpc.status.NOT_FOUND, 
          message: "Cliente no encontrado" 
        });
      }
      
      cb(null, toCliente(cliente));
    } catch (error) {
      console.error('❌ Error obteniendo cliente:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // OBTENER cliente por RUT
  async GetClienteByRut(call, cb) {
    const { rut } = call.request;
    
    try {
      const cliente = await clientesCol.findOne({ rut: rut.trim() });
      if (!cliente) {
        return cb({ 
          code: grpc.status.NOT_FOUND, 
          message: "Cliente no encontrado" 
        });
      }
      
      cb(null, toCliente(cliente));
    } catch (error) {
      console.error('❌ Error obteniendo cliente por RUT:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // OBTENER cliente por CORREO
  async GetClienteByCorreo(call, cb) {
    const { correo } = call.request;
    
    try {
      const cliente = await clientesCol.findOne({ 
        correo: correo.trim().toLowerCase() 
      });
      
      if (!cliente) {
        return cb({ 
          code: grpc.status.NOT_FOUND, 
          message: "Cliente no encontrado" 
        });
      }
      
      cb(null, toCliente(cliente));
    } catch (error) {
      console.error('❌ Error obteniendo cliente por correo:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // LISTAR clientes
  async ListClientes(call, cb) {
    const { page = 1, pageSize = 10, q = "", onlyActive = false } = call.request;
    
    try {
      const filter = {};
      
      // Filtro de búsqueda
      if (q) {
        filter.$or = [
          { nombre: { $regex: q, $options: "i" } },
          { correo: { $regex: q, $options: "i" } },
          { rut: { $regex: q, $options: "i" } }
        ];
      }
      
      // Filtro de activos
      if (onlyActive) {
        filter.active = true;
      }

      const skip = (page - 1) * pageSize;
      const [clientes, total] = await Promise.all([
        clientesCol.find(filter)
          .sort({ creado_en: -1 })
          .skip(skip)
          .limit(pageSize)
          .toArray(),
        clientesCol.countDocuments(filter)
      ]);

      cb(null, { 
        clientes: clientes.map(toCliente), 
        page: parseInt(page), 
        pageSize: parseInt(pageSize), 
        total 
      });
      
    } catch (error) {
      console.error('❌ Error listando clientes:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // ACTUALIZAR cliente
  async UpdateCliente(call, cb) {
    const { id, ...fields } = call.request;
    
    try {
      if (!id) {
        return cb({
          code: grpc.status.INVALID_ARGUMENT,
          message: "El campo 'id' es obligatorio"
        });
      }

      // Verificar que el cliente existe
      const exists = await clientesCol.findOne({ _id: new ObjectId(id) });
      if (!exists) {
        return cb({
          code: grpc.status.NOT_FOUND,
          message: `Cliente con id '${id}' no encontrado`
        });
      }

      const update = { 
        ...fields, 
        actualizado_en: new Date() 
      };

      // Si se está actualizando la clave, encriptarla
      if (update.clave) {
        update.clave = await bcrypt.hash(update.clave, SALT_ROUNDS);
      }

      // Limpiar campos undefined
      Object.keys(update).forEach(key => {
        if (update[key] === undefined) {
          delete update[key];
        }
      });

      // Si se actualiza el correo, verificar que no exista otro cliente con el mismo correo
      if (update.correo) {
        update.correo = update.correo.trim().toLowerCase();
        const clienteConMismoCorreo = await clientesCol.findOne({
          correo: update.correo,
          _id: { $ne: new ObjectId(id) }
        });

        if (clienteConMismoCorreo) {
          return cb({
            code: grpc.status.ALREADY_EXISTS,
            message: "Ya existe otro cliente con ese correo"
          });
        }
      }

      // Si se actualiza el RUT, verificar que no exista otro cliente con el mismo RUT
      if (update.rut) {
        update.rut = update.rut.trim();
        const clienteConMismoRut = await clientesCol.findOne({
          rut: update.rut,
          _id: { $ne: new ObjectId(id) }
        });

        if (clienteConMismoRut) {
          return cb({
            code: grpc.status.ALREADY_EXISTS,
            message: "Ya existe otro cliente con ese RUT"
          });
        }
      }

      await clientesCol.updateOne(
        { _id: new ObjectId(id) }, 
        { $set: update }
      );
      
      const updated = await clientesCol.findOne({ _id: new ObjectId(id) });
      cb(null, toCliente(updated));
      
    } catch (error) {
      console.error('❌ Error actualizando cliente:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // ELIMINAR cliente
  async DeleteCliente(call, cb) {
    const { id } = call.request;
    
    try {
      if (!id) {
        return cb({
          code: grpc.status.INVALID_ARGUMENT,
          message: "El campo 'id' es obligatorio"
        });
      }

      const result = await clientesCol.deleteOne({ _id: new ObjectId(id) });
      cb(null, { ok: result.deletedCount > 0 });
      
    } catch (error) {
      console.error('❌ Error eliminando cliente:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // VALIDAR cliente (login)
  async ValidarCliente(call, cb) {
    const { correo, clave } = call.request;
    
    try {
      // Buscar cliente por correo
      const cliente = await clientesCol.findOne({ 
        correo: correo.trim().toLowerCase() 
      });

      if (!cliente || !cliente.clave) {
        return cb(null, { valido: false });
      }

      // Verificar si la cuenta está bloqueada
      if (cliente.cuenta_bloqueada) {
        return cb(null, { valido: false });
      }

      // Comparar clave ingresada con la encriptada
      const esValida = await bcrypt.compare(clave.trim(), cliente.clave);

      // Si la clave es inválida, incrementar intentos fallidos
      if (!esValida) {
        const nuevosIntentos = (cliente.intentos_fallidos || 0) + 1;
        const cuentaBloqueada = nuevosIntentos >= 3; // Bloquear después de 3 intentos

        await clientesCol.updateOne(
          { _id: cliente._id },
          { 
            $set: { 
              intentos_fallidos: nuevosIntentos,
              cuenta_bloqueada: cuentaBloqueada,
              actualizado_en: new Date()
            } 
          }
        );

        if (cuentaBloqueada) {
          console.log(`Cuenta bloqueada por intentos fallidos: ${correo}`);
        }

        return cb(null, { valido: false });
      }

      // Si la clave es válida, resetear intentos fallidos
      if (cliente.intentos_fallidos > 0) {
        await clientesCol.updateOne(
          { _id: cliente._id },
          { 
            $set: { 
              intentos_fallidos: 0,
              actualizado_en: new Date()
            } 
          }
        );
      }

      cb(null, { valido: true });
      
    } catch (error) {
      console.error('❌ Error validando cliente:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  },

  // CONTAR clientes
  async CountClientes(call, cb) {
    try {
      const total = await clientesCol.countDocuments();
      cb(null, { total });
    } catch (error) {
      console.error('❌ Error contando clientes:', error);
      cb({
        code: grpc.status.INTERNAL,
        message: 'Error del servidor: ' + error.message
      });
    }
  }
};


// Pedidos
const handlerPedidos = {
async CreatePedido(call, cb) {
  const {
    num_pedido,
    fecha_pedido,
    rut_cliente,
    fuente,
    estado,
    medio,
    info_entrega,
    total_pedido
  } = call.request;

  const doc = {
    num_pedido,
    fecha_pedido: new Date(fecha_pedido.seconds * 1000 + fecha_pedido.nanos / 1e6),
    rut_cliente,
    fuente,
    estado,
    medio,
    info_entrega,
    total_pedido
  };

  const { insertedId } = await pedidosCol.insertOne(doc);
  const created = await pedidosCol.findOne({ _id: insertedId });

  cb(null, {
    id: created._id.toString(),
    num_pedido: created.num_pedido,
    fecha_pedido,
    rut_cliente: created.rut_cliente,
    fuente,
    estado,
    medio,
    info_entrega: created.info_entrega,
    total_pedido
  });
},
  async GetPedido(call, cb) {
    const { id } = call.request;
    const pedido = await pedidosCol.findOne({ _id: new ObjectId(id) });
    if (!pedido) return cb({ code: grpc.status.NOT_FOUND, message: "Pedido no encontrado" });
    cb(null, toPedido(pedido));
  },
  async getByEstado(call, cb) {
  try {
    const {
      estado,
      page = 1,
      pageSize = 10
    } = call.request;

    // Validar que el estado esté presente
    if (estado === undefined || estado === null) {
      return cb({
        code: grpc.status.INVALID_ARGUMENT,
        message: "El parámetro 'estado' es requerido"
      });
    }

    // Crear filtro específico por estado
    const filter = { estado: estado };

    const skip = (page - 1) * pageSize;
    const [pedidos, total] = await Promise.all([
      pedidosCol.find(filter)
        .sort({ fecha_pedido: -1 }) // Ordenar por fecha más reciente
        .skip(skip)
        .limit(pageSize)
        .toArray(),
      pedidosCol.countDocuments(filter)
    ]);

    cb(null, {
      pedidos: pedidos.map(toPedido),
      page,
      pageSize,
      total
    });
  } catch (err) {
    console.error("Error en getByEstado:", err);
    cb({ 
      code: grpc.status.INTERNAL, 
      message: "Error al buscar pedidos por estado: " + err.message 
    });
  }
},
    async GetByNumero(call, cb) {
    const { numero } = call.request;
    const pedido = await pedidosCol.findOne({ numero });
    if (!pedido) return cb({ code: grpc.status.NOT_FOUND, message: "Pedido no encontrado" });
    cb(null, toPedido(pedido));
  },
  async ListPedidos(call, cb) {
  try {
    const {
      page = 1,
      pageSize = 10,
      q = "",
      rut_cliente = "",
      estado="",
      onlyActive = false
    } = call.request;

    const filter = {};

    if (q) {
      filter.$or = [
        { rut_cliente: { $regex: q, $options: "i" } },
        { estado: { $regex: q, $options: "i" } }
      ];
    }

    if (rut_cliente) {
      filter.rut_cliente = { $regex: rut_cliente, $options: "i" };
    }

    if (onlyActive) {
      filter.estado = { $ne: 5 }; // si usas estado ANULADO = 5
    }

    const skip = (page - 1) * pageSize;
    const [pedidos, total] = await Promise.all([
      pedidosCol.find(filter).skip(skip).limit(pageSize).toArray(),
      pedidosCol.countDocuments(filter)
    ]);

    cb(null, {
      pedidos: pedidos.map(toPedido),
      page,
      pageSize,
      total
    });
  } catch (err) {
    console.error("Error en ListPedidos:", err);
    cb({ code: grpc.status.INTERNAL, message: "Error al listar pedidos" });
  }
},

  async UpdatePedido(call, cb) {
    const { id, ...fields } = call.request;
    const update = {
      ...fields,
      fecha_pedido: timestampToDate(fields.fecha_pedido)
    };
    await pedidosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await pedidosCol.findOne({ _id: new ObjectId(id) });
    cb(null, toPedido(updated));
  },
  async DeletePedido(call, cb) {
    const { id } = call.request;
    const result = await pedidosCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  },
  async countPedidos(call, callback) {
    try {
        const total = await pedidosCol.countDocuments();
        callback(null, { total });
    } catch (error) {
        console.error('Error en countPedidos:', error);
        callback({
            code: grpc.status.INTERNAL,
            message: 'Error al contar pedidos'
        });
    }
},
async countByEstado(call, callback) {
    try {
        // Contar por cada estado (usando los strings que tienes en la BD)
        const counts = await Promise.all([
            pedidosCol.countDocuments({ estado: "PENDIENTE" }),
            pedidosCol.countDocuments({ estado: "EN_PREPARACION" }),
            pedidosCol.countDocuments({ estado: "LISTO" }),
            pedidosCol.countDocuments({ estado: "EN_CAMINO" }),
            pedidosCol.countDocuments({ estado: "ENTREGADO" }),
            pedidosCol.countDocuments({ estado: "ANULADO" })
        ]);
        
        const total = counts.reduce((sum, count) => sum + count, 0);
        
        callback(null, {
            pendiente: counts[0],
            en_preparacion: counts[1],
            listo: counts[2],
            en_camino: counts[3],
            entregado: counts[4],
            anulado: counts[5],
            total: total
        });
        
    } catch (error) {
        console.error('Error en countByEstado:', error);
        callback({
            code: grpc.status.INTERNAL,
            message: 'Error al contar pedidos por estado'
        });
    }
}
};

  //Detalle de pedido
  const handlerDetallePedido = {
    async CreateDetallePedido(call, cb) {
    const { num_pedido, cod_producto, cantidad } = call.request;

    const doc = { num_pedido, cod_producto, cantidad };
    const { insertedId } = await detallePedidoCol.insertOne(doc);
    const created = await detallePedidoCol.findOne({ _id: insertedId });

    cb(null, toDetallePedido(created));
  },

  async GetDetallePedido(call, cb) {
    const { id } = call.request;
    const detalle = await detallePedidoCol.findOne({ _id: new ObjectId(id) });
    if (!detalle) return cb({ code: grpc.status.NOT_FOUND, message: "Detalle del pedido no encontrado" });
    cb(null, toDetallePedido(detalle));
  },

async ListDetallePedido(call, cb) {
  const num_pedido = String(call.request.num_pedido).trim();

  const filtro = { num_pedido };

  const detallePedido = await detallePedidoCol.find(filtro).toArray();

  cb(null, {
    detallePedido: detallePedido.map(doc => ({
      id: doc._id.toString(),
      num_pedido: doc.num_pedido,
      cod_producto: doc.cod_producto,
      cantidad: doc.cantidad
    }))
  });
},

  async DeleteDetallePedido(call, cb) {
    const { id } = call.request;
    const result = await detallePedidoCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }};

  //Ventas
  const handlerVentas = {
  async CreateVenta(call, cb) {
  const {
    num_venta,
    num_pedido,
    fecha_venta,
    rut_cliente,
    rut_vendedor,
    medio
  } = call.request;

  const doc = {
    num_venta,
    num_pedido,
    fecha_venta: new Date(fecha_venta.seconds * 1000 + fecha_venta.nanos / 1e6),
    rut_cliente,
    rut_vendedor,
    medio
  };

  const { insertedId } = await ventasCol.insertOne(doc);
  const created = await ventasCol.findOne({ _id: insertedId });

  cb(null, {
    id: created._id.toString(),
    num_venta: created.num_venta,
    num_pedido: created.num_pedido,
    fecha_venta,
    rut_cliente: created.rut_cliente,
    rut_vendedor: created.rut_vendedor,
    medio
  });
},
  async GetVenta(call, cb) {
    const { id } = call.request;
    const venta = await ventasCol.findOne({ _id: new ObjectId(id) });
    if (!venta) return cb({ code: grpc.status.NOT_FOUND, message: "Venta no encontrada" });
    cb(null, toVenta(venta));
  },
  async ListVentas(call, cb) {
  try {
    const {
      page = 1,
      pageSize = 10,
      q = "",
      rut_cliente = "",
      rut_vendedor = "",
      onlyActive = false
    } = call.request;

    const filter = {};

    if (q) {
      filter.$or = [
        { rut_cliente: { $regex: q, $options: "i" } },
        { rut_vendedor: { $regex: q, $options: "i" } }
      ];
    }

    if (rut_cliente) {
      filter.rut_cliente = { $regex: rut_cliente, $options: "i" };
    }

    if (rut_vendedor) {
      filter.rut_vendedor = { $regex: rut_vendedor, $options: "i" };
    }

    const skip = (page - 1) * pageSize;
    const [ventas, total] = await Promise.all([
      ventasCol.find(filter).skip(skip).limit(pageSize).toArray(),
      ventasCol.countDocuments(filter)
    ]);

    cb(null, {
      ventas: ventas.map(toVenta),
      page,
      pageSize,
      total
    });
  } catch (err) {
    console.error("Error en ListVentas:", err);
    cb({ code: grpc.status.INTERNAL, message: "Error al listar ventas" });
  }
},

  async UpdateVenta(call, cb) {
    const { id, ...fields } = call.request;
    const update = {
      ...fields,
      fecha_venta: timestampToDate(fields.fecha_venta)
    };
    await ventasCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await ventasCol.findOne({ _id: new ObjectId(id) });
    cb(null, toVenta(updated));
  },
  async DeleteVenta(call, cb) {
    const { id } = call.request;
    const result = await ventasCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }};

  //Detalle de venta
  const handlerDetalleVenta = {
    async CreateDetalleVenta(call, cb) {
      const { num_venta, cod_producto, cantidad } = call.request;

      const doc = { num_venta, cod_producto, cantidad };
      const { insertedId } = await detalleVentaCol.insertOne(doc);
      const created = await detalleVentaCol.findOne({ _id: insertedId });

      cb(null, toDetalleVenta(created));
  },

  async GetDetalleVenta(call, cb) {
    const { id } = call.request;
    const detalle = await detalleVentaCol.findOne({ _id: new ObjectId(id) });
    if (!detalle) return cb({ code: grpc.status.NOT_FOUND, message: "Detalle de la venta no encontrado" });
    cb(null, toDetalleVenta(detalle));
  },

async ListDetalleVenta(call, cb) {
  const num_venta = String(call.request.num_venta).trim();

  const filtro = { num_venta };

  const detalleVenta = await detalleVentaCol.find(filtro).toArray();

  cb(null, {
    detalleVenta: detalleVenta.map(doc => ({
      id: doc._id.toString(),
      num_venta: doc.num_venta,
      cod_producto: doc.cod_producto,
      cantidad: doc.cantidad
    }))
  });
},

  async DeleteDetalleVenta(call, cb) {
    const { id } = call.request;
    const result = await detalleVentaCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }
};

async function main() {
  const client = new MongoClient(MONGODB_URI);
  await client.connect();
  db = client.db(MONGODB_DB);
  productosCol = db.collection("Productos");
  categoriasCol = db.collection("Categorias");
  permisosCol = db.collection("Permisos");
  rolesCol = db.collection("Roles");
  rolesPermisosCol = db.collection("RolesPermisos");
  usuariosCol = db.collection("Usuarios");
  clientesCol = db.collection("Clientes");
  pedidosCol = db.collection("Pedidos");
  detallePedidoCol = db.collection("DetallePedidos");
  ventasCol = db.collection("Ventas");
  detalleVentaCol = db.collection("DetalleVentas");

  const server = new grpc.Server();
  server.addService(productoProto.ProductosService.service, handlerProductos);
  server.addService(categoriaProto.CategoriasService.service, handlerCategorias);
  server.addService(permisoProto.PermisosService.service, handlerPermisos);
  server.addService(rolProto.RolesService.service, handlerRoles);
  server.addService(rolPermisoProto.RolesPermisosService.service, handlerRolesPermisos);
  server.addService(usuarioProto.UsuariosService.service, handlerUsuarios);
  server.addService(clienteProto.ClientesService.service, handlerClientes);
  server.addService(pedidoProto.PedidosService.service, handlerPedidos);
  server.addService(detallePedidoProto.DetallePedidosService.service, handlerDetallePedido);
  server.addService(ventaProto.VentasService.service, handlerVentas);
  server.addService(detalleVentaProto.DetalleVentasService.service, handlerDetalleVenta);


  server.bindAsync(`127.0.0.1:${GRPC_PORT}`, grpc.ServerCredentials.createInsecure(), (err, port) => {
    if (err) {
      console.error("Error al iniciar gRPC:", err);
      process.exit(1);
    }
  });

  //Si se presiona Ctrl-C finaliza proceso
  process.on("SIGINT", async () => {
    await client.close();
    server.tryShutdown(() => process.exit(0));
  });
}

main().catch((e) => {
  console.error("Error fatal:", e);
  process.exit(1);
});