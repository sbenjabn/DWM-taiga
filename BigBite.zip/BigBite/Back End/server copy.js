const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const { MongoClient, ObjectId } = require("mongodb");
const bcrypt = require('bcrypt');
const SALT_ROUNDS = 10;

require("dotenv").config();

const productoDef = protoLoader.loadSync("./protos/producto.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const categoriaDef = protoLoader.loadSync("./protos/categoria.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const permisoDef = protoLoader.loadSync("./protos/permiso.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const rolDef = protoLoader.loadSync("./protos/rol.proto", {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true
});

const rolPermisoDef = protoLoader.loadSync("./protos/rolpermiso.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const usuarioDef = protoLoader.loadSync("./protos/usuario.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const pedidoDef = protoLoader.loadSync("./protos/pedido.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const detallePedidoDef = protoLoader.loadSync("./protos/detallePedido.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const ventaDef = protoLoader.loadSync("./protos/venta.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const detalleVentaDef = protoLoader.loadSync("./protos/detalleVenta.proto", {
  keepCase: true,longs: String,enums: String,defaults: true,oneofs: true
});

const productoProto = grpc.loadPackageDefinition(productoDef).productos;
const categoriaProto = grpc.loadPackageDefinition(categoriaDef).categorias;
const permisoProto = grpc.loadPackageDefinition(permisoDef).permisos;
const rolProto = grpc.loadPackageDefinition(rolDef).roles;
const rolPermisoProto = grpc.loadPackageDefinition(rolPermisoDef).rolPermisos;
const usuarioProto = grpc.loadPackageDefinition(usuarioDef).usuarios;
const pedidoProto = grpc.loadPackageDefinition(pedidoDef).pedidos;
const detallePedidoProto = grpc.loadPackageDefinition(detallePedidoDef).detallePedidos;
const ventaProto = grpc.loadPackageDefinition(ventaDef).ventas;
const detalleVentaProto = grpc.loadPackageDefinition(detalleVentaDef).detalleVentas;

//enum de pedido.proto y venta.proto
const EstadoPedido = pedidoProto.EstadoPedido;
const MedioPago = pedidoProto.MedioPago;
const FuentePedido = pedidoProto.FuentePedido;

//Datos conexión
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const MONGODB_DB = process.env.MONGODB_DB || "BigBite";
const GRPC_PORT = process.env.GRPC_PORT || "50051";

let db, productosCol, categoriasCol, permisosCol, rolesCol, rolesPermisosCol, usuariosCol,
    pedidosCol, detallePedidoCol, ventasCol, detalleVentaCol;


//Conversión fechas
function dateToTimestamp(date) {
  const d = new Date(date);
  return {
    seconds: Math.floor(d.getTime() / 1000),
    nanos: (d.getMilliseconds() % 1000) * 1e6
  };
};

const toDetalleVenta = (doc) => ({
  id: doc._id.toString(),
  num_venta: doc.num_venta,
  cod_producto: doc.cod_producto,
  cantidad: doc.cantidad
});

const toVenta = (doc) => ({
    id: doc._id.toString(),
    num_venta: doc.num_venta,
    num_pedido: doc.num_pedido,
    fecha_venta: dateToTimestamp(doc.fecha_venta),
    rut_cliente: doc.rut_cliente,
    rut_vendedor: doc.rut_vendedor,
    medio: doc.medio
});

const toDetallePedido = (doc) => ({
  id: doc._id.toString(),
  num_pedido: doc.num_pedido,
  cod_producto: doc.cod_producto,
  cantidad: doc.cantidad
});

const toPedido = (doc) => ({
    id: doc._id.toString(),
    num_pedido: doc.num_pedido,
    fecha_pedido: dateToTimestamp(doc.fecha_pedido),
    rut_cliente: doc.rut_cliente,
    fuente: doc.fuente,
    estado: doc.estado,
    medio: doc.medio,
    info_entrega: doc.info_entrega
});

const toUsuario = (doc) => ({
  id: doc._id.toString(),
  rut: doc.rut,
  correo: doc.correo,
  nombre: doc.nombre,
  telefono: doc.telefono,
  edad: doc.edad,
  intentos_fallidos: doc.intentos_fallidos,
  aut2FA: !!doc.aut2FA,
  cuenta_bloqueada: !!doc.cuenta_bloqueada,
  active: !!doc.active,
  rol: doc.rol,
  clave: doc.clave,
  creado_en: doc.creado_en?.toISOString() || "",
  actualizado_en: doc.actualizado_en?.toISOString() || ""
});

const toRolPermiso = (doc) => ({
  id: doc._id.toString(),
  codigo_rol: doc.codigo_rol,
  codigo_permiso: doc.codigo_permiso
});

const toRol = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion
});

const toPermiso = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion
});

const toCategoria = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion
});

const toProducto = (doc) => ({
  id: doc._id.toString(),
  codigo: doc.codigo,
  nombre: doc.nombre,
  descripcion: doc.descripcion,
  precio: doc.precio,
  id_categoria: doc.id_categoria,
  ingredientes: doc.ingredientes || [],
  stock_disponible: doc.stock_disponible,
  url_imagen: doc.url_imagen,
  active: !!doc.active,
  creado_en: doc.creado_en?.toISOString() || "",
  actualizado_en: doc.actualizado_en?.toISOString() || ""
});

//Productos
const handlerProductos = {
  async CreateProducto(call, cb) {
    const { codigo, nombre, descripcion, precio, id_categoria, ingredientes = [], stock_disponible, url_imagen, active = true } = call.request;
    const now = new Date();
    const doc = { codigo, nombre, descripcion, precio, id_categoria, ingredientes, stock_disponible, url_imagen, active, creado_en: now, actualizado_en: now };
    const { insertedId } = await productosCol.insertOne(doc);
    const created = await productosCol.findOne({ _id: insertedId });
    cb(null, toProducto(created));
  },
  async GetProducto(call, cb) {
    const { id } = call.request;
    const producto = await productosCol.findOne({ _id: new ObjectId(id) });
    if (!producto) return cb({ code: grpc.status.NOT_FOUND, message: "Producto no encontrado" });
    cb(null, toProducto(producto));
  },
  async ListProductos(call, cb) {
    const { page = 1, pageSize = 10, q = "", onlyActive = false } = call.request;
    const filter = {};
    if (q) filter.nombre = { $regex: q, $options: "i" };
    if (onlyActive) filter.active = true;
    const skip = (page - 1) * pageSize;
    const [productos, total] = await Promise.all([
      productosCol.find(filter).skip(skip).limit(pageSize).toArray(),
      productosCol.countDocuments(filter)
    ]);
    cb(null, { productos: productos.map(toProducto), page, pageSize, total });
  },
  async UpdateProducto(call, cb) {
    const { id, ...fields } = call.request;
    const update = { ...fields, actualizado_en: new Date() };
    await productosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await productosCol.findOne({ _id: new ObjectId(id) });
    cb(null, toProducto(updated));
  },
  async DeleteProducto(call, cb) {
    const { id } = call.request;
    const result = await productosCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }};

// Categorías
const handlerCategorias = {
  async CreateCategoria(call, cb) {
    const { codigo, nombre, descripcion } = call.request;
    const doc = { codigo, nombre, descripcion };
    const { insertedId } = await categoriasCol.insertOne(doc);
    const created = await categoriasCol.findOne({ _id: insertedId });
    cb(null, toCategoria(created));
  },
  async GetCategoria(call, cb) {
    const { id } = call.request;
    const categoria = await categoriasCol.findOne({ _id: new ObjectId(id) });
    if (!categoria) return cb({ code: grpc.status.NOT_FOUND, message: "Categoría no encontrada" });
    cb(null, toCategoria(categoria));
  },
  async ListCategorias(call, cb) {
    const categorias = await categoriasCol.find().toArray();
    cb(null, { categorias: categorias.map(toCategoria) });
  },
  async UpdateCategoria(call, cb) {
  const { id, codigo, nombre, descripcion } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo !== undefined) update.codigo = codigo;
  if (nombre !== undefined) update.nombre = nombre;
  if (descripcion !== undefined) update.descripcion = descripcion;

  const exists = await categoriasCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Categoría con id '${id}' no encontrada` });

  await categoriasCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await categoriasCol.findOne({ _id: new ObjectId(id) });
  cb(null, toCategoria(updated));
},

async DeleteCategoria(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const result = await categoriasCol.deleteOne({ _id: new ObjectId(id) });
  cb(null, { ok: result.deletedCount > 0 });
}};

// Permisos
const handlerPermisos ={
  async CreatePermiso(call, cb) {
    const { codigo, nombre, descripcion } = call.request;
    const doc = { codigo, nombre, descripcion };
    const { insertedId } = await permisosCol.insertOne(doc);
    const created = await permisosCol.findOne({ _id: insertedId });
    cb(null, toPermiso(created));
  },
  async GetPermiso(call, cb) {
    const { id } = call.request;
    const permiso = await permisosCol.findOne({ _id: new ObjectId(id) });
    if (!permiso) return cb({ code: grpc.status.NOT_FOUND, message: "Permiso no encontrado" });
    cb(null, toPermiso(permiso));
  },
  async ListPermisos(call, cb) {
    const permisos = await permisosCol.find().toArray();
    cb(null, { permisos: permisos.map(toPermiso) });
  },
  async UpdatePermiso(call, cb) {
  const { id, codigo, nombre, descripcion } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo !== undefined) update.codigo = codigo;
  if (nombre !== undefined) update.nombre = nombre;
  if (descripcion !== undefined) update.descripcion = descripcion;

  const exists = await permisosCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Permiso con id '${id}' no encontrado` });

  await permisosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await permisosCol.findOne({ _id: new ObjectId(id) });
  cb(null, toPermiso(updated));
},

async DeletePermiso(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const result = await permisosCol.deleteOne({ _id: new ObjectId(id) });
  cb(null, { ok: result.deletedCount > 0 });
}};

// Roles
const handlerRoles = {
  async CreateRol(call, cb) {
    const { codigo, nombre, descripcion } = call.request;
    const doc = { codigo, nombre, descripcion };
    const { insertedId } = await rolesCol.insertOne(doc);
    const created = await rolesCol.findOne({ _id: insertedId });
    cb(null, toRol(created));
  },
  async GetRol(call, cb) {
    const { id } = call.request;
    const rol = await rolesCol.findOne({ _id: new ObjectId(id) });
    if (!rol) return cb({ code: grpc.status.NOT_FOUND, message: "Rol no encontrado" });
    cb(null, toRol(rol));
  },
  async ListRoles(call, cb) {
    const roles = await rolesCol.find().toArray();
    cb(null, { roles: roles.map(toRol) });
  },
  async UpdateRol(call, cb) {
  const { id, codigo, nombre, descripcion } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo !== undefined) update.codigo = codigo;
  if (nombre !== undefined) update.nombre = nombre;
  if (descripcion !== undefined) update.descripcion = descripcion;

  const exists = await rolesCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Rol con id '${id}' no encontrado` });

  await rolesCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await rolesCol.findOne({ _id: new ObjectId(id) });
  cb(null, toRol(updated));
},

async DeleteRol(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const result = await rolesCol.deleteOne({ _id: new ObjectId(id) });
  cb(null, { ok: result.deletedCount > 0 });
}};

// Roles Permisos
const handlerRolesPermisos = {
  async CreateRolPermiso(call, cb) {
    const { codigo_rol, codigo_permiso } = call.request;
    const doc = { codigo_rol, codigo_permiso };
    const { insertedId } = await rolesPermisosCol.insertOne(doc);
    const created = await rolesPermisosCol.findOne({ _id: insertedId });
    cb(null, toRolPermiso(created));
  },
  async GetRolPermiso(call, cb) {
    const { id } = call.request;
    const rolPermiso = await rolesPermisosCol.findOne({ _id: new ObjectId(id) });
    if (!rolPermiso) return cb({ code: grpc.status.NOT_FOUND, message: "Rol/permiso no encontrado" });
    cb(null, toRolPermiso(rolPermiso));
  },
  async ListRolesPermisos(call, cb) {
    const rolesPermisos = await rolesPermisosCol.find().toArray();
    cb(null, { roles_permisos: rolesPermisos.map(toRolPermiso) });
  },
  async UpdateRolPermiso(call, cb) {
  const { id, codigo_rol, codigo_permiso } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const update = {};
  if (codigo_rol !== undefined) update.codigo_rol = codigo_rol;
  if (codigo_permiso !== undefined) update.codigo_permiso = codigo_permiso;
  
  const exists = await rolesPermisosCol.findOne({ _id: new ObjectId(id) });
  if (!exists) return cb({ code: grpc.status.NOT_FOUND, message: `Rol/permiso con id '${id}' no encontrado` });

  await rolesPermisosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
  const updated = await rolesPermisosCol.findOne({ _id: new ObjectId(id) });
  cb(null, toRolPermiso(updated));
},

async DeleteRolPermiso(call, cb) {
  const { id } = call.request;
  if (!id) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'id' es obligatorio" });

  const result = await rolesPermisosCol.deleteOne({ _id: new ObjectId(id) });
  cb(null, { ok: result.deletedCount > 0 });
},
async GetPermisosPorRol(call, cb) {
  const { codigo_rol } = call.request;
  if (!codigo_rol) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'codigo_rol' es obligatorio" });

  const asociaciones = await rolesPermisosCol.find({ codigo_rol }).toArray();
  const codigosPermiso = asociaciones.map(a => a.codigo_permiso);

  const permisos = await permisosCol.find({ codigo: { $in: codigosPermiso } }).toArray();
  const response = {
    permisos: permisos.map(p => ({
      id: p._id.toString(),
      codigo: p.codigo,
      nombre: p.nombre,
      descripcion: p.descripcion
    }))
  };

  cb(null, response);
},
async GetRolesPorPermiso(call, cb) {
  const { codigo_permiso } = call.request;
  if (!codigo_permiso) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'codigo_permiso' es obligatorio" });

  const asociaciones = await rolesPermisosCol.find({ codigo_permiso }).toArray();
  const codigosRol = asociaciones.map(a => a.codigo_rol);

  const roles = await rolesCol.find({ codigo: { $in: codigosRol } }).toArray();
  const response = {
    roles: roles.map(r => ({
      id: r._id.toString(),
      codigo: r.codigo,
      nombre: r.nombre,
      descripcion: r.descripcion
    }))
  };

  cb(null, response);
}};

// Usuarios
const handlerUsuarios = {
  async CreateUsuario(call, cb) {
    const { rut, correo , nombre, telefono, edad, intentos_fallidos, aut2FA = false, cuenta_bloqueada = false, active = true, rol, clave } = call.request;
    const now = new Date();
    // Encriptar la clave antes de guardar
    const claveEncriptada = await bcrypt.hash(clave, SALT_ROUNDS);

    const doc = {  rut, 
                   correo , 
                   nombre, 
                   telefono, 
                   edad, 
                   intentos_fallidos, 
                   aut2FA, 
                   cuenta_bloqueada, 
                   active, 
                   rol,
                   clave:claveEncriptada, 
                   creado_en: now, 
                   actualizado_en: now };
    const { insertedId } = await usuariosCol.insertOne(doc);
    const created = await usuariosCol.findOne({ _id: insertedId });
    cb(null, toUsuario(created));
  },
  async GetUsuario(call, cb) {
    const { id } = call.request;
    const usuario = await usuariosCol.findOne({ _id: new ObjectId(id) });
    if (!usuario) return cb({ code: grpc.status.NOT_FOUND, message: "Usuario no encontrado" });
    cb(null, toUsuario(usuario));
  },
  async ListUsuarios(call, cb) {
    const { page = 1, pageSize = 10, q = "", onlyActive = false } = call.request;
    const filter = {};
    if (q) filter.nombre = { $regex: q, $options: "i" };
    if (onlyActive) filter.active = true;
    const skip = (page - 1) * pageSize;
    const [usuarios, total] = await Promise.all([
      usuariosCol.find(filter).skip(skip).limit(pageSize).toArray(),
      usuariosCol.countDocuments(filter)
    ]);
    cb(null, { usuarios: usuarios.map(toUsuario), page, pageSize, total });
  },
  async UpdateUsuario(call, cb) {
    const { id, ...fields } = call.request;
    const update = { ...fields, actualizado_en: new Date() };
    await usuariosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await usuariosCol.findOne({ _id: new ObjectId(id) });
    cb(null, toUsuario(updated));
  },
  async DeleteUsuario(call, cb) {
    const { id } = call.request;
    const result = await usuariosCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  },
  async GetUsuariosPorRol(call, cb) {
  const { rol } = call.request;
  if (!rol) return cb({ code: grpc.status.INVALID_ARGUMENT, message: "El campo 'rol' es obligatorio" });

  const usuarios = await usuariosCol.find({ rol }).toArray();
  const response = {
    usuarios: usuarios.map(u => ({
      id: u._id.toString(),
      nombre: u.nombre,
      correo: u.correo,
      rol: u.rol
    }))
  };

  cb(null, response);
},
async ValidarUsuario(call, cb) {
  try {
    const { correo, clave } = call.request;
    //console.log("Correo recibido:", correo);
    //console.log("Clave ingresada:", clave);

    // Buscar usuario por correo
    const usuario = await usuariosCol.findOne({ correo });
    //console.log("Correo recibido:", correo);
    //console.log("Clave ingresada:", clave);
    //console.log("Usuario encontrado:", usuario ? usuario.correo : "no encontrado");
    //console.log("Clave en BD:", usuario?.clave);
    if (!usuario || !usuario.clave) {
      return cb(null, { valido: false }); // Usuario no encontrado o sin clave
    }

    // Comparar clave ingresada con la encriptada
    const esValida = await bcrypt.compare(clave.trim(), usuario.clave);
    cb(null, { valido: esValida });
  } catch (error) {
    cb({ code: grpc.status.INTERNAL, message: error.message });
  }
}
};

// Pedidos
const handlerPedidos = {
async CreatePedido(call, cb) {
  const {
    num_pedido,
    fecha_pedido,
    rut_cliente,
    fuente,
    estado,
    medio,
    info_entrega
  } = call.request;

  const doc = {
    num_pedido,
    fecha_pedido: new Date(fecha_pedido.seconds * 1000 + fecha_pedido.nanos / 1e6),
    rut_cliente,
    fuente,
    estado,
    medio,
    info_entrega
  };

  const { insertedId } = await pedidosCol.insertOne(doc);
  const created = await pedidosCol.findOne({ _id: insertedId });

  cb(null, {
    id: created._id.toString(),
    num_pedido: created.num_pedido,
    fecha_pedido,
    rut_cliente: created.rut_cliente,
    fuente,
    estado,
    medio,
    info_entrega: created.info_entrega
  });
},
  async GetPedido(call, cb) {
    const { id } = call.request;
    const pedido = await pedidosCol.findOne({ _id: new ObjectId(id) });
    if (!pedido) return cb({ code: grpc.status.NOT_FOUND, message: "Pedido no encontrado" });
    cb(null, toPedido(pedido));
  },
  
  async ListPedidos(call, cb) {
  try {
    const {
      page = 1,
      pageSize = 10,
      q = "",
      rut_cliente = "",
      estado="",
      onlyActive = false
    } = call.request;

    const filter = {};

    if (q) {
      filter.$or = [
        { rut_cliente: { $regex: q, $options: "i" } },
        { estado: { $regex: q, $options: "i" } }
      ];
    }

    if (rut_cliente) {
      filter.rut_cliente = { $regex: rut_cliente, $options: "i" };
    }

    if (onlyActive) {
      filter.estado = { $ne: 5 }; // si usas estado ANULADO = 5
    }

    const skip = (page - 1) * pageSize;
    const [pedidos, total] = await Promise.all([
      pedidosCol.find(filter).skip(skip).limit(pageSize).toArray(),
      pedidosCol.countDocuments(filter)
    ]);

    cb(null, {
      pedidos: pedidos.map(toPedido),
      page,
      pageSize,
      total
    });
  } catch (err) {
    console.error("Error en ListPedidos:", err);
    cb({ code: grpc.status.INTERNAL, message: "Error al listar pedidos" });
  }
},

  async UpdatePedido(call, cb) {
    const { id, ...fields } = call.request;
    const update = {
      ...fields,
      fecha_pedido: timestampToDate(fields.fecha_pedido)
    };
    await pedidosCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await pedidosCol.findOne({ _id: new ObjectId(id) });
    cb(null, toPedido(updated));
  },
  async DeletePedido(call, cb) {
    const { id } = call.request;
    const result = await pedidosCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }};

  //Detalle de pedido
  const handlerDetallePedido = {
    async CreateDetallePedido(call, cb) {
    const { num_pedido, cod_producto, cantidad } = call.request;

    const doc = { num_pedido, cod_producto, cantidad };
    const { insertedId } = await detallePedidoCol.insertOne(doc);
    const created = await detallePedidoCol.findOne({ _id: insertedId });

    cb(null, toDetallePedido(created));
  },

  async GetDetallePedido(call, cb) {
    const { id } = call.request;
    const detalle = await detallePedidoCol.findOne({ _id: new ObjectId(id) });
    if (!detalle) return cb({ code: grpc.status.NOT_FOUND, message: "Detalle del pedido no encontrado" });
    cb(null, toDetallePedido(detalle));
  },

async ListDetallePedido(call, cb) {
  const num_pedido = String(call.request.num_pedido).trim();
  console.log("Buscando detalles para num_pedido:", num_pedido);

  const filtro = { num_pedido };
  console.log("Filtro usado:", filtro);

  const detallePedido = await detallePedidoCol.find(filtro).toArray();
  console.log("Detalles encontrados:", detallePedido.length);

  cb(null, {
    detallePedido: detallePedido.map(doc => ({
      id: doc._id.toString(),
      num_pedido: doc.num_pedido,
      cod_producto: doc.cod_producto,
      cantidad: doc.cantidad
    }))
  });
},

  async DeleteDetallePedido(call, cb) {
    const { id } = call.request;
    const result = await detallePedidoCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }};

  //Ventas
  const handlerVentas = {
  async CreateVenta(call, cb) {
  const {
    num_venta,
    num_pedido,
    fecha_venta,
    rut_cliente,
    rut_vendedor,
    medio
  } = call.request;

  const doc = {
    num_venta,
    num_pedido,
    fecha_venta: new Date(fecha_venta.seconds * 1000 + fecha_venta.nanos / 1e6),
    rut_cliente,
    rut_vendedor,
    medio
  };

  const { insertedId } = await ventasCol.insertOne(doc);
  const created = await ventasCol.findOne({ _id: insertedId });

  cb(null, {
    id: created._id.toString(),
    num_venta: created.num_venta,
    num_pedido: created.num_pedido,
    fecha_venta,
    rut_cliente: created.rut_cliente,
    rut_vendedor: created.rut_vendedor,
    medio
  });
},
  async GetVenta(call, cb) {
    const { id } = call.request;
    const venta = await ventasCol.findOne({ _id: new ObjectId(id) });
    if (!venta) return cb({ code: grpc.status.NOT_FOUND, message: "Venta no encontrada" });
    cb(null, toVenta(venta));
  },
  async ListVentas(call, cb) {
  try {
    const {
      page = 1,
      pageSize = 10,
      q = "",
      rut_cliente = "",
      rut_vendedor = "",
      onlyActive = false
    } = call.request;

    const filter = {};

    if (q) {
      filter.$or = [
        { rut_cliente: { $regex: q, $options: "i" } },
        { rut_vendedor: { $regex: q, $options: "i" } }
      ];
    }

    if (rut_cliente) {
      filter.rut_cliente = { $regex: rut_cliente, $options: "i" };
    }

    if (rut_vendedor) {
      filter.rut_vendedor = { $regex: rut_vendedor, $options: "i" };
    }

    const skip = (page - 1) * pageSize;
    const [ventas, total] = await Promise.all([
      ventasCol.find(filter).skip(skip).limit(pageSize).toArray(),
      ventasCol.countDocuments(filter)
    ]);

    cb(null, {
      ventas: ventas.map(toVenta),
      page,
      pageSize,
      total
    });
  } catch (err) {
    console.error("Error en ListVentas:", err);
    cb({ code: grpc.status.INTERNAL, message: "Error al listar ventas" });
  }
},

  async UpdateVenta(call, cb) {
    const { id, ...fields } = call.request;
    const update = {
      ...fields,
      fecha_venta: timestampToDate(fields.fecha_venta)
    };
    await ventasCol.updateOne({ _id: new ObjectId(id) }, { $set: update });
    const updated = await ventasCol.findOne({ _id: new ObjectId(id) });
    cb(null, toVenta(updated));
  },
  async DeleteVenta(call, cb) {
    const { id } = call.request;
    const result = await ventasCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }};

  //Detalle de venta
  const handlerDetalleVenta = {
    async CreateDetalleVenta(call, cb) {
      const { num_venta, cod_producto, cantidad } = call.request;

      const doc = { num_venta, cod_producto, cantidad };
      const { insertedId } = await detalleVentaCol.insertOne(doc);
      const created = await detalleVentaCol.findOne({ _id: insertedId });

      cb(null, toDetalleVenta(created));
  },

  async GetDetalleVenta(call, cb) {
    const { id } = call.request;
    const detalle = await detalleVentaCol.findOne({ _id: new ObjectId(id) });
    if (!detalle) return cb({ code: grpc.status.NOT_FOUND, message: "Detalle de la venta no encontrado" });
    cb(null, toDetalleVenta(detalle));
  },

async ListDetalleVenta(call, cb) {
  const num_venta = String(call.request.num_venta).trim();
  console.log("Buscando detalles para num_venta:", num_venta);

  const filtro = { num_venta };
  console.log("Filtro usado:", filtro);

  const detalleVenta = await detalleVentaCol.find(filtro).toArray();
  console.log("Detalles encontrados:", detalleVenta.length);

  cb(null, {
    detalleVenta: detalleVenta.map(doc => ({
      id: doc._id.toString(),
      num_venta: doc.num_venta,
      cod_producto: doc.cod_producto,
      cantidad: doc.cantidad
    }))
  });
},

  async DeleteDetalleVenta(call, cb) {
    const { id } = call.request;
    const result = await detalleVentaCol.deleteOne({ _id: new ObjectId(id) });
    cb(null, { ok: result.deletedCount > 0 });
  }
};

async function main() {
  const client = new MongoClient(MONGODB_URI);
  await client.connect();
  db = client.db(MONGODB_DB);
  productosCol = db.collection("Productos");
  categoriasCol = db.collection("Categorias");
  permisosCol = db.collection("Permisos");
  rolesCol = db.collection("Roles");
  rolesPermisosCol = db.collection("RolesPermisos");
  usuariosCol = db.collection("Usuarios");
  pedidosCol = db.collection("Pedidos");
  detallePedidoCol = db.collection("DetallePedidos");
  ventasCol = db.collection("Ventas");
  detalleVentaCol = db.collection("DetalleVentas");
 
  const server = new grpc.Server();
  server.addService(productoProto.ProductosService.service, handlerProductos);
  server.addService(categoriaProto.CategoriasService.service, handlerCategorias);
  server.addService(permisoProto.PermisosService.service, handlerPermisos);
  server.addService(rolProto.RolesService.service, handlerRoles);
  server.addService(rolPermisoProto.RolesPermisosService.service, handlerRolesPermisos);
  server.addService(usuarioProto.UsuariosService.service, handlerUsuarios);
  server.addService(pedidoProto.PedidosService.service, handlerPedidos);
  server.addService(detallePedidoProto.DetallePedidosService.service, handlerDetallePedido);
  server.addService(ventaProto.VentasService.service, handlerVentas);
  server.addService(detalleVentaProto.DetalleVentasService.service, handlerDetalleVenta);


  server.bindAsync(`127.0.0.1:${GRPC_PORT}`, grpc.ServerCredentials.createInsecure(), (err, port) => {
    if (err) {
      console.error("Error al iniciar gRPC:", err);
      process.exit(1);
    }
    console.log(`Servidor gRPC en puerto ${port} | MongoDB: ${MONGODB_DB}`);
  });

  //Si se presiona Ctrl-C finaliza proceso
  process.on("SIGINT", async () => {
    console.log("Cerrando servidor...");
    await client.close();
    server.tryShutdown(() => process.exit(0));
  });
}

main().catch((e) => {
  console.error("Error fatal:", e);
  process.exit(1);
});